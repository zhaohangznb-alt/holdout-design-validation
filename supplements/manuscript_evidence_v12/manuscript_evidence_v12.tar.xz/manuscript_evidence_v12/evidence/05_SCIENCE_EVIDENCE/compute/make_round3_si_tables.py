"""Generate the SI LaTeX block for Tables S23-S25 (F2, F5, F8) directly from the round-2 result files,
plus a JSON of every number used, so that no value is typed by hand.
Output: outputs/build/round3/si_tables_S23_S25.tex and outputs/build/round3/round3_numbers.json"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

R = Path(__file__).resolve().parents[1] / "results"
OUT = Path(__file__).resolve().parents[2] / "build/round3"
OUT.mkdir(parents=True, exist_ok=True)
ORDER = ["alk", "braf", "egfr", "erbb2", "kdr", "met", "ache", "dpp4", "ptgs2", "hdac1", "pde4d"]
KIN = ORDER[:6]


def f3(x):
    s = f"{x:.3f}"
    return "0.000" if s == "-0.000" else s


def rng(med, lo, hi):
    return f"{f3(med)} [{f3(lo)}, {f3(hi)}]"


nums = {}
# ------------------------------------------------------------------ F2 (Table S23)
# Amendment A3: 200 replicates with the RF random_state cycling over (42, 53, 67)[b % 3] (results in f2_b200/).
F2DIR = "f2_b200" if (R / "f2_b200/f2_target_summary.csv").exists() else "f2"
t2 = pd.read_csv(R / F2DIR / "f2_target_summary.csv").set_index("target")
p2 = pd.read_csv(R / F2DIR / "f2_panel_summary.csv").set_index("panel")
fits2 = pd.read_csv(R / F2DIR / "f2_replicate_fits.csv")
rc = pd.read_csv(R / "f8/f8_route_contrasts.csv")
arch = rc[(rc.view == "main") & (rc.scenario == "revised") & (rc.model == "rf") & (rc.weighting == "context")].set_index("target")
cs = pd.read_csv(R / "f8/f8_contrast_summary.csv")
archp = cs[(cs.view == "main") & (cs.scenario == "revised") & (cs.model == "rf") & (cs.weighting == "context")].set_index("panel")
B = int(fits2.replicate.nunique())
rows23 = []
for t in ORDER:
    r = t2.loc[t]
    neg = int(round(r.fraction_d_negative * B))
    rows23.append(f"{t.upper()} & {rng(r.se_skill_median, r.se_skill_p2_5, r.se_skill_p97_5)} & {rng(r.ye_skill_median, r.ye_skill_p2_5, r.ye_skill_p97_5)} & "
                  f"{f3(arch.loc[t, 'ye_minus_se'])} & {rng(r.d_median, r.d_p2_5, r.d_p97_5)} & {neg}/{B} \\\\")
    nums[f"S23_{t}"] = dict(se=[r.se_skill_median, r.se_skill_p2_5, r.se_skill_p97_5], ye=[r.ye_skill_median, r.ye_skill_p2_5, r.ye_skill_p97_5],
                            archived_d=arch.loc[t, "ye_minus_se"], d=[r.d_median, r.d_p2_5, r.d_p97_5], neg=neg)
    if t == "met":
        rows23.append("\\midrule")
panel_rows = []
for panel, label in [("kinase", "Six-kinase panel"), ("nonkinase", "Additional panel")]:
    r = p2.loc[panel]
    neg = int(round(r.fraction_replicates_panel_median_negative * B))
    panel_rows.append(f"{label} & & & {f3(archp.loc[panel, 'median_ye_minus_se'])} & {rng(r.median_paired_change_median, r.median_paired_change_p2_5, r.median_paired_change_p97_5)} & {neg}/{B} \\\\")
    nums[f"S23_panel_{panel}"] = dict(archived=archp.loc[panel, "median_ye_minus_se"], d=[r.median_paired_change_median, r.median_paired_change_p2_5, r.median_paired_change_p97_5], neg=neg)
brf = fits2[fits2.target == "braf"].pivot_table(index="replicate", columns="route", values="skill")
met = fits2[fits2.target == "met"].pivot_table(index="replicate", columns="route", values="skill")
nums["S23_braf_se_negative_replicates"] = int((brf.source_exact < 0).sum())
nums["S23_braf_se_min"] = float(brf.source_exact.min())
nums["S23_met_d_nonnegative"] = int(((met.temporal_exact - met.source_exact) >= 0).sum())
nums["S23_fits"] = int(len(fits2))
nums["S23_B"] = B
nums["S23_seed_mode"] = ("cycle" if "rf_random_state" in fits2 and fits2.rf_random_state.nunique() > 1 else "fixed42")
nums["S23_seed_values"] = sorted(int(x) for x in fits2.rf_random_state.unique()) if "rf_random_state" in fits2 else [42]
nums["S23_targets_all_negative"] = int(sum(1 for t in ORDER if nums[f"S23_{t}"]["neg"] == B))
nums["S23_other_d_nonnegative"] = {t: B - nums[f"S23_{t}"]["neg"] for t in ORDER if t not in ("braf", "met") and nums[f"S23_{t}"]["neg"] < B}

# ------------------------------------------------------------------ F5 (Table S24)
t5 = pd.read_csv(R / "f5/f5_target_summary.csv").set_index("target")
diag = pd.read_csv(R / "f5/f5_matching_diagnostics.csv")
fits5 = pd.read_csv(R / "f5/f5_fits.csv")
sizes = diag.groupby(["target", "arm"]).n.first().unstack()
rows24 = []
for t in ORDER:
    r = t5.loc[t]
    rows24.append(f"{t.upper()} & {int(sizes.loc[t, 'label_matched_source'])} & {int(sizes.loc[t, 'period_source'])} & "
                  f"{rng(r.label_matched_pool_contrast_median, r.label_matched_pool_contrast_min, r.label_matched_pool_contrast_max)} & "
                  f"{rng(r.recency_within_source_median, r.recency_within_source_min, r.recency_within_source_max)} & "
                  f"{rng(r.year_vs_period_source_median, r.year_vs_period_source_min, r.year_vs_period_source_max)} \\\\")
    nums[f"S24_{t}"] = dict(m=int(sizes.loc[t, "label_matched_source"]), nh=int(sizes.loc[t, "period_source"]),
                            label=[r.label_matched_pool_contrast_median, r.label_matched_pool_contrast_min, r.label_matched_pool_contrast_max],
                            period=[r.recency_within_source_median, r.recency_within_source_min, r.recency_within_source_max],
                            year_minus_period=[r.year_vs_period_source_median, r.year_vs_period_source_min, r.year_vs_period_source_max],
                            size_only=[r.size_only_pool_contrast_median, r.size_only_pool_contrast_min, r.size_only_pool_contrast_max])
    if t == "met":
        rows24.append("\\midrule")
for c in ["label_matched_pool_contrast", "recency_within_source", "year_vs_period_source", "size_only_pool_contrast"]:
    nums[f"S24_positive_{c}"] = int((t5[c + "_median"] > 0).sum())
lm = diag[diag.arm == "label_matched_source"]
nums["S24_max_deficit"] = int(lm.deficit.max()); nums["S24_max_deficit_target"] = lm.loc[lm.deficit.idxmax(), "target"]
nums["S24_max_deficit_n"] = int(lm.loc[lm.deficit.idxmax(), "n"])
nums["S24_max_abs_label_mean_gap"] = float((lm.sample_label_mean - lm.year_pool_label_mean).abs().max())
ps = diag[diag.arm == "period_source"]
nums["S24_period_tv_range"] = [float(ps.year_histogram_tv_vs_year_pool.min()), float(ps.year_histogram_tv_vs_year_pool.max())]
nums["S24_fits"] = int(len(fits5))
nums["S24_label_fits"] = int((fits5.arm == "label_matched_source").sum())
nums["S24_period_fits"] = int((fits5.arm != "label_matched_source").sum())
nums["S24_egfr_label_all_positive"] = bool(t5.loc["egfr", "label_matched_pool_contrast_min"] > 0)
nums["S24_ptgs2_label_all_negative"] = bool(t5.loc["ptgs2", "label_matched_pool_contrast_max"] < 0)
eg = lm[lm.target == "egfr"].iloc[0]
nums["S24_egfr_label_means"] = dict(sample=float(lm[lm.target == "egfr"].sample_label_mean.mean()), year=float(eg.year_pool_label_mean), source=float(eg.source_pool_label_mean))

# ------------------------------------------------------------------ F8 (Table S25)
rows25 = []
lab_panel = {"kinase": "Six kinases", "nonkinase": "Additional"}
lab_cohort = {"revised": "Broad", "single_protein": "Operational"}
lab_model = {"rf": "RF", "ridge": "Ridge", "tanimoto1nn": "1-NN"}
lab_w = {"context": "Context", "molecule": "Molecule", "document": "Document"}
m8 = cs[cs.view == "main"].copy()
for panel in ["kinase", "nonkinase"]:
    for coh in ["revised", "single_protein"]:
        for model in ["rf", "ridge", "tanimoto1nn"]:
            for w in ["context", "molecule", "document"]:
                r = m8[(m8.panel == panel) & (m8.scenario == coh) & (m8.model == model) & (m8.weighting == w)].iloc[0]
                rows25.append(f"{lab_panel[panel]} & {lab_cohort[coh]} & {lab_model[model]} & {lab_w[w]} & {f3(r.panel_median_se)} & {f3(r.panel_median_ye)} & "
                              f"{f3(r.median_ye_minus_se)} & {f3(r.median_ss_minus_se)} & {int(r.targets_lower_ye)}/{int(r.targets)} \\\\")
                nums[f"S25_{panel}_{coh}_{model}_{w}"] = dict(se=r.panel_median_se, ye=r.panel_median_ye, d_ye=r.median_ye_minus_se, d_ss=r.median_ss_minus_se,
                                                            lower=int(r.targets_lower_ye), n=int(r.targets))
        if not (panel == "nonkinase" and coh == "single_protein"):
            rows25.append("\\midrule")
st8 = json.loads((R / "f8/F8_STATUS.json").read_text())
nums["S25_context_check"] = st8["max_abs_context_target_skill_vs_archived"]

# ------------------------------------------------------------------ F5 by model (Table S26, Amendment A3)
bm = pd.read_csv(R / "f5/f5_target_summary_by_model.csv")
CONTRASTS = [("size_only_pool_contrast", "Size-only pool (reference)"), ("label_matched_pool_contrast", "Label-matched pool"),
             ("recency_within_source", "Period effect"), ("year_vs_period_source", "Year minus period")]
MODEL_LABEL = {"rf": "RF", "ridge": "Ridge", "tanimoto1nn": "1-NN"}
rows26 = []
for model in ["rf", "ridge", "tanimoto1nn"]:
    g = bm[bm.model == model]
    for col, label in CONTRASTS:
        med = col + "_median"
        if med not in g or not g[med].notna().any():
            continue
        v = g[med].dropna()
        n = int(v.notna().sum()); pos = int((v > 0).sum())
        rows26.append(f"{MODEL_LABEL[model]} & {label} & {f3(v.median())} & [{f3(v.min())}, {f3(v.max())}] & {pos}/{n} \\\\")
        nums[f"S26_{model}_{col}"] = dict(median=float(v.median()), min=float(v.min()), max=float(v.max()), positive=pos, n=n)
    if model != "tanimoto1nn":
        rows26.append("\\midrule")
# cross-check: each model's size-only pool contrast is taken from the archived per-draw contrasts (published Table S22),
# so the by-model size-only medians reproduce the per-draw contrasts of the published analysis for that model.
pdc_check = pd.read_csv(R / "f5/f5_per_draw_contrasts_by_model.csv")
gaps = []
for m in ["rf", "ridge", "tanimoto1nn"]:
    a = bm[bm.model == m].set_index("target").size_only_pool_contrast_median
    b = pdc_check[pdc_check.model == m].groupby("target").size_only_pool_contrast.median()
    gaps.append(float((a - b.reindex(a.index)).abs().max()))
nums["S26_size_only_selfconsistency"] = max(gaps)

CYCLE = nums["S23_seed_mode"] == "cycle"
_within = sum(1 for t in ORDER if nums[f"S23_{t}"]["d"][1] <= nums[f"S23_{t}"]["archived_d"] <= nums[f"S23_{t}"]["d"][2])
nums["S23_archived_within_range"] = int(_within)
P_AMEND = ("; a later amendment, also made before the corresponding fits, raised the Table S23 replicate count to " + str(B) + " and cycled the replicate RF seed, and added the Ridge and 1-NN control arms of Table S26"
           if CYCLE else "; a later amendment, also made before the corresponding fits, added the Ridge and 1-NN control arms of Table S26")
P_SEED = (r"RF was refitted on each resample with the replicate-cycled random state (seed $(42,53,67)[b\bmod 3]$), so the three published RF seeds are represented across replicates; the training mean was recomputed from the resampled labels, and skill was evaluated on the unchanged archived route test rows."
          if CYCLE else "RF with seed 42 was refitted on each resample, the training mean was recomputed from the resampled labels, and skill was evaluated on the unchanged archived route test rows.")
P_DONE = (f"Twenty replicates per target and route were completed ({nums['S23_fits']:,} fits)." if B == 20
          else f"In total, {B} replicates per target and route were completed ({nums['S23_fits']:,} fits).")
P_RANGE = ("Entries are the replicate median with the 2.5th and 97.5th percentiles over " + str(B) + " replicates, so they describe a training-resampling range conditional on the observed source documents and the fixed test rows; they are not confidence intervals for new targets. Because the replicate RF seed cycles over the three published seeds, this range also absorbs the RF seed variation reported in Table S4."
           if CYCLE else "Entries are the replicate median with the 2.5th and 97.5th percentiles. With 20 replicates these percentiles lie close to the most extreme replicates, so they describe a coarse training-resampling range conditional on the observed source documents and the fixed test rows; they are not confidence intervals for new targets, and the single RF seed omits the seed variation reported in Table S4.")
P_WITHIN = (r"Every archived $\Delta$ lies within its resampling range." if _within == len(ORDER)
            else rf"The archived $\Delta$ lies within its resampling range for {_within} of {len(ORDER)} targets.")

_oth = nums["S23_other_d_nonnegative"]
_names = [k.upper() for k in _oth]
_cnts = [str(v) for v in _oth.values()]
P_OTHER = ("" if not _oth else
           " " + (_names[0] if len(_names) == 1 else ", ".join(_names[:-1]) + " and " + _names[-1]) + r" had non-negative $\Delta$ in "
           + (_cnts[0] if len(_cnts) == 1 else ", ".join(_cnts[:-1]) + " and " + _cnts[-1]) + (" replicate." if _cnts == ["1"] else " replicates" + (", respectively." if len(_cnts) > 1 else ".")))

S23 = r"""\clearpage
\section*{Table S23 Training-document resampling of route contrasts}

Tables S23--S26 report four sensitivity analyses added after the primary analyses. Their protocol (models, seeds, resampling units, contrasts and summaries) was fixed before any of their results were computed. One design amendment, made before any result with real fingerprints existed, replaced a source arm matched to the year-pool document-year distribution, which could not be matched at the required size, by the period-restricted design of Table S24""" + P_AMEND + r""". In Table S23 the replicate random seed indexes targets in the package order ALK, BRAF, EGFR, ERBB2, KDR, MET, ACHE, DPP4, PTGS2, HDAC1, PDE4D rather than the alphabetical order stated in the protocol; the seeds were fixed in code before any fit and do not depend on outcomes. All fits used the recorded fitting environment and the fixed RF specification of the main analysis. No archived prediction, partition, training constant or primary estimate is changed.

For each broad-cohort target, the source-exact and year-exact training sets were resampled by whole training source documents with replacement, drawing as many documents as the training set contains and including every row of a drawn document once per draw. Replicate $b$ for target index $i$ and route $r$ (source exact 0, year exact 1) used \path{RandomState(20261004 + 1000b + 10i + r)}. """ + P_SEED + " " + P_DONE + r""" $\Delta$ is year-exact minus source-exact skill within a replicate; the panel rows summarise the replicate-wise median of $\Delta$ across targets. Archived $\Delta$ is the difference between the archived three-seed median skills (Table S21).

\begingroup
\setlength{\tabcolsep}{3pt}
\footnotesize
\renewcommand{\thetable}{S23}
\begin{longtable}{llllrl}
\caption{RF skill and paired route change under training-document resampling.}\label{tab:S23}\\
\toprule
Target & SE skill [P2.5, P97.5] & YE skill [P2.5, P97.5] & $\Delta$ [P2.5, P97.5] & Archived $\Delta$ & $\Delta<0$ \\
\midrule
\endfirsthead
\toprule
Target & SE skill [P2.5, P97.5] & YE skill [P2.5, P97.5] & $\Delta$ [P2.5, P97.5] & Archived $\Delta$ & $\Delta<0$ \\
\midrule
\endhead
"""
# reorder columns: put resampled delta before archived to match header
def reorder23(row):
    if row.startswith("\\"):
        return row
    cells = [c.strip() for c in row.rstrip("\\ ").split("&")]
    return " & ".join([cells[0], cells[1], cells[2], cells[4], cells[3], cells[5]]) + " \\\\"
S23 += "\n".join(reorder23(r) for r in rows23) + "\n\\midrule\n" + "\n".join(reorder23(r) for r in panel_rows) + "\n"
S23 += r"""\bottomrule
\end{longtable}
\endgroup

""" + P_RANGE + r""" The last column counts replicates with negative $\Delta$. """ + P_WITHIN + r""" The direction was negative in every replicate for """ + str(nums["S23_targets_all_negative"]) + r""" targets; BRAF had negative source-exact skill in """ + str(nums["S23_braf_se_negative_replicates"]) + r""" replicates (minimum """ + f3(nums["S23_braf_se_min"]) + r"""), and MET had non-negative $\Delta$ in """ + str(nums["S23_met_d_nonnegative"]) + r""" replicates, so a few training documents strongly influence these two route contrasts.""" + P_OTHER + r"""

"""
S24 = r"""\clearpage
\section*{Table S24 Label-matched and period-restricted common-test controls}

These controls use the common test intersections, the five draw seeds and the full-pool year-exact predictions of Table S22, with RF seeds 42, 53 and 67 (""" + str(nums["S24_fits"]) + r""" fits). The label-matched source sample has the year-pool size $m$ and is drawn without replacement from the full source-exact training pool to the year-pool label distribution: strata are ten bins defined by the deciles of the year-pool labels (outer edges unbounded), each stratum receives the year-pool count, and any shortfall is filled uniformly from the remaining source rows (\path{RandomState(draw + 7)}; at most """ + str(nums["S24_max_deficit"]) + " of " + f"{nums['S24_max_deficit_n']:,}" + r""" rows, for """ + nums["S24_max_deficit_target"].upper() + r"""). The period-restricted source pool contains all source-exact training rows whose document year is not later than the year route's training end; it has $n_h<m$ rows and is used whole. It is compared with uniform random samples of size $n_h$ from the full source pool (\path{RandomState(draw + 17)}) and from the year pool (\path{RandomState(draw + 19)}). Sampled positions retain original row order. Outcome labels are used only to define the label strata.

Entries are differences in RF MSE on the common test rows (pIC50 squared), computed per draw from three-seed medians and summarised by the median over the five draws, with the draw minimum and maximum in brackets. Label-matched pool is the full year pool minus the label-matched source sample; period effect is the period-restricted source pool minus the random source sample of size $n_h$; year minus period is the random year-pool sample of size $n_h$ minus the period-restricted source pool. Positive values mean higher error for the first-named arm. The published size-only contrast (RF pool in Table S22) is the reference.

\begingroup
\setlength{\tabcolsep}{3pt}
\footnotesize
\renewcommand{\thetable}{S24}
\begin{longtable}{lrrlll}
\caption{Common-test RF MSE contrasts with label-matched and period-restricted source pools.}\label{tab:S24}\\
\toprule
Target & $m$ & $n_h$ & Label-matched pool [range] & Period effect [range] & Year minus period [range] \\
\midrule
\endfirsthead
\toprule
Target & $m$ & $n_h$ & Label-matched pool [range] & Period effect [range] & Year minus period [range] \\
\midrule
\endhead
""" + "\n".join(rows24) + "\n" + r"""\bottomrule
\end{longtable}
\endgroup

Median contrasts were positive in """ + str(nums["S24_positive_label_matched_pool_contrast"]) + r""" targets for the label-matched pool (""" + str(nums["S24_positive_size_only_pool_contrast"]) + r""" for the published size-only contrast), in """ + str(nums["S24_positive_recency_within_source"]) + r""" for the period effect and in """ + str(nums["S24_positive_year_vs_period_source"]) + r""" for year minus period. The label-matched samples reproduced the year-pool label mean to within """ + f3(nums["S24_max_abs_label_mean_gap"]) + r""" pIC50. The period-restricted pools contain no rows after the training end, but their document-year distributions still differ from those of the year pools (total-variation distance """ + f"{nums['S24_period_tv_range'][0]:.2f}" + r"""--""" + f"{nums['S24_period_tv_range'][1]:.2f}" + r"""), and their label distributions are not matched. These comparisons are descriptive: they reduce but do not remove the mixture of structural, label, temporal and source-composition differences between pools, and the PTGS2 intersection contains 35 measurement contexts.

"""
S25 = r"""\clearpage
\section*{Table S25 Evaluation-unit weighting of route contrasts}

The 680 archived prediction files were rescored without refitting. Context weighting is the published estimand, in which every aggregated measurement context has weight one. Molecule weighting gives every unique structure string in a test set a total weight of one, split equally over its contexts; document weighting does the same for every test source document. Model and training-mean errors use the same weights, skill is $1-\mathrm{wMSE}_{model}/\mathrm{wMSE}_{mean}$, and RF uses the three-seed median. Context weighting reproduces the archived target skills (maximum difference $2.2\times10^{-16}$). Entries are main-view panel medians of source-exact (SE) and year-exact (YE) skill, median within-target paired changes and the number of targets with lower YE skill; no intervals are computed.

\begingroup
\setlength{\tabcolsep}{3pt}
\footnotesize
\renewcommand{\thetable}{S25}
\begin{longtable}{llllrrrrr}
\caption{Panel skills and paired route changes under context, molecule and document weighting.}\label{tab:S25}\\
\toprule
Panel & Cohort & Model & Weighting & SE & YE & YE$-$SE & SS$-$SE & Lower YE \\
\midrule
\endfirsthead
\toprule
Panel & Cohort & Model & Weighting & SE & YE & YE$-$SE & SS$-$SE & Lower YE \\
\midrule
\endhead
""" + "\n".join(rows25) + "\n" + r"""\bottomrule
\end{longtable}
\endgroup

For RF, the median paired year-exact change remained negative and larger in magnitude than the scaffold-filter change under all three weightings in both panels and cohorts. Document weighting reduced its magnitude, for example from """ + f3(nums["S25_kinase_revised_rf_context"]["d_ye"]) + " to " + f3(nums["S25_kinase_revised_rf_document"]["d_ye"]) + r""" in the broad six-kinase panel, and raised both panel skills, consistent with documents that contribute many test contexts weighing more heavily in the context-weighted contrast. The Ridge exception in the additional operational panel, in which the scaffold-filter contrast exceeded the year-exact contrast in magnitude, held under context and document weighting but not under molecule weighting (""" + f3(nums["S25_nonkinase_single_protein_ridge_molecule"]["d_ss"]) + " versus " + f3(nums["S25_nonkinase_single_protein_ridge_molecule"]["d_ye"]) + r"""). The number of broad six-kinase targets with lower 1-NN year-exact skill changed from """ + f"{nums['S25_kinase_revised_tanimoto1nn_context']['lower']}" + " (context) to " + f"{nums['S25_kinase_revised_tanimoto1nn_molecule']['lower']}" + " (molecule) and " + f"{nums['S25_kinase_revised_tanimoto1nn_document']['lower']}" + r""" (document) of six.
"""
S26 = r"""\clearpage
\section*{Table S26 Label-matched and period-restricted controls for Ridge and 1-NN}

The common-test controls of Table S24 were repeated for the two fixed alternative models, Ridge and 1-NN, with the fixed specifications of the main analysis and the same pools, draws and seeds. RF is included for reference. Ridge and 1-NN are deterministic, so each draw gives a single value; RF uses the three-seed median. The contrasts are differences in model MSE on the common test rows (pIC50 squared), summarised here as the median across the eleven targets of each target's five-draw median, with the target-level minimum and maximum in brackets. Positive values mean higher error for the first-named arm. Each model has its own size-only pool contrast; the size-only row for every model is the corresponding published per-draw reference (Table S22), carried over unchanged, so that the label-matched, period and year-minus-period rows isolate the effect of matching or restricting the source pool for that fixed model.

\begingroup
\setlength{\tabcolsep}{4pt}
\footnotesize
\renewcommand{\thetable}{S26}
\begin{longtable}{lllll}
\caption{Common-test MSE contrasts for RF, Ridge and 1-NN across the eleven targets.}\label{tab:S26}\\
\toprule
Model & Contrast & Median & [min, max] & Positive \\
\midrule
\endfirsthead
\toprule
Model & Contrast & Median & [min, max] & Positive \\
\midrule
\endhead
""" + "\n".join(rows26) + "\n" + r"""\bottomrule
\end{longtable}
\endgroup

The label-matched pool and period contrasts were positive for a majority of targets under all three models: for the label-matched pool, """ + str(nums["S26_rf_label_matched_pool_contrast"]["positive"]) + r""" of """ + str(nums["S26_rf_label_matched_pool_contrast"]["n"]) + r""" targets under RF, """ + str(nums["S26_ridge_label_matched_pool_contrast"]["positive"]) + r""" under Ridge and """ + str(nums["S26_tanimoto1nn_label_matched_pool_contrast"]["positive"]) + r""" under 1-NN; for the period effect, """ + str(nums["S26_rf_recency_within_source"]["positive"]) + r""", """ + str(nums["S26_ridge_recency_within_source"]["positive"]) + r""" and """ + str(nums["S26_tanimoto1nn_recency_within_source"]["positive"]) + r""" respectively. The residual year-minus-period contrast was positive for a minority under every model (""" + str(nums["S26_rf_year_vs_period_source"]["positive"]) + r""", """ + str(nums["S26_ridge_year_vs_period_source"]["positive"]) + r""" and """ + str(nums["S26_tanimoto1nn_year_vs_period_source"]["positive"]) + r"""), consistent with the Table S24 reading that most of the common-test gap is attributable to label and pool composition rather than to document year alone, across all three fixed models.
"""
block = S23 + S24 + S25 + S26
(OUT / "si_tables_S23_S26.tex").write_text(block, encoding="utf-8")


def clean(o):
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o


(OUT / "round3_numbers.json").write_text(json.dumps(clean(nums), indent=1), encoding="utf-8")
print("written", OUT / "si_tables_S23_S26.tex", len(block), "chars")
