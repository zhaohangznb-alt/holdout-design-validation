"""Amendment A3 guard: the Ridge and 1-NN helpers used for the extended F5 arms must reproduce archived predictions.
Refits Ridge and rebuilds 1-NN on the archived source-exact and year-exact training pools of ALK and ACHE and compares
with the archived main/revised prediction files (Ridge: max |diff| <= 1e-9; 1-NN: exact). Writes RIDGE_NN_EQUIVALENCE.json."""
import argparse, json
from pathlib import Path
import numpy as np
from r2common import sha, read, save, stamp, environment, Featurizer, csv, ridge_fit_predict, nn_predict, panel_of

ap = argparse.ArgumentParser()
ap.add_argument("--snapshot", type=Path, required=True)
ap.add_argument("--bundle", type=Path, required=True)
ap.add_argument("--output", type=Path, required=True)
a = ap.parse_args()
env = environment(False)
snap, b, out = a.snapshot.resolve(), a.bundle.resolve(), a.output.resolve()
out.mkdir(parents=True, exist_ok=True)
ih, fm, cfg = read(snap / "INPUT_HASHES.json"), read(b / "FILE_MANIFEST.json"), read(snap / "MODEL_CONFIG.json")
feat = Featurizer(cfg["fingerprint"])
res = []
for t in ["alk", "ache"]:
    for route in ["source_exact", "temporal_exact"]:
        trf = f"inputs/train_{t}_{route}_full.csv"
        assert sha(snap / trf) == ih[trf]
        tr = csv(snap / trf)
        Xtr, ytr = feat.matrix(tr.smiles), tr.target.to_numpy(float)
        for model in ["ridge", "tanimoto1nn"]:
            rel = f"results/predictions/{panel_of(t)}/main_revised_{t}_{route}_{model}_0.csv"
            assert sha(b / rel) == fm[rel], rel
            te = csv(b / rel)
            Xte = feat.matrix(te.smiles)
            pred = ridge_fit_predict(Xtr, ytr, Xte) if model == "ridge" else nn_predict(Xtr, ytr, Xte)
            d = float(np.max(np.abs(pred - te.prediction.to_numpy(float))))
            ok = d <= 1e-9 if model == "ridge" else d == 0.0
            res.append(dict(target=t, route=route, model=model, rows=len(te), max_abs_difference=d, passed=bool(ok)))
            print(t, route, model, d, ok, flush=True)
status = dict(checks=res, all_passed=all(r["passed"] for r in res), environment=env, checked=stamp())
save(out / "RIDGE_NN_EQUIVALENCE.json", status)
assert status["all_passed"], "Ridge/1-NN helpers do not reproduce the archived predictions"
