"""P3-0 exporter guard (PROTOCOL_PHASE3.md).
For the five archived additional targets, the ChEMBL 37 working-extract export must reproduce
 (a) the frozen API responses: same activity_id set and identical values of every field used by clean(); same assay fields;
 (b) the archived prepared partitions: clean()/split() on the export, written as prepare_external.main writes them,
     must give files with the SHA-256 recorded in the F1 reproduction's split manifest.
Writes <out>/P3_GUARD.json and per-target mismatch samples. Exit code 0 only if every check passes.
"""
import argparse, json, math
from pathlib import Path
import pandas as pd
from r2common import save, stamp, sha
from p3_common import ADDITIONAL_IDS, import_bundle, screen, write_partitions
from p3_chembl import export_target

ACT_STR = ["target_chembl_id", "target_organism", "standard_type", "standard_relation", "data_validity_comment", "standard_units",
           "canonical_smiles", "assay_chembl_id", "document_chembl_id"]
ACT_NUM = ["standard_flag", "potential_duplicate", "standard_value", "pchembl_value", "document_year"]
ASSAY_STR = ["relationship_type", "target_chembl_id", "assay_type", "bao_format"]


def load_api(raw, symbol):
    acts, assays = [], {}
    for p in sorted((raw / symbol).glob("activities_*.json")):
        if p.name.endswith((".request.json", ".error.json")):
            continue
        acts.extend(json.loads(p.read_text(encoding="utf8"))["activities"])
    for p in sorted((raw / symbol).glob("assays_*.json")):
        if p.name.endswith((".request.json", ".error.json")):
            continue
        assays.update({a["assay_chembl_id"]: a for a in json.loads(p.read_text(encoding="utf8"))["assays"]})
    return {a["activity_id"]: a for a in acts}, assays


def num(v):
    if v is None:
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return ("text", str(v))
    return None if math.isnan(x) else x


def compare(api_acts, api_assays, ex_acts, ex_assays):
    res = dict(api_activities=len(api_acts), export_activities=len(ex_acts),
               only_api=sorted(set(api_acts) - set(ex_acts))[:20], only_export=sorted(set(ex_acts) - set(api_acts))[:20],
               n_only_api=len(set(api_acts) - set(ex_acts)), n_only_export=len(set(ex_acts) - set(api_acts)))
    diffs = {}
    for k in sorted(set(api_acts) & set(ex_acts)):
        a, e = api_acts[k], ex_acts[k]
        for f in ACT_STR:
            if a.get(f) != e.get(f):
                diffs.setdefault(f, []).append([k, a.get(f), e.get(f)])
        for f in ACT_NUM:
            if num(a.get(f)) != num(e.get(f)):
                diffs.setdefault(f, []).append([k, a.get(f), e.get(f)])
    res["activity_field_mismatches"] = {f: len(v) for f, v in diffs.items()}
    res["activity_field_examples"] = {f: v[:5] for f, v in diffs.items()}
    used = {e["assay_chembl_id"] for e in ex_acts.values()}
    adiff = {}
    for aid in sorted(used):
        a, e = api_assays.get(aid), ex_assays.get(aid)
        if a is None or e is None:
            adiff.setdefault("missing", []).append([aid, a is None, e is None]); continue
        for f in ASSAY_STR:
            if a.get(f) != e.get(f):
                adiff.setdefault(f, []).append([aid, a.get(f), e.get(f)])
    res["assay_field_mismatches"] = {f: len(v) for f, v in adiff.items()}
    res["assay_field_examples"] = {f: v[:5] for f, v in adiff.items()}
    res["passed"] = res["n_only_api"] == 0 and res["n_only_export"] == 0 and not diffs and not adiff
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work37", type=Path, required=True, help="working extract of ChEMBL 37 (p3_chembl.py build)")
    ap.add_argument("--bundle", type=Path, required=True, help="verified bundle (F1 copy): code + inputs/external_raw")
    ap.add_argument("--prepared", type=Path, required=True, help="F1 reproduction: <bundle>/reproduced_full_r2/external_prepared")
    ap.add_argument("--output", type=Path, required=True)
    a = ap.parse_args()
    out = a.output.resolve(); out.mkdir(parents=True, exist_ok=True)
    pe = import_bundle(a.bundle)
    api_raw = a.bundle.resolve() / "inputs/external_raw"
    man = pd.read_csv(a.prepared / "split_manifest.csv")
    ex_raw = out / "raw37"
    results = {}
    for symbol, tid in ADDITIONAL_IDS.items():
        summ = export_target(a.work37, tid, ex_raw / symbol)
        api_acts, api_assays = load_api(api_raw, symbol)
        ex = json.loads((ex_raw / symbol / "activities_000000.json").read_text(encoding="utf8"))["activities"]
        exa = json.loads((ex_raw / symbol / "assays_000000.json").read_text(encoding="utf8"))["assays"]
        r = compare(api_acts, api_assays, {x["activity_id"]: x for x in ex}, {x["assay_chembl_id"]: x for x in exa})
        r["export"] = summ
        # (b) clean()/split() on the export vs the archived partitions
        g, routes, cut, summary, flow = screen(pe, ex_raw, symbol, tid)
        r["screen_summary"] = summary
        part = []
        if routes is not None:
            rows, unavailable = write_partitions(out / "prepared_from_export", symbol, routes)
            got = {(x["scenario"], x["route"], x["partition"]): x["corrected_sha256"] for x in rows}
            ref = {(x.scenario, x.route, x.partition): x.corrected_sha256 for x in man[man.target == symbol].itertuples()}
            for k in sorted(set(got) | set(ref)):
                part.append(dict(scenario=k[0], route=k[1], partition=k[2], export_sha256=got.get(k), archived_sha256=ref.get(k), identical=got.get(k) == ref.get(k)))
        r["partitions_checked"] = len(part)
        r["partitions_identical"] = sum(p["identical"] for p in part)
        r["partition_mismatches"] = [p for p in part if not p["identical"]]
        r["partitions_passed"] = bool(part) and all(p["identical"] for p in part)
        results[symbol] = r
        print(symbol, "records", r["passed"], "partitions", r["partitions_identical"], "/", r["partitions_checked"], flush=True)
    status = dict(check="P3-0 exporter guard", targets=results, records_passed=all(r["passed"] for r in results.values()),
                  partitions_passed=all(r["partitions_passed"] for r in results.values()), work37=str(a.work37),
                  work37_record=json.loads(Path(a.work37).with_suffix(".complete.json").read_text(encoding="utf8")) if Path(a.work37).with_suffix(".complete.json").exists() else None,
                  prepared_split_manifest_sha256=sha(a.prepared / "split_manifest.csv"), checked=stamp())
    status["all_passed"] = status["records_passed"] and status["partitions_passed"]
    save(out / "P3_GUARD.json", status)
    print("P3-0 all passed:", status["all_passed"], flush=True)
    raise SystemExit(0 if status["all_passed"] else 3)


if __name__ == "__main__":
    main()
