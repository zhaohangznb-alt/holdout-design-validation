"""F8: evaluation-unit weighting sensitivity on the 680 archived per-row prediction files (no fitting).
Protocol: PROTOCOL_ROUND2.md (section F8)."""
import argparse, json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd

KEY = ["panel", "view", "scenario", "target", "route", "model"]


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def weights(f, scheme):
    if scheme == "context":
        return np.ones(len(f))
    col = "smiles" if scheme == "molecule" else "document_chembl_id"
    n = f.groupby(col)[col].transform("size").to_numpy(float)
    return 1.0 / n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    a = ap.parse_args()
    b, out = a.bundle.resolve(), a.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    fm = json.loads((b / "FILE_MANIFEST.json").read_text(encoding="utf8"))
    rm = pd.read_csv(b / "results/analysis/run_metrics.csv")
    recs = []
    for r in rm.itertuples():
        rel = f"results/predictions/{r.panel}/{r.prediction_file}"
        assert sha(b / rel) == fm[rel], rel
        f = pd.read_csv(b / rel, float_precision="round_trip")
        y = f.target.to_numpy(float); p = f.prediction.to_numpy(float); c = f.training_mean.to_numpy(float)
        for scheme in ["context", "molecule", "document"]:
            w = weights(f, scheme)
            mse = float(np.sum(w * (y - p) ** 2) / w.sum()); base = float(np.sum(w * (y - c) ** 2) / w.sum())
            recs.append(dict(panel=r.panel, view=r.view, scenario=r.scenario, target=r.target, route=r.route, model=r.model, seed=r.seed,
                             weighting=scheme, rows=len(f), units=int(len(f) if scheme == "context" else f[("smiles" if scheme == "molecule" else "document_chembl_id")].nunique()),
                             wmse_model=mse, wmse_mean=base, skill=1 - mse / base, archived_skill=r.skill))
    df = pd.DataFrame(recs)
    df.to_csv(out / "f8_run_weighted.csv", index=False)
    ctx = df[df.weighting == "context"]
    check = float(np.max(np.abs(ctx.skill - ctx.archived_skill)))
    tg = df.groupby(KEY + ["weighting"], as_index=False).agg(skill=("skill", "median"), units=("units", "first"), rows=("rows", "first"))
    tm = pd.read_csv(b / "results/analysis/target_metrics.csv")
    chk = tg[tg.weighting == "context"].merge(tm[KEY + ["skill"]], on=KEY, suffixes=("", "_archived"))
    target_check = float(np.max(np.abs(chk.skill - chk.skill_archived)))
    tg.to_csv(out / "f8_target_skills.csv", index=False)
    routes = tg.pivot_table(index=["panel", "view", "scenario", "target", "model", "weighting"], columns="route", values="skill").reset_index()
    routes["ye_minus_se"] = routes.temporal_exact - routes.source_exact
    routes["ss_minus_se"] = routes.source_scaffold - routes.source_exact
    routes.to_csv(out / "f8_route_contrasts.csv", index=False)
    g = routes.groupby(["panel", "view", "scenario", "model", "weighting"])
    summ = g.agg(median_ye_minus_se=("ye_minus_se", "median"), median_ss_minus_se=("ss_minus_se", "median"),
                 targets_lower_ye=("ye_minus_se", lambda s: int((s < 0).sum())), targets=("target", "size"),
                 panel_median_se=("source_exact", "median"), panel_median_ye=("temporal_exact", "median")).reset_index()
    summ.to_csv(out / "f8_contrast_summary.csv", index=False)
    status = dict(prediction_files=int(rm.shape[0]), weightings=["context", "molecule", "document"],
                  max_abs_context_run_skill_vs_archived=check, max_abs_context_target_skill_vs_archived=target_check,
                  context_reproduces_archive=bool(check <= 1e-12 and target_check <= 1e-12))
    (out / "F8_STATUS.json").write_text(json.dumps(status, indent=2), encoding="utf8")
    print(json.dumps(status, indent=1))
    show = summ[(summ.view == "main")]
    print(show.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
