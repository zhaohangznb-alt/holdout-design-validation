"""F1 comparison: fresh full 680-case reproduction vs the archived predictions and analysis tables.
Protocol: PROTOCOL_ROUND2.md (section F1)."""
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from r2common import sha, save, read, stamp, csv

TOL = 1e-12


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle", type=Path, required=True)
    ap.add_argument("--fresh", type=Path, required=True, help="reproduce.py output directory")
    ap.add_argument("--output", type=Path, required=True)
    a = ap.parse_args()
    b, f, out = a.bundle.resolve(), a.fresh.resolve(), a.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    fm = read(b / "FILE_MANIFEST.json")
    rows = []
    for panel, run in [("kinase", "current_models"), ("nonkinase", "external_models")]:
        for ref in sorted((b / "results/predictions" / panel).glob("*.csv")):
            key = f"results/predictions/{panel}/{ref.name}"
            assert sha(ref) == fm[key], key
            new = f / run / ref.name
            rec = dict(panel=panel, case=ref.name, fresh_exists=new.exists())
            if new.exists():
                x, y = csv(new), csv(ref)
                rec["same_columns_and_rows"] = list(x.columns) == list(y.columns) and len(x) == len(y)
                if rec["same_columns_and_rows"]:
                    num = list(y.select_dtypes(include="number").columns)
                    oth = [c for c in y.columns if c not in num]
                    rec["non_numeric_identical"] = bool(x[oth].equals(y[oth]))
                    errs = {c: float(np.max(np.abs(x[c].to_numpy(float) - y[c].to_numpy(float)))) if len(y) else 0.0 for c in num}
                    rec["max_abs_numeric_difference"] = max(errs.values()) if errs else 0.0
                    rec["prediction_max_abs_difference"] = errs.get("prediction")
                    rec["byte_identical"] = sha(new) == sha(ref)
                    is_nn = "tanimoto1nn" in ref.name
                    rec["pass"] = bool(rec["non_numeric_identical"] and rec["max_abs_numeric_difference"] <= TOL and (not is_nn or errs.get("prediction") == 0.0))
                else:
                    rec["pass"] = False
            else:
                rec["pass"] = False
            rows.append(rec)
    df = pd.DataFrame(rows)
    df.to_csv(out / "f1_prediction_comparison.csv", index=False)
    tables = {}
    for name in ["target_metrics.csv", "contrast_summary.csv", "panel_summary.csv", "conditional_document_intervals.csv", "paired_model_intervals.csv", "target_route_contrasts.csv"]:
        p_new, p_old = f / "analysis" / name, b / "results/analysis" / name
        if p_new.exists() and p_old.exists():
            x, y = csv(p_new), csv(p_old)
            num = [c for c in y.select_dtypes(include="number").columns if c in x.columns]
            same_shape = x.shape == y.shape
            d = float(np.nanmax(np.abs(x[num].to_numpy(float) - y[num].to_numpy(float)))) if same_shape and num else None
            tables[name] = dict(same_shape=same_shape, max_abs_numeric_difference=d, byte_identical=sha(p_new) == sha(p_old))
        else:
            tables[name] = dict(missing_fresh=not p_new.exists(), missing_archived=not p_old.exists())
    steps = read(f / "steps.json") if (f / "steps.json").exists() else None
    complete = (f / "PIPELINE_COMPLETE.json").exists()
    status = "PASS" if complete and len(df) == 680 and df["pass"].all() else ("PARTIAL" if df.fresh_exists.any() and not (df.fresh_exists & ~df["pass"]).any() else "FAIL")
    summary = dict(status=status, compared=int(len(df)), fresh_present=int(df.fresh_exists.sum()), passed=int(df["pass"].sum()),
                   byte_identical=int(df.get("byte_identical", pd.Series(dtype=bool)).fillna(False).sum()),
                   max_prediction_difference=float(df["prediction_max_abs_difference"].max()) if "prediction_max_abs_difference" in df else None,
                   max_numeric_difference=float(df["max_abs_numeric_difference"].max()) if "max_abs_numeric_difference" in df else None,
                   tolerance=TOL, pipeline_complete=complete, steps=steps, analysis_tables=tables, compared_utc=stamp())
    save(out / "F1_COMPARISON.json", summary)
    print(json.dumps({k: v for k, v in summary.items() if k != "steps"}, indent=1, default=str))


if __name__ == "__main__":
    main()
