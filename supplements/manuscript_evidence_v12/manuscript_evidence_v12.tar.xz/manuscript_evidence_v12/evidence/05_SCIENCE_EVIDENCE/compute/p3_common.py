"""Phase-3 shared code: bundle imports, automated preparation (prepare_external.clean/split), model fitting and metrics."""
import json, sys, hashlib, time, gzip, io
from pathlib import Path
import numpy as np
import pandas as pd
from r2common import Featurizer, rf_model, ridge_fit_predict, nn_predict, save, read, stamp, sha, csv

SEEDS = [42, 53, 67]
ROUTES = ["source_exact", "source_scaffold", "temporal_exact", "temporal_scaffold"]
KINASE_IDS = {"alk": "CHEMBL4247", "braf": "CHEMBL5145", "egfr": "CHEMBL203", "erbb2": "CHEMBL1824", "kdr": "CHEMBL279", "met": "CHEMBL3717"}
ADDITIONAL_IDS = {"ache": "CHEMBL220", "dpp4": "CHEMBL284", "ptgs2": "CHEMBL230", "hdac1": "CHEMBL325", "pde4d": "CHEMBL288"}
CA2_ID = "CHEMBL205"
PUBLISHED_IDS = dict(KINASE_IDS, **ADDITIONAL_IDS)


def import_bundle(bundle):
    """Make the unchanged bundle modules importable (prepare_external imports fetch_external and runner)."""
    p = str(Path(bundle).resolve())
    if p not in sys.path:
        sys.path.insert(0, p)
    import prepare_external  # noqa: E402
    return prepare_external


def sig(f):
    return hashlib.sha256(f[["record_uid", "smiles", "target"]].to_csv(index=False).encode()).hexdigest()


def screen(pe, raw, symbol, tid):
    """EXTERNAL_PROTOCOL.md screening on clean()/split() output (Clarification C3). Returns (g, routes, cut, summary, flow)."""
    try:
        g, flow, summary = pe.clean(Path(raw), symbol, tid)
        routes, cut = pe.split(g)
    except Exception as e:  # recorded as a screening failure, never silently skipped
        return None, None, None, dict(target=symbol, target_id=tid, selected=False, failed_criteria="error:" + type(e).__name__ + ":" + str(e)[:200]), []
    reasons = []
    for check, ok in [("cleaned_records>=1500", summary["cleaned_activities"] >= 1500), ("molecules>=1000", summary["molecules"] >= 1000),
                      ("documents>=20", summary["documents"] >= 20), ("year_span>=10", summary["last_year"] - summary["first_year"] >= 10)]:
        if not ok:
            reasons.append(check)
    for r in ["source_exact", "temporal_exact"]:
        summary[r + "_test_contexts"] = len(routes[r]["test"])
        if len(routes[r]["test"]) < 100:
            reasons.append(r + "_test>=100")
    summary.update(selected=not reasons, failed_criteria=";".join(reasons))
    summary.update({"training_through": cut["training_through"], "validation_through": cut["validation_through"]})
    return g, routes, cut, summary, flow


def write_partitions(out, symbol, routes, scenarios=("revised", "single_protein")):
    """Write the broad/operational partitions exactly as prepare_external.main does; return split-manifest rows."""
    rows, unavailable = [], []
    for scenario in scenarios:
        for route, parts in routes.items():
            p = {n: (x if scenario == "revised" else x[x.operational_eligible]).copy() for n, x in parts.items()}
            if not all(len(x) > 0 for x in p.values()):
                unavailable.append(dict(target=symbol, scenario=scenario, route=route, reason="empty partition")); continue
            for part, x in p.items():
                dest = Path(out) / "data/main" / f"{scenario}_{symbol}_{route}_{part}.csv"
                dest.parent.mkdir(parents=True, exist_ok=True); x.to_csv(dest, index=False)
                y = pd.read_csv(dest)
                rows.append(dict(view="main", scenario=scenario, target=symbol, route=route, partition=part, corrected_csv=dest.name,
                                 corrected_sha256=sha(dest), corrected_rows=len(x), corrected_ordered_signature=sig(y),
                                 below_100_test=part == "test" and len(x) < 100))
    return rows, unavailable


def load_partitions(root, split_manifest, strict_sig=True):
    """Read partitions listed in a split manifest with hash, row-count and (optionally) ordered-signature checks."""
    s = pd.read_csv(split_manifest)
    frames = {}
    for r in s.itertuples():
        p = Path(root) / "data" / str(r.view) / str(r.corrected_csv).replace("\\", "/").rsplit("/", 1)[-1]
        assert sha(p) == r.corrected_sha256, p
        f = pd.read_csv(p)
        assert len(f) == r.corrected_rows, p
        if strict_sig:
            assert sig(f) == r.corrected_ordered_signature, p
        frames[(r.view, r.scenario, r.target, r.route, r.partition)] = f
    return frames


def roundtrip(df, dest):
    """Freeze a model-input table as CSV and read it back (the frozen CSV is the model input, as in prepare_external)."""
    dest = Path(dest); dest.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(dest, index=False)
    return pd.read_csv(dest)


def metrics(y, p, mean):
    mse = float(np.mean((y - p) ** 2)); base = float(np.mean((y - mean) ** 2))
    return dict(mse_model=mse, mse_mean=base, rmse_model=float(np.sqrt(mse)), rmse_mean=float(np.sqrt(base)),
                mae_model=float(np.mean(np.abs(y - p))), mae_mean=float(np.mean(np.abs(y - mean))), skill=1 - mse / base if base > 0 else None)


def fit_context(feat, train, tests, cfg_rf, n_jobs, models=("rf", "ridge", "tanimoto1nn"), predictions=None):
    """Fit the fixed models once on `train` and score every test set in `tests` (dict name -> frame).
    Returns metric records (RF: one per seed). If `predictions` is a list, prediction rows are appended to it."""
    Xtr = feat.matrix(train.smiles); ytr = train.target.to_numpy(float)
    mean = float(ytr.mean())
    Xte = {k: feat.matrix(v.smiles) for k, v in tests.items() if len(v)}
    out = []
    for model in models:
        for seed in (SEEDS if model == "rf" else [0]):
            t0 = time.time()
            if model == "rf":
                m = rf_model(cfg_rf, seed, n_jobs).fit(Xtr, ytr)
            fit_s = time.time() - t0
            for name, test in tests.items():
                if not len(test):
                    out.append(dict(test_set=name, model=model, seed=seed, train_rows=len(train), test_rows=0, training_mean=mean)); continue
                t1 = time.time()
                if model == "rf":
                    pred = m.predict(Xte[name])
                elif model == "ridge":
                    pred = ridge_fit_predict(Xtr, ytr, Xte[name])
                else:
                    pred = nn_predict(Xtr, ytr, Xte[name])
                yte = test.target.to_numpy(float)
                assert np.isfinite(pred).all()
                out.append(dict(test_set=name, model=model, seed=seed, train_rows=len(train), test_rows=len(test), training_mean=mean,
                                fit_seconds=fit_s + time.time() - t1, **metrics(yte, pred, mean)))
                if predictions is not None:
                    predictions.append(pd.DataFrame(dict(test_set=name, model=model, seed=seed, record_uid=test.record_uid.to_numpy(),
                                                         target=yte, prediction=pred)))
    return out


def write_predictions(frames, dest):
    """Gzip CSV with a fixed mtime so the bytes depend only on the content."""
    dest = Path(dest); dest.parent.mkdir(parents=True, exist_ok=True)
    body = pd.concat(frames, ignore_index=True).to_csv(index=False).encode()
    with open(dest, "wb") as fh, gzip.GzipFile(fileobj=fh, mode="wb", mtime=0) as gz:
        gz.write(body)
    return sha(dest)


def target_level(runs, keys):
    """Three-seed median for RF, the single value for Ridge/1-NN (as in the published analysis)."""
    return runs.groupby(keys + ["model"], dropna=False).agg(
        skill=("skill", "median"), mse_model=("mse_model", "median"), mse_mean=("mse_mean", "first"),
        test_rows=("test_rows", "first"), train_rows=("train_rows", "first")).reset_index()


def route_contrasts(target_skills, idx):
    piv = target_skills.pivot_table(index=idx, columns="route", values="skill").reset_index()
    for a, b, n in [("temporal_exact", "source_exact", "ye_minus_se"), ("source_scaffold", "source_exact", "ss_minus_se"),
                    ("temporal_scaffold", "temporal_exact", "ys_minus_ye")]:
        if {a, b} <= set(piv.columns):
            piv[n] = piv[a] - piv[b]
    return piv
