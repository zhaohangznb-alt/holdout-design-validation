"""Shared helpers for the round-2 analyses (see PROTOCOL_ROUND2.md)."""
import os
for _k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_k, "1")
import hashlib, json, platform, sys, datetime
from pathlib import Path
import numpy as np
import pandas as pd

PINNED = {"python": "3.9.10", "numpy": "2.0.2", "pandas": "2.3.3", "sklearn": "1.6.1", "rdkit": "2025.09.2"}
TARGETS = ["alk", "braf", "egfr", "erbb2", "kdr", "met", "ache", "dpp4", "ptgs2", "hdac1", "pde4d"]
KINASES = TARGETS[:6]


def panel_of(t):
    return "kinase" if t in KINASES else "nonkinase"


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, obj):
    p = Path(p)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=float), encoding="utf8")
    tmp.replace(p)


def read(p):
    return json.loads(Path(p).read_text(encoding="utf8"))


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def environment(test_mode):
    import sklearn
    env = {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
           "sklearn": sklearn.__version__, "platform": platform.platform(), "executable": sys.executable}
    try:
        import rdkit
        env["rdkit"] = rdkit.__version__
    except ImportError:
        env["rdkit"] = None
    if not test_mode:
        bad = {k: (env.get(k), v) for k, v in PINNED.items() if env.get(k) != v}
        assert not bad, f"Environment differs from the pinned versions: {bad}"
    env["mode"] = "TEST_FAKE_FEATURES_NOT_A_RESULT" if test_mode else "pinned_real"
    return env


class Featurizer:
    """Binary Morgan fingerprints (radius 2, 2048 bits, no chirality) cached per SMILES string.
    fake=True is ONLY for logic tests in environments without RDKit; its outputs are never results."""

    def __init__(self, cfg_fp, fake=False):
        self.fake = fake
        self.cache = {}
        if not fake:
            from rdkit import Chem
            from rdkit.Chem import rdFingerprintGenerator
            self.Chem = Chem
            self.gen = rdFingerprintGenerator.GetMorganGenerator(**cfg_fp)
        self.nbits = cfg_fp["fpSize"]

    def one(self, s):
        if s not in self.cache:
            if self.fake:
                rng = np.random.RandomState(int(hashlib.md5(s.encode()).hexdigest()[:8], 16))
                self.cache[s] = (rng.rand(self.nbits) < 0.05).astype(np.uint8)
            else:
                mol = self.Chem.MolFromSmiles(s)
                assert mol is not None, s
                self.cache[s] = self.gen.GetFingerprintAsNumPy(mol).astype(np.uint8)
        return self.cache[s]

    def matrix(self, smiles):
        return np.stack([self.one(s) for s in smiles])


def rf_model(cfg_rf, seed, n_jobs):
    from sklearn.ensemble import RandomForestRegressor
    return RandomForestRegressor(**dict(cfg_rf, n_jobs=n_jobs, random_state=seed))


def csv(p):
    return pd.read_csv(p, float_precision="round_trip")


def ridge_fit_predict(Xtr, ytr, Xte):
    """Archived Ridge: alpha 1, intercept, lsqr, tol 1e-4, max_iter 10000, sparse float64 input (runner.py)."""
    from scipy.sparse import csr_matrix
    from sklearn.linear_model import Ridge
    m = Ridge(alpha=1.0, fit_intercept=True, solver="lsqr", tol=1e-4, max_iter=10000)
    m.fit(csr_matrix(Xtr, dtype=np.float64), ytr)
    return m.predict(csr_matrix(Xte, dtype=np.float64))


def nn_predict(Xtr, ytr, Xte):
    """Archived 1-NN: binary Tanimoto, first maximum in original training order, zero-union similarity 1 (runner.first_nn)."""
    a = Xtr.astype(np.int32)
    na = a.sum(1)
    out = np.empty(len(Xte))
    for j, x in enumerate(Xte.astype(np.int32)):
        inter = a @ x
        union = na + x.sum() - inter
        sim = np.divide(inter, union, out=np.ones(len(a), dtype=float), where=union != 0)
        out[j] = ytr[int(np.argmax(sim))]
    return out
