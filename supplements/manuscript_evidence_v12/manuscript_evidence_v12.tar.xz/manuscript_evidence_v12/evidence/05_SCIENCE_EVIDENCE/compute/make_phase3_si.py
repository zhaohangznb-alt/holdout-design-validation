"""Generate S27-S29 from the corrected summaries; no fitting."""
from pathlib import Path
import json
import pandas as pd
ROOT=Path(__file__).resolve().parent
C=ROOT.parent/'results/p3/corrected';P=ROOT.parent/'results/p3'
A=json.loads((C/'P3A_SUMMARY.json').read_text());B=json.loads((C/'P3B_SUMMARY.json').read_text());D=json.loads((C/'P3C_SUMMARY.json').read_text())
NAMES={'rf':'RF','dmpnn':'D-MPNN','ridge':'Ridge','tanimoto1nn':'1-NN'}
R=['source_exact','source_scaffold','temporal_exact','temporal_scaffold']
S=[]
def add(t):S.append(t)
def fmt(v):return f'{float(v):.3f}'
def interval(x):return fmt(x['median'])+' ['+fmt(x['ci'][0])+', '+fmt(x['ci'][1])+']'
def esc(s):
    return str(s).replace('&',r'\&').replace('_',r'\_').replace('%',r'\%').replace('#',r'\#')
def table(spec,head,rows,caption=None,label=None):
    add(r'\begin{longtable}{'+spec+'}')
    if caption:add(r'\caption{'+caption+'}'+(r'\label{'+label+'}' if label else '')+r'\\')
    add(r'\toprule');add(' & '.join(head)+r' \\');add(r'\midrule\endfirsthead')
    add(r'\toprule');add(' & '.join(head)+r' \\');add(r'\midrule\endhead')
    for row in rows:add(' & '.join(map(str,row))+r' \\')
    add(r'\bottomrule\end{longtable}')

add(r'''\clearpage
\section*{Table S27 D-MPNN on the archived partitions}

The additional analyses in Tables S27--S29 were specified in the written phase-3 protocol before their data preparation and fitting. The current D-MPNN extension uses the archived main-view partitions of the six kinases and five additional targets, each in broad and operational cohorts: 11 targets, 22 target--cohort combinations and 88 route contexts. It is separate from the historical D-MPNN material in Table S8. Chemprop 2.2.4 uses directed bond messages, hidden width 300, depth three, dropout zero, mean aggregation, a one-hidden-layer readout of width 300, batch size 64 and the default Noam learning-rate schedule. Training-label standardisation is fitted only on training rows. Early stopping uses validation MSE, patience ten and at most 50 epochs; the best-validation weights are retained in memory for test prediction. Batch normalisation is off. Seeds are 42, 53 and 67, producing 264 completed runs. RF uses its archived three-seed medians on the same route test rows and matching training-mean comparator. D-MPNN uses validation labels for early stopping, whereas RF does not use validation labels for selection.

Model values first use the seed median within each target--cohort--route context. Route medians and within-target contrast medians are then computed separately over 22 combinations. The 95\% percentile intervals for the contrast medians resample whole targets, retaining both cohorts of each sampled target (10,000 resamples, seed 20261004). Counts refer to target--cohort combinations, not independent targets. Per-cohort summaries and absolute model/baseline errors are given below.

The recorded environment is Python 3.11.16, Chemprop 2.2.4, PyTorch 2.6.0+cu124, Lightning 2.6.6 and RDKit 2026.03.6 on an RTX 4070 Laptop GPU. GPU computation is not configured for deterministic cuDNN execution. Partitions retain SHA-256 and row-count equality; all 264 partition files match their recorded SHA-256 hashes and row counts (264/264). The pandas-dependent ordered signature matches for 230/264 files; protocol C9 records these signatures without requiring equality across pandas versions.

\begingroup\footnotesize\setlength{\LTpre}{3pt}\setlength{\LTpost}{3pt}\setlength{\tabcolsep}{4pt}
\renewcommand{\thetable}{S27}''')
table('lrrrr',['Model','SE','SS','YE','YS'],[[NAMES[m]]+[fmt(A['by_model'][m]['route_median_skill'][r]) for r in R] for m in ['rf','dmpnn']],
      'Route-specific median skill. SE/SS denote source exact/scaffold and YE/YS year exact/scaffold.','tab:S27')
table('llll',['Model',r'YE$-$SE [95\% PI]',r'SS$-$SE [95\% PI]','Lower YE'],
      [[NAMES[m],interval(A['by_model'][m]['ye_minus_se']),interval(A['by_model'][m]['ss_minus_se']),str(A['by_model'][m]['ye_minus_se']['negative_combinations'])+'/22'] for m in ['rf','dmpnn']])
table('llrr',['Model','Cohort',r'Median YE$-$SE','Lower YE'],
      [[NAMES[m],'Broad' if s=='revised' else 'Operational',fmt(x['ye_minus_se']),str(x['negative'])+'/11'] for m in ['rf','dmpnn'] for s,x in A['by_model'][m]['by_cohort'].items()])
d=pd.read_csv(P/'dmpnn/dmpnn_runs.csv');rf=pd.read_csv(ROOT/'archived_rf_target_metrics.csv');rf=rf[(rf.view=='main')&(rf.model=='rf')]
rows=[]
for m,df in [('rf',rf),('dmpnn',d)]:
    x=df.groupby(['scenario','target','route'],as_index=False)[['mse_model','mse_mean','mae_model','mae_mean']].median()
    for route,ab in zip(R,['SE','SS','YE','YS']):
        z=x[x.route==route]; rows.append([NAMES[m],ab]+[fmt(z[col].median()) for col in ['mse_model','mse_mean','mae_model','mae_mean']])
add('Absolute-error summaries are metric-wise medians over the same 22 contexts. MSE is in squared pIC50 units and MAE in pIC50 units; baseline denotes the corresponding training mean.')
table('llrrrr',['Model','Route','Model MSE','Baseline MSE','Model MAE','Baseline MAE'],rows)
add(r'\endgroup')

add(r'''\clearpage
\section*{Table S28 Extended stratified target panel}

The ChEMBL 37 sampling frame contains 160 human single-protein targets passing SQL-filtered counts of at least 1,500 exact-relation standard IC\textsubscript{50} records, 1,000 distinct molregno identifiers, 20 documents and a ten-year document-year span, excluding the original eleven targets and CA2. These frame counts precede the full external cleaning and canonical-SMILES screen. Protein classification assigns nine strata. Sorted target identifiers are permuted within each stratum with NumPy default\_rng(20261004 plus the stratum index); the first five candidates passing the full screen are selected, including at least 100 test contexts in both exact routes. Eight strata supply five targets each, and Other supplies two. Forty-four candidates were screened; CHEMBL1904 and CHEMBL4979 failed the source-exact test-size threshold and were replaced by the next passing candidates in their recorded order.

Selection is score-blind. The selection list and preparation hashes were frozen at 02:36:25 UTC on 5 October 2026, before the recorded panel fitting start at 02:52:25 UTC. All targets use the automated eligibility, aggregation and splitting rules of the additional-target protocol, without manual source auditing. The three fixed models use the same specifications as the earlier extension; RF uses seeds 42, 53 and 67. All 168 broad target--route contexts are available. The operational cohort has 147 of 168 possible contexts; empty training, validation or test partitions account for 21 unavailable routes, listed below. The completed evaluations comprise 1,575 model--seed records across 315 available contexts.

The primary summary gives every selected target equal weight. Percentile intervals use 10,000 bootstrap resamples of targets within their strata (seed 20261004). They describe this selected stratified panel, without population weighting to all ChEMBL targets. Operational contrasts use only targets with both compared routes available. The proportion intervals use Wilson's formula and are reported separately from the stratified bootstrap.

\begingroup\footnotesize\setlength{\LTpre}{3pt}\setlength{\LTpost}{3pt}\setlength{\tabcolsep}{4pt}
\renewcommand{\thetable}{S28}''')
rows=[]
for s in ['revised','single_protein']:
    for m in ['rf','ridge','tanimoto1nn']:
        x=B['results'][s+'__'+m]['ye_minus_se'];lo,hi=x['proportion_lower_wilson']
        rows.append(['Broad' if s=='revised' else 'Operational',NAMES[m],interval(x['stratified']),str(x['n_negative'])+'/'+str(x['n']),f'[{fmt(lo)}, {fmt(hi)}]'])
table('lllll',['Cohort','Model',r'Median YE$-$SE [95\% PI]','Lower YE','Proportion [95\% CI]'],rows,
      'Year-exact minus source-exact skill across the selected panel. RF first uses the three-seed median.','tab:S28')
by=B['results']['revised__rf']['ye_minus_se']['stratum_median']
table('lrr',['Stratum','Selected targets',r'RF median YE$-$SE'],[[esc(s),B['by_stratum'][s],fmt(by[s])] for s in ['Kinase','Protease','Other enzyme','Membrane receptor','Ion channel','Transcription factor','Epigenetic regulator','Transporter','Other']])
freeze=json.loads((P/'panel/PANEL_SELECTION_FROZEN.json').read_text());sel=pd.DataFrame(freeze['selected'])
rc=pd.read_csv(P/'panel/panel_runs.csv');rc=rc[(rc.scenario=='revised')&(rc.model=='rf')&(rc.seed==42)]
rows=[]
for t in freeze['selected']:
    q=rc[rc.target==t['symbol']].set_index('route')
    rows.append([t['target_chembl_id'],esc(t['pref_name']),esc(t['stratum']),int(q.loc['source_exact','test_rows']),int(q.loc['temporal_exact','test_rows'])])
selected_rows=rows
missing=pd.DataFrame(freeze['unavailable']); rows=[]
for target,g in missing.groupby('target'):
    rows.append([target.upper(),', '.join({'source_exact':'SE','source_scaffold':'SS','temporal_exact':'YE','temporal_scaffold':'YS'}[v] for v in g.route)])
add('Unavailable operational routes all arise from an empty partition. These exclusions do not remove any broad-cohort result.')
table('ll',['Target','Unavailable operational routes'],rows)
add(r'\clearpage')
add('Selected target identifiers, names and broad-cohort exact-route test-context counts:')
table('p{2.6cm}p{5.3cm}p{2.8cm}rr',['ChEMBL ID','Target name','Stratum','SE n','YE n'],selected_rows)
add(r'\endgroup')

add(r'''\clearpage
\section*{Table S29 Cross-release evaluation from ChEMBL 36 to 37}

Each of the original eleven targets is prepared independently from ChEMBL 36 and 37 with the same automated broad-cohort rules; the six kinases here are not the curated primary cohorts. A release-forward model trains on all retained ChEMBL 36 contexts and is evaluated on ChEMBL 37 contexts from documents absent from that target's filtered ChEMBL 36 export before cleaning. Exact-tier test rows exclude training canonical structures; the scaffold tier additionally excludes training Murcko scaffolds. New-document counts below precede these exclusions. Some newly added records refer to earlier publications, including 2021 documents for EGFR. This is a historical database-release evaluation, rather than prospective experimental collection or database-wide document novelty.

Internal source/document-year routes are constructed from ChEMBL 36 alone and evaluated on their own route test rows. Each model uses its matching training-mean baseline. RF values aggregate only seeds 42, 53 and 67; Ridge and 1-NN are shown separately. Agreement means the absolute skill discrepancy between each internal route and its corresponding release-forward tier: exact with exact, scaffold with scaffold. Training populations, test populations and baseline means differ between designs. These discrepancies describe one release transition and do not identify a causal advantage of a splitting strategy.

All eleven targets are shown. BRAF and ERBB2 have fewer than 30 release-forward exact-tier contexts ($\dagger$) and are excluded from all cross-target medians. MET has 30 exact and 16 scaffold contexts and meets the prespecified exact-tier threshold.

\begingroup\footnotesize\setlength{\LTpre}{3pt}\setlength{\LTpost}{3pt}\setlength{\tabcolsep}{3pt}
\renewcommand{\thetable}{S29}''')
rf=pd.read_csv(C/'p3c_per_target_rf.csv');order=['alk','braf','egfr','erbb2','kdr','met','ache','dpp4','ptgs2','hdac1','pde4d'];rf=rf.set_index('target').loc[order]
rows=[]
for t,x in rf.iterrows():
    rows.append([t.upper()+(r'$^{\dagger}$' if x.below_min_exact else ''),int(x.test_exact_contexts),int(x.new_documents)]+[fmt(x[c]) for c in ['release_forward_exact_skill','internal_source_exact_skill','internal_temporal_exact_skill','agree_source_exact','agree_temporal_exact']])
table('lrrrrrrr',['Target','Exact n','New docs','Forward','Internal SE','Internal YE','SE gap','YE gap'],rows,
      'RF exact-tier release-forward skill and internal-route discrepancies. New docs are defined within the filtered target export.','tab:S29')
rows=[]
for t,x in rf.iterrows():
    rows.append([t.upper()+(r'$^{\dagger}$' if x.below_min_exact else ''),int(x.test_scaffold_contexts)]+[fmt(x[c]) for c in ['release_forward_scaffold_skill','internal_source_scaffold_skill','internal_temporal_scaffold_skill','agree_source_scaffold','agree_temporal_scaffold']])
table('lrrrrrr',['Target','Scaffold n','Forward','Internal SS','Internal YS','SS gap','YS gap'],rows)
rows=[]
for m in ['rf','ridge','tanimoto1nn']:
    x=D['by_model'][m];rows.append([NAMES[m],fmt(x['median_release_forward_exact_skill']),fmt(x['median_release_forward_exact_mae'])]+[fmt(x['agreement_median'][r]) for r in R])
add('Cross-target medians over the nine eligible targets. Forward skill and MAE use the exact tier; each discrepancy uses its matching tier. MAE is in pIC50 units.')
table('lrrrrrr',['Model','Forward skill','Forward MAE','SE gap','SS gap','YE gap','YS gap'],rows)
add(r'\endgroup')


(C/'si_tables_S27_S29.tex').write_text('\n\n'.join(S)+'\n',encoding='utf-8')
print('Generated corrected S27-S29,',len(rows),'last-table rows')
