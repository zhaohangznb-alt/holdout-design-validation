"""F2: training-resampling (whole-document bootstrap) uncertainty for RF skill and the YE-SE paired change.
Protocol: PROTOCOL_ROUND2.md (section F2). Checkpointed per fit; restartable; no model binaries kept."""
import argparse, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from r2common import TARGETS, panel_of, sha, save, read, stamp, environment, Featurizer, rf_model, csv

ROUTES = ["source_exact", "temporal_exact"]


def load(snapshot, bundle):
    ih = read(snapshot / "INPUT_HASHES.json")
    fm = read(bundle / "FILE_MANIFEST.json")
    cfg = read(snapshot / "MODEL_CONFIG.json")
    data = {}
    for t in TARGETS:
        for route in ROUTES:
            trf = f"inputs/train_{t}_{route}_full.csv"
            assert sha(snapshot / trf) == ih[trf], trf
            tr = csv(snapshot / trf)
            tef = f"results/predictions/{panel_of(t)}/main_revised_{t}_{route}_rf_42.csv"
            assert sha(bundle / tef) == fm[tef], tef
            te = csv(bundle / tef)[["record_uid", "smiles", "target", "document_chembl_id", "training_mean"]]
            assert abs(te.training_mean.iloc[0] - tr.target.mean()) <= 1e-9, (t, route)
            assert not set(te.record_uid) & set(tr.record_uid)
            data[t, route] = (tr, te)
    return cfg, data


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--snapshot", type=Path, required=True, help="extracted controlled_comparison/ directory")
    ap.add_argument("--bundle", type=Path, required=True, help="extracted verified bundle/ directory")
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--replicates", type=int, default=20)
    ap.add_argument("--n-jobs", type=int, default=-1)
    ap.add_argument("--targets", default=",".join(TARGETS))
    ap.add_argument("--fake-features", action="store_true", help="TEST ONLY: random features, never a result")
    ap.add_argument("--summarize-only", action="store_true")
    ap.add_argument("--seed-mode", choices=["fixed42", "cycle"], default="fixed42", help="cycle = RF random_state (42, 53, 67)[b % 3] (Amendment A3)")
    a = ap.parse_args()
    out = a.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "fits").mkdir(exist_ok=True)
    env = environment(a.fake_features)
    cfg, data = load(a.snapshot.resolve(), a.bundle.resolve())
    targets = a.targets.split(",")
    if not a.summarize_only:
        save(out / f"command_{time.time_ns()}.json", dict(argv=sys.argv, started=stamp(), environment=env))
        feat = Featurizer(cfg["fingerprint"], fake=a.fake_features)
        X = {k: (feat.matrix(tr.smiles), tr.target.to_numpy(float), feat.matrix(te.smiles), te.target.to_numpy(float)) for k, (tr, te) in data.items() if k[0] in targets}
        for b in range(a.replicates):
            for i, t in enumerate(TARGETS):
                if t not in targets:
                    continue
                for r, route in enumerate(ROUTES):
                    rec_p = out / "fits" / f"{t}_{route}_b{b:02d}.json"
                    if rec_p.exists():
                        continue
                    tr, te = data[t, route]
                    Xtr, ytr, Xte, yte = X[t, route]
                    docs = tr.document_chembl_id.to_numpy()
                    udocs = np.array(sorted(set(docs)))
                    rng = np.random.RandomState(20261004 + 1000 * b + 10 * i + r)
                    drawn = rng.choice(len(udocs), size=len(udocs), replace=True)
                    rows = np.concatenate([np.flatnonzero(docs == udocs[d]) for d in drawn])
                    t0 = time.time()
                    rf_seed = 42 if a.seed_mode == "fixed42" else (42, 53, 67)[b % 3]
                    m = rf_model(cfg["rf"], rf_seed, a.n_jobs).fit(Xtr[rows], ytr[rows])
                    pred = m.predict(Xte)
                    mean = float(ytr[rows].mean())
                    mse = float(np.mean((yte - pred) ** 2))
                    base = float(np.mean((yte - mean) ** 2))
                    save(rec_p, dict(target=t, panel=panel_of(t), route=route, replicate=b, rng_seed=20261004 + 1000 * b + 10 * i + r,
                                     rf_random_state=rf_seed, train_rows=int(len(rows)), train_documents=int(len(udocs)),
                                     unique_documents_drawn=int(len(set(drawn))), test_rows=int(len(yte)), training_mean=mean,
                                     mse_rf=mse, mse_mean=base, skill=1 - mse / base, fit_seconds=time.time() - t0,
                                     mode=env["mode"], completed=stamp()))
                    print("DONE", rec_p.name, round(time.time() - t0, 1), "s", flush=True)
    summarize(out, data, targets, env, a.replicates)


def summarize(out, data, targets, env, planned):
    recs = pd.DataFrame([read(p) for p in sorted((out / "fits").glob("*.json"))])
    if recs.empty:
        print("no fits yet"); return
    recs.to_csv(out / "f2_replicate_fits.csv", index=False)
    complete_b = [b for b in sorted(recs.replicate.unique()) if len(recs[recs.replicate == b]) == 2 * len(targets)]
    use = recs[recs.replicate.isin(complete_b)]
    piv = use.pivot_table(index=["panel", "target", "replicate"], columns="route", values="skill").reset_index()
    piv["d_ye_minus_se"] = piv.temporal_exact - piv.source_exact
    rows = []
    for (panel, t), g in piv.groupby(["panel", "target"]):
        q = lambda s: np.quantile(s, [0.025, 0.5, 0.975]) if len(s) else [np.nan] * 3
        rows.append(dict(panel=panel, target=t, replicates=len(g),
                         se_skill_p2_5=q(g.source_exact)[0], se_skill_median=q(g.source_exact)[1], se_skill_p97_5=q(g.source_exact)[2],
                         ye_skill_p2_5=q(g.temporal_exact)[0], ye_skill_median=q(g.temporal_exact)[1], ye_skill_p97_5=q(g.temporal_exact)[2],
                         d_p2_5=q(g.d_ye_minus_se)[0], d_median=q(g.d_ye_minus_se)[1], d_p97_5=q(g.d_ye_minus_se)[2],
                         fraction_d_negative=float((g.d_ye_minus_se < 0).mean())))
    tgt = pd.DataFrame(rows)
    tgt.to_csv(out / "f2_target_summary.csv", index=False)
    pan = []
    for panel, g in piv.groupby("panel"):
        med = g.groupby("replicate").d_ye_minus_se.median()
        pan.append(dict(panel=panel, replicates=len(med), median_paired_change_p2_5=float(np.quantile(med, .025)) if len(med) else None,
                        median_paired_change_median=float(np.median(med)) if len(med) else None,
                        median_paired_change_p97_5=float(np.quantile(med, .975)) if len(med) else None,
                        fraction_replicates_panel_median_negative=float((med < 0).mean()) if len(med) else None))
    pd.DataFrame(pan).to_csv(out / "f2_panel_summary.csv", index=False)
    save(out / "F2_STATUS.json", dict(completed_fits=int(len(recs)), complete_replicates=len(complete_b), targets=targets,
                                      planned_replicates_per_target_route=planned, mode=env["mode"], summarized=stamp()))
    print(tgt.round(3).to_string(index=False)); print(pd.DataFrame(pan).round(3).to_string(index=False))


if __name__ == "__main__":
    main()
