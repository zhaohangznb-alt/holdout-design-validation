"""P3-B: extended, stratified target panel with automated eligibility (PROTOCOL_PHASE3.md, Clarifications C1-C3).
  frame  : SQL frame on the ChEMBL 37 working extract -> thresholds, exclusions, strata, seeded per-stratum order
  screen : walk each stratum's order; export -> clean() -> split() -> EXTERNAL_PROTOCOL screen; first 5 passing targets per
           stratum are selected; partitions written; selection frozen (hashes) BEFORE any fit
  fit    : RF (3 seeds), Ridge, 1-NN on broad ('revised') and operational ('single_protein') cohorts x 4 routes; restartable
"""
import argparse, json, time
from pathlib import Path
import numpy as np
import pandas as pd
from r2common import Featurizer, save, read, stamp, sha, environment
from p3_common import PUBLISHED_IDS, CA2_ID, ROUTES, import_bundle, screen, write_partitions, load_partitions, fit_context, write_predictions
from p3_chembl import frame, export_target, STRATA

PER_STRATUM = 5
BASE_SEED = 20261004
THRESH = dict(n_activities=1500, n_molregno=1000, n_documents=20, year_span=10)


def cmd_frame(a):
    out = a.output.resolve(); out.mkdir(parents=True, exist_ok=True)
    f = pd.DataFrame(frame(a.work37))
    f["year_span"] = f.last_year - f.first_year
    f["meets_counts"] = (f.n_activities >= THRESH["n_activities"]) & (f.n_molregno >= THRESH["n_molregno"]) & \
                        (f.n_documents >= THRESH["n_documents"]) & (f.year_span >= THRESH["year_span"])
    excluded = set(PUBLISHED_IDS.values()) | {CA2_ID}
    f["excluded_published_or_ca2"] = f.target_chembl_id.isin(excluded)
    f = f.sort_values("target_chembl_id").reset_index(drop=True)
    f.to_csv(out / "frame_all.csv", index=False)
    el = f[f.meets_counts & ~f.excluded_published_or_ca2].copy()
    el.to_csv(out / "frame_eligible.csv", index=False)
    order = []
    for i, s in enumerate(STRATA):
        ids = np.array(sorted(el.loc[el.stratum == s, "target_chembl_id"]))
        perm = np.random.default_rng(BASE_SEED + i).permutation(len(ids)) if len(ids) else np.array([], dtype=int)
        for rank, tid in enumerate(ids[perm] if len(ids) else []):
            r = el[el.target_chembl_id == tid].iloc[0]
            order.append(dict(stratum=s, stratum_index=i, rank=rank, target_chembl_id=tid, pref_name=r.pref_name, n_activities=int(r.n_activities),
                              n_molregno=int(r.n_molregno), n_documents=int(r.n_documents), first_year=int(r.first_year), last_year=int(r.last_year),
                              class_l1=r.class_l1, class_l2=r.class_l2))
    pd.DataFrame(order).to_csv(out / "sampling_order.csv", index=False)
    rec = dict(frame_targets=len(f), eligible=len(el), by_stratum=el.stratum.value_counts().reindex(STRATA, fill_value=0).to_dict(),
               thresholds=THRESH, excluded=sorted(excluded), base_seed=BASE_SEED,
               files={n: sha(out / n) for n in ["frame_all.csv", "frame_eligible.csv", "sampling_order.csv"]},
               work37=str(a.work37), created=stamp())
    save(out / "FRAME_COMPLETE.json", rec)
    print(json.dumps(rec["by_stratum"]), "eligible", len(el), flush=True)


def cmd_screen(a):
    out = a.output.resolve()
    frozen = out / "PANEL_SELECTION_FROZEN.json"
    assert not frozen.exists(), "selection already frozen; screening is not repeated"
    fr = read(out / "FRAME_COMPLETE.json")
    assert sha(out / "sampling_order.csv") == fr["files"]["sampling_order.csv"]
    order = pd.read_csv(out / "sampling_order.csv")
    pe = import_bundle(a.bundle)
    raw, prep = out / "raw37", out / "prepared"
    log, split_rows, unavailable, selected, exports = [], [], [], [], {}
    for s in STRATA:
        n_sel = 0
        for r in order[order.stratum == s].sort_values("rank").itertuples():
            if n_sel >= PER_STRATUM:
                break
            sym = r.target_chembl_id.lower()
            t0 = time.time()
            ex = export_target(a.work37, r.target_chembl_id, raw / sym)
            exports[sym] = {p.name: sha(p) for p in sorted((raw / sym).glob("*.json"))}
            g, routes, cut, summ, flow = screen(pe, raw, sym, r.target_chembl_id)
            row = dict(stratum=s, rank=r.rank, symbol=sym, target_chembl_id=r.target_chembl_id, pref_name=r.pref_name, exported_activities=ex["activities"],
                       seconds=round(time.time() - t0, 1), **{k: v for k, v in summ.items() if k not in ("target", "target_id")})
            log.append(row)
            print(s, r.rank, sym, summ.get("selected"), summ.get("failed_criteria"), flush=True)
            if summ.get("selected"):
                n_sel += 1
                (prep / "screened_contexts").mkdir(parents=True, exist_ok=True)
                g.to_csv(prep / "screened_contexts" / f"{sym}.csv", index=False)
                rows, un = write_partitions(prep, sym, routes)
                split_rows += rows; unavailable += un
                selected.append(dict(stratum=s, rank=int(r.rank), symbol=sym, target_chembl_id=r.target_chembl_id, pref_name=r.pref_name,
                                     training_through=cut["training_through"], validation_through=cut["validation_through"]))
    pd.DataFrame(log).to_csv(out / "screen_log.csv", index=False)
    pd.DataFrame(split_rows).to_csv(prep / "split_manifest.csv", index=False)
    rec = dict(selected=selected, n_selected=len(selected), by_stratum=pd.DataFrame(selected).stratum.value_counts().reindex(STRATA, fill_value=0).to_dict() if selected else {},
               screened=len(log), unavailable=unavailable, selection_used_model_scores=False,
               files=dict(screen_log=sha(out / "screen_log.csv"), split_manifest=sha(prep / "split_manifest.csv"),
                          sampling_order=sha(out / "sampling_order.csv"), frame_record=sha(out / "FRAME_COMPLETE.json")),
               raw_export_hashes=exports, code_sha256={n: sha(Path(__file__).with_name(n)) for n in ["p3_panel.py", "p3_common.py", "p3_chembl.py"]},
               prepare_external_sha256=sha(Path(a.bundle) / "prepare_external.py"), frozen=stamp())
    save(frozen, rec)
    print("selected", len(selected), rec["by_stratum"], flush=True)


def cmd_fit(a):
    out = a.output.resolve()
    rec = read(out / "PANEL_SELECTION_FROZEN.json")
    prep = out / "prepared"
    assert sha(prep / "split_manifest.csv") == rec["files"]["split_manifest"], "split manifest changed after freezing"
    env = environment(a.test_mode)
    cfg = read(a.model_config)
    frames = load_partitions(prep, prep / "split_manifest.csv")
    fits = out / "fits"; fits.mkdir(exist_ok=True)
    keys = sorted({k[1:4] for k in frames})  # (scenario, target, route)
    order = {x["symbol"]: i for i, x in enumerate(rec["selected"])}
    keys.sort(key=lambda k: (order[k[1]], k[0], ROUTES.index(k[2])))
    feat, cur = None, None
    for scenario, sym, route in keys:
        dest = fits / f"{scenario}_{sym}_{route}.json"
        if dest.exists():
            continue
        if cur != sym:
            feat, cur = Featurizer(cfg["fingerprint"], fake=a.test_mode), sym
        train, test = frames[("main", scenario, sym, route, "train")], frames[("main", scenario, sym, route, "test")]
        preds = []
        t0 = time.time()
        recs = fit_context(feat, train, {"test": test}, cfg["rf"], a.n_jobs, predictions=preds)
        psha = write_predictions(preds, fits / f"{scenario}_{sym}_{route}.predictions.csv.gz")
        stratum = next(x["stratum"] for x in rec["selected"] if x["symbol"] == sym)
        save(dest, dict(scenario=scenario, target=sym, stratum=stratum, route=route, records=recs, predictions_sha256=psha,
                        seconds=round(time.time() - t0, 1), environment=env, finished=stamp()))
        print("FIT", scenario, sym, route, round(time.time() - t0, 1), "s", flush=True)
    rows = []
    for p in sorted(fits.glob("*.json")):
        d = read(p)
        for r in d["records"]:
            rows.append(dict(scenario=d["scenario"], target=d["target"], stratum=d["stratum"], route=d["route"], **r))
    pd.DataFrame(rows).to_csv(out / "panel_runs.csv", index=False)
    save(out / "PANEL_FIT_STATUS.json", dict(contexts_expected=len(keys), contexts_done=len(list(fits.glob("*.json"))), runs=len(rows),
                                             model_config_sha256=sha(a.model_config), environment=env, test_mode=a.test_mode, finished=stamp()))
    print("PANEL FIT COMPLETE", len(keys), flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    for n in ["frame", "screen", "fit"]:
        p = sp.add_parser(n)
        p.add_argument("--output", type=Path, required=True)
        p.add_argument("--work37", type=Path)
        p.add_argument("--bundle", type=Path)
        p.add_argument("--model-config", type=Path)
        p.add_argument("--n-jobs", type=int, default=-1)
        p.add_argument("--test-mode", action="store_true", help="fake features, unpinned environment: LOGIC TEST ONLY")
    a = ap.parse_args()
    dict(frame=cmd_frame, screen=cmd_screen, fit=cmd_fit)[a.cmd](a)
