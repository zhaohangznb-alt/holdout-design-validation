"""Portable R5 SI generator: corrected S27-S29 and registered post hoc S30.
Uses existing results; performs no fitting or new data extraction.
"""
from pathlib import Path
import runpy,json,re
import pandas as pd
COMPUTE=Path(__file__).resolve().parent
OUT=COMPUTE.parents[1]
P=COMPUTE.parent/'results/p3';C=P/'corrected'
runpy.run_path(str(COMPUTE/'make_phase3_si.py'),run_name='__main__')
block=(C/'si_tables_S27_S29.tex').read_text(encoding='utf-8');lines=block.splitlines();sec=None;count={}
for i,line in enumerate(lines):
 m=re.search(r'\\section\*\{Table (S\d+)',line)
 if m:sec=m[1];count[sec]=0
 if line.startswith(r'\begin{longtable}'):
  count[sec]+=1
  if not re.search(r'\\label\{([^}]+)\}','\n'.join(lines[i:i+6])):
   lines[i]=line+r'\noalign{\label{tab:'+sec+'_'+str(count[sec])+'}}'
block='\n'.join(lines)+'\n\n'
h=json.loads((P/'hierarchical/HIERARCHICAL_RESULTS.json').read_text());sh=pd.read_csv(P/'hierarchical/stratum_shrinkage.csv')
def f(x):return f'{float(x):.3f}'
def table(spec,head,rows,label):
 return '\n'.join([r'\begin{longtable}{'+spec+'}',r'\noalign{\label{'+label+'}}',r'\toprule',' & '.join(head)+r' \\',r'\midrule\endfirsthead',r'\toprule',' & '.join(head)+r' \\',r'\midrule\endhead']+[' & '.join(map(str,row))+r' \\' for row in rows]+[r'\bottomrule\end{longtable}'])+'\n\n'
block+=(COMPUTE/'s30_intro.tex').read_text(encoding='utf-8')
rows=[]
for x in h['fits']:
 rows.append(['Broad' if x['scenario']=='revised' else 'Operational','YE-SE' if x['contrast']=='ye_minus_se' else 'SS-SE',x['n_targets'],f(x['mean']),f"[{f(x['normal_ci_low'])}, {f(x['normal_ci_high'])}]",f(x['between_stratum_sd']),f(x['residual_sd'])])
block+=table('llrllll',['Cohort','Contrast','n','Mean','95\\% Wald CI','Class SD','Residual SD'],rows,'tab:S30')
rows=[[('Broad' if x['scenario']=='revised' else 'Operational'),('YE-SE' if x['contrast']=='ye_minus_se' else 'SS-SE'),f(x['mean_se']),f"[{f(x['t_sensitivity_low'])}, {f(x['t_sensitivity_high'])}]"] for x in h['fits']]
block+=table('llll',['Cohort','Contrast','Mean SE','Approximate 95\\% t interval'],rows,'tab:S30_2')
strata=['Kinase','Protease','Other enzyme','Membrane receptor','Ion channel','Transcription factor','Epigenetic regulator','Transporter','Other']
for sc,label in [('revised','tab:S30_3'),('single_protein','tab:S30_4')]:
 block+=('Broad' if sc=='revised' else 'Operational')+' cohort: complete-pair counts and shrunken class means.\n\n';rows=[]
 for st in strata:
  d=sh[(sh.scenario==sc)&(sh.stratum==st)].set_index('contrast');rows.append([st,int(d.loc['ye_minus_se','n_targets']),f(d.loc['ye_minus_se','shrunken_mean']),int(d.loc['ss_minus_se','n_targets']),f(d.loc['ss_minus_se','shrunken_mean'])])
 block+=table('lrlrl',['Stratum','YE-SE n','YE-SE mean','SS-SE n','SS-SE mean'],rows,label)
block+=r'\endgroup'+'\n'
target=OUT/'build/round5/si_tables_S27_S30.tex';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(block,encoding='utf-8')
print('R5 S27-S30 generated:',target)
