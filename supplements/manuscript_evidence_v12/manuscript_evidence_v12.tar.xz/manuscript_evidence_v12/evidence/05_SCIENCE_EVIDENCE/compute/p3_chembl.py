"""Phase 3 (PROTOCOL_PHASE3.md): ChEMBL SQLite helpers.
- build_workdb(): read-only pass over a release file -> small working extract (Clarification C1): the activity rows with
  standard_type = IC50, standard_relation = '=', standard_flag = 1 (the archived API request) and the columns the exporter uses.
- export_target(): writes records with the field names of the ChEMBL REST responses read by bundle/prepare_external.py
  (activities_000000.json / assays_000000.json / target.json), mirroring the archived API request.
- frame(): SQL counts after database-level cleaning for all human SINGLE PROTEIN targets, with protein-class strata (C2).
Usage (PC):  python p3_chembl.py build --src <chembl_37.db> --work <p3_work_37.db>
"""
import argparse, json, sqlite3, hashlib, time, datetime
from pathlib import Path

ACT_SQL = """
SELECT act.activity_id, act.record_id, md.chembl_id AS molecule_chembl_id, cs.canonical_smiles,
       a.chembl_id AS assay_chembl_id, d.chembl_id AS document_chembl_id, d.year AS document_year,
       act.pchembl_value, act.potential_duplicate, act.data_validity_comment, act.standard_flag,
       act.standard_relation, act.standard_type, act.standard_units, act.standard_value,
       td.chembl_id AS target_chembl_id, td.organism AS target_organism
FROM act
JOIN assays a ON act.assay_id = a.assay_id
JOIN target_dictionary td ON a.tid = td.tid
LEFT JOIN docs d ON act.doc_id = d.doc_id
LEFT JOIN molecule_dictionary md ON act.molregno = md.molregno
LEFT JOIN compound_structures cs ON act.molregno = cs.molregno
WHERE td.chembl_id = ? AND act.standard_type = 'IC50' AND act.standard_relation = '=' AND act.standard_flag = 1
ORDER BY act.activity_id
"""
ASSAY_SQL = """
SELECT a.chembl_id AS assay_chembl_id, a.assay_type, a.relationship_type, a.bao_format, td.chembl_id AS target_chembl_id
FROM assays a JOIN target_dictionary td ON a.tid = td.tid
WHERE a.chembl_id IN ({})
"""
TARGET_SQL = """
SELECT td.chembl_id AS target_chembl_id, td.pref_name, td.organism, td.target_type,
       group_concat(cseq.accession) AS accessions
FROM target_dictionary td
LEFT JOIN target_components tc ON td.tid = tc.tid
LEFT JOIN component_sequences cseq ON tc.component_id = cseq.component_id
WHERE td.chembl_id = ? GROUP BY td.tid
"""
WORK_SQL = [
    ("act", """CREATE TABLE act AS SELECT activity_id, record_id, molregno, assay_id, doc_id, standard_type, standard_relation,
              standard_value, standard_units, standard_flag, pchembl_value, potential_duplicate, data_validity_comment
              FROM src.activities WHERE standard_type = 'IC50' AND standard_relation = '=' AND standard_flag = 1"""),
    ("act_idx", "CREATE INDEX w_act_assay ON act(assay_id)"),
    ("assays", """CREATE TABLE assays AS SELECT assay_id, chembl_id, tid, assay_type, relationship_type, bao_format
                 FROM src.assays WHERE assay_id IN (SELECT assay_id FROM act)"""),
    ("assays_idx", "CREATE UNIQUE INDEX w_assays_id ON assays(assay_id); CREATE INDEX w_assays_tid ON assays(tid); CREATE INDEX w_assays_chembl ON assays(chembl_id)"),
    ("target_dictionary", "CREATE TABLE target_dictionary AS SELECT tid, chembl_id, pref_name, organism, target_type FROM src.target_dictionary"),
    ("target_dictionary_idx", "CREATE UNIQUE INDEX w_td_tid ON target_dictionary(tid); CREATE INDEX w_td_chembl ON target_dictionary(chembl_id)"),
    ("docs", "CREATE TABLE docs AS SELECT doc_id, chembl_id, year FROM src.docs WHERE doc_id IN (SELECT doc_id FROM act)"),
    ("docs_idx", "CREATE UNIQUE INDEX w_docs_id ON docs(doc_id)"),
    ("molecule_dictionary", "CREATE TABLE molecule_dictionary AS SELECT molregno, chembl_id FROM src.molecule_dictionary WHERE molregno IN (SELECT molregno FROM act)"),
    ("molecule_dictionary_idx", "CREATE UNIQUE INDEX w_md_id ON molecule_dictionary(molregno)"),
    ("compound_structures", "CREATE TABLE compound_structures AS SELECT molregno, canonical_smiles FROM src.compound_structures WHERE molregno IN (SELECT molregno FROM act)"),
    ("compound_structures_idx", "CREATE UNIQUE INDEX w_cs_id ON compound_structures(molregno)"),
    ("target_components", "CREATE TABLE target_components AS SELECT tid, component_id FROM src.target_components"),
    ("component_sequences", "CREATE TABLE component_sequences AS SELECT component_id, accession FROM src.component_sequences"),
    ("component_class", "CREATE TABLE component_class AS SELECT component_id, protein_class_id FROM src.component_class"),
    ("protein_classification", "CREATE TABLE protein_classification AS SELECT protein_class_id, parent_id, pref_name, class_level FROM src.protein_classification"),
    ("version", "CREATE TABLE version AS SELECT * FROM src.version"),
    ("small_idx", "CREATE INDEX w_tc_tid ON target_components(tid); CREATE INDEX w_cs_comp ON component_sequences(component_id); CREATE INDEX w_cc_comp ON component_class(component_id)"),
]


def _uri(p, ro):
    return Path(p).resolve().as_uri() + ("?mode=ro" if ro else "")


def connect(db):
    con = sqlite3.connect(_uri(db, True), uri=True)
    con.row_factory = sqlite3.Row
    return con


def release_of(con):
    try:
        return [list(dict(x).values()) for x in con.execute("SELECT * FROM version").fetchall()]
    except sqlite3.Error:
        return None


def build_workdb(src, work):
    """Build the working extract from a release file opened read-only; atomic rename on success."""
    src, work = Path(src).resolve(), Path(work).resolve()
    assert src.exists(), src
    if (work.with_suffix(".complete.json")).exists():
        return json.loads(work.with_suffix(".complete.json").read_text(encoding="utf8"))
    tmp = work.with_suffix(".building")
    if tmp.exists():
        tmp.unlink()
    con = sqlite3.connect(_uri(tmp, False), uri=True)
    con.execute("PRAGMA journal_mode = OFF"); con.execute("PRAGMA synchronous = OFF"); con.execute("PRAGMA temp_store = FILE")
    con.execute("ATTACH DATABASE ? AS src", (_uri(src, True),))
    log = []
    for name, sql in WORK_SQL:
        t0 = time.time()
        con.executescript(sql) if ";" in sql else con.execute(sql)
        con.commit()
        log.append(dict(step=name, seconds=round(time.time() - t0, 1)))
        print(name, log[-1]["seconds"], "s", flush=True)
    counts = {t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in
              ["act", "assays", "target_dictionary", "docs", "molecule_dictionary", "compound_structures", "protein_classification"]}
    ver = [list(r) for r in con.execute("SELECT * FROM version").fetchall()]
    con.execute("DETACH DATABASE src"); con.close()
    tmp.replace(work)
    st = src.stat()
    rec = dict(source=str(src), source_bytes=st.st_size, source_mtime_utc=datetime.datetime.fromtimestamp(st.st_mtime, datetime.timezone.utc).isoformat(),
               source_opened_read_only=True, version=ver, counts=counts, steps=log, work=str(work), work_bytes=work.stat().st_size,
               filters="standard_type = 'IC50' AND standard_relation = '=' AND standard_flag = 1",
               built_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    work.with_suffix(".complete.json").write_text(json.dumps(rec, indent=2), encoding="utf8")
    return rec


def export_target(db, tid, dest):
    """Write API-like JSON for one target into dest/ and return a small summary."""
    dest = Path(dest); dest.mkdir(parents=True, exist_ok=True)
    con = connect(db)
    rows = [dict(r) for r in con.execute(ACT_SQL, (tid,))]
    for r in rows:
        if r["document_year"] is not None:
            r["document_year"] = int(r["document_year"])
    aids = sorted({r["assay_chembl_id"] for r in rows if r["assay_chembl_id"]})
    assays = []
    for i in range(0, len(aids), 900):
        chunk = aids[i:i + 900]
        assays.extend(dict(r) for r in con.execute(ASSAY_SQL.format(",".join("?" * len(chunk))), chunk))
    t = con.execute(TARGET_SQL, (tid,)).fetchone()
    tgt = dict(t) if t is not None else {}
    ver = release_of(con)
    con.close()

    def write(name, obj):
        body = json.dumps(obj, ensure_ascii=False, sort_keys=True).encode("utf-8")
        (dest / name).write_bytes(body)
        (dest / name.replace(".json", ".request.json")).write_text(
            json.dumps(dict(source="sqlite_work_extract", db=str(db), target=tid, sha256=hashlib.sha256(body).hexdigest())), encoding="utf8")
    write("activities_000000.json", dict(activities=rows, page_meta=dict(total_count=len(rows), source="sqlite")))
    write("assays_000000.json", dict(assays=assays))
    write("target.json", tgt)
    return dict(target=tid, activities=len(rows), assays=len(assays), release=ver)


FRAME_SQL = """
SELECT td.chembl_id AS target_chembl_id, td.pref_name, td.tid,
       COUNT(*) AS n_activities, COUNT(DISTINCT act.molregno) AS n_molregno, COUNT(DISTINCT act.doc_id) AS n_documents,
       MIN(d.year) AS first_year, MAX(d.year) AS last_year
FROM act
JOIN assays a ON act.assay_id = a.assay_id
JOIN target_dictionary td ON a.tid = td.tid
JOIN docs d ON act.doc_id = d.doc_id
JOIN compound_structures cs ON act.molregno = cs.molregno
WHERE td.target_type = 'SINGLE PROTEIN' AND td.organism = 'Homo sapiens'
  AND act.standard_type = 'IC50' AND act.standard_relation = '=' AND act.standard_flag = 1
  AND (act.potential_duplicate IS NULL OR act.potential_duplicate = 0) AND act.data_validity_comment IS NULL
  AND act.standard_units = 'nM' AND act.standard_value > 0 AND act.pchembl_value IS NOT NULL
  AND d.year IS NOT NULL AND cs.canonical_smiles IS NOT NULL
GROUP BY td.tid
"""
CLASS_SQL = "SELECT tc.tid, cc.protein_class_id FROM target_components tc JOIN component_class cc ON tc.component_id = cc.component_id"
STRATA = ["Kinase", "Protease", "Other enzyme", "Membrane receptor", "Ion channel", "Transcription factor",
          "Epigenetic regulator", "Transporter", "Other"]


def classify(rows, pc, cls):
    """Clarification C2: lowest protein_class_id with a level-1 ancestor; levels from class_level."""
    def lineage(cid):
        out, seen = [], set()
        while cid is not None and cid in pc and cid not in seen:
            seen.add(cid); out.append(pc[cid]); cid = pc[cid]["parent_id"]
        return out[::-1]
    for r in rows:
        l1 = l2 = used = None
        for cid in sorted(cls.get(r["tid"], [])):
            lin = lineage(cid)
            a = [x["pref_name"] for x in lin if x["class_level"] == 1]
            if not a:
                continue
            l1 = a[0]; b = [x["pref_name"] for x in lin if x["class_level"] == 2]; l2 = b[0] if b else None; used = cid
            break
        if l1 == "Enzyme":
            stratum = "Kinase" if l2 == "Kinase" else "Protease" if l2 == "Protease" else "Other enzyme"
        elif l1 in STRATA:
            stratum = l1
        else:
            stratum = "Other"
        r.update(class_l1=l1, class_l2=l2, protein_class_id_used=used, n_classifications=len(cls.get(r["tid"], [])), stratum=stratum)
    return rows


def frame(db):
    """Return the sampling-frame rows (PROTOCOL_PHASE3.md P3-B) with strata, before thresholds."""
    con = connect(db)
    rows = [dict(r) for r in con.execute(FRAME_SQL)]
    pc = {r["protein_class_id"]: dict(r) for r in con.execute("SELECT protein_class_id, parent_id, pref_name, class_level FROM protein_classification")}
    cls = {}
    for r in con.execute(CLASS_SQL):
        cls.setdefault(r["tid"], []).append(r["protein_class_id"])
    con.close()
    return classify(rows, pc, cls)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    b = sp.add_parser("build"); b.add_argument("--src", type=Path, required=True); b.add_argument("--work", type=Path, required=True)
    a = ap.parse_args()
    if a.cmd == "build":
        print(json.dumps(build_workdb(a.src, a.work), indent=2))
