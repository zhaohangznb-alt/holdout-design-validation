# Round-2 analysis protocol (fixed before any round-2 result was computed)

Written: 2026-10-04T06:26Z, before any F1/F2/F5/F8 output existed. Authorised by the author in the Cowork session on 2026-10-04 ("放开，F1 加 F2/F5/F8"; run F1/F2/F5 on the author's PC).
Status of results: supplementary and exploratory. None of these results is written into the manuscript by this session; the author decides whether and how to report them.

All analyses use the frozen public material of https://github.com/zhaohangznb-alt/holdout-design-validation (commit 61cd4c8ca08e4544812165e7dcb95ddcd4c0dd0a):
`verified_bundle_v1.tar.xz` (SHA-256 8fa707f1b8e5569b9723105c741cdd6b5d174441f718c78a00876d028c5724a1) and
`supplements/matched_train_control/controlled_comparison_v1.tar.xz`. No eligibility rule, label, structure, partition,
route definition, model setting or seed of the published analyses is changed. No tuning and no outcome-based selection.

Model specification for every new fit = archived `model_config.json`: RF 500 trees, max_features sqrt, min_samples_leaf 2,
other defaults; binary Morgan fingerprints radius 2, 2,048 bits, chirality off (RDKit 2025.09.2); training-mean baseline
from the matching training rows; skill = 1 - MSE_model / MSE_mean. `n_jobs` may differ from the archive (it does not change
fitted RF results for a fixed random_state). Environment: Python 3.9.10, numpy 2.0.2, pandas 2.3.3, scikit-learn 1.6.1,
RDKit 2025.09.2, scipy 1.13.1, joblib 1.5.3 (the author's existing pinned Windows environment); the scripts assert these versions.

## F1 - full 680-case clean-directory reproduction (reproducibility, not new science)

Command (unchanged public pipeline): `python -B verify_release.py` then `python -B reproduce.py --output reproduced_full_r2`
inside a freshly extracted `bundle/` on Windows. It rebuilds all 408 input tables, refits 138 RF / 46 Ridge / builds 46
1-NN indices, writes 680 prediction cases and recomputes the 2,000-replicate conditional intervals.
Comparison (`compare_f1.py`): for each of the 680 archived prediction files, the fresh file must exist; non-numeric columns
must be identical; every numeric column must agree within absolute 1e-12 (pre-declared tolerance of the earlier replays);
1-NN predictions must be exactly equal; byte identity is reported separately. Fresh `target_metrics.csv`,
`contrast_summary.csv`, `panel_summary.csv` are compared with the archived analysis tables (absolute 1e-12 for metrics;
interval endpoints are reported as differences only, because the bootstrap seeds are context-derived and should match).
Outcome categories: PASS (all 680 within tolerance), PARTIAL (some cases complete), FAIL (any case outside tolerance).

## F2 - training-resampling uncertainty (new exploratory analysis)

Scope: main view, broad (revised) cohorts, 11 targets (6 kinases, 5 non-kinases), routes source_exact (SE) and
temporal_exact (YE); RF only. Training rows: `train_<t>_<route>_full.csv` from the controlled-comparison snapshot (hash-checked).
Test rows: the archived route test set (rows of `main_revised_<t>_<route>_rf_42.csv`, hash-checked against the bundle manifest).
Resampling unit: whole training source documents, drawn with replacement, as many draws as there are training documents;
every row of a drawn document is included once per draw (rows concatenated in draw order). Replicates b = 0..19 (B = 20).
Random generator for replicate b, target index i (alphabetical order of the 11 target codes), route r (SE = 0, YE = 1):
`numpy.random.RandomState(20261004 + 1000*b + 10*i + r)`. RF random_state = 42 for every replicate, so the spread reflects
training-set resampling (seed variability is reported separately in Table S4 and is small).
Per replicate: training mean recomputed from the resampled training labels; RF fitted; MSE_RF and MSE_mean on the fixed test
rows; skill_b. Paired change per replicate: D_b = skill_YE,b - skill_SE,b within target.
Primary readouts: per target, the 2.5th/97.5th percentiles of skill_b (each route) and of D_b, and the fraction of replicates
with D_b < 0; per panel, the percentile interval of the replicate-wise median of D_b across targets.
Reference values: archived three-seed medians (not the replicate distribution centre). Interpretation: training-resampling
spread conditional on the observed source documents; not a population-of-targets inference; no significance test.
Execution order: replicate-major (all targets for b = 0, then b = 1, ...), checkpointed per fit; if stopped early, the number
of completed replicates is reported and intervals are computed only when all 22 target-routes have the same completed b.

## F5 - label- and year-distribution-matched common-test controls (new exploratory analysis)

Builds on the published common-test, matched-training-size control (same common test intersections, same five draw seeds
101, 211, 307, 401, 503; the smaller year pool is used whole with its archived predictions). Two new source-pool arms, each
with exactly m = year-pool size rows, sampled without replacement from the full source-exact training pool:
(L) label-matched: strata = 10 bins defined by the deciles of the year-pool labels (numpy.quantile, linear; first and last
edges extended to -inf/+inf); the required count per stratum equals the year-pool count in that stratum.
(Y) year-matched: strata = document_year values of the year pool; required count per year = year-pool count for that year.
Sampling: `numpy.random.RandomState(draw_seed + 7)` for L and `RandomState(draw_seed + 13)` for Y; within each stratum,
uniform sampling without replacement from source rows in that stratum; if a stratum has too few source rows, all are taken
and the deficit is filled by uniform sampling without replacement from the remaining source rows; deficits are recorded.
The selected positions are sorted to keep the original row order. Models: RF seeds 42, 53, 67 (Ridge/1-NN not run).
Outcome per draw: MSE on the common test (mean row loss per seed, then median of seeds). Contrasts (positive = higher year-pool
error): pool_L = MSE(year full) - MSE(source label-matched); pool_Y = MSE(year full) - MSE(source year-matched); reference
pool_size = MSE(year matched) - MSE(source size-matched) from the published `per_draw_contrasts.csv`.
Readouts: per target, median and range over the five draws; number of targets with positive median contrast; matching
diagnostics (label mean/SD and year histogram distance of each sample vs the year pool; deficits). Descriptive only.

## F8 - evaluation-unit weighting sensitivity (new exploratory analysis; no fitting)

Input: all 680 archived per-row prediction files in `bundle/results/predictions/` (hash-checked against FILE_MANIFEST.json).
Three weightings of the same test rows, model predictions and training-mean constants:
(C) context weighting (published estimand; every aggregated measurement context weight 1);
(M) molecule weighting: every unique `smiles` (canonical structure string as stored) in a test set has total weight 1,
split equally over its contexts; (D) document weighting: every test source document has total weight 1, split equally over
its contexts. Weighted MSE_model and MSE_mean use the same weights; skill = 1 - wMSE_model/wMSE_mean; RF = median of the three
seed skills. Summaries per panel/view/cohort/model: panel median skill per route, median within-target paired changes
(YE - SE, SS - SE) and number of targets with lower YE skill, exactly as in contrast_summary.csv. Check: (C) must reproduce
the archived target_metrics.csv skills within 1e-12. Descriptive; no interval.

## Amendment A1 to F5 (2026-10-04T06:33Z, before any real-feature F5 outcome)

Reason: a feasibility dry run on the real snapshot data (matching diagnostics only; model outputs in that dry run used random
test features and are not results) showed that arm (Y) cannot match the year-pool document-year distribution at size m: the
source pool holds roughly 70% of each historical year's rows, so e.g. PTGS2 needed 1,018 of 2,877 rows from other years
(total-variation distance 0.35). Arm (Y) is therefore replaced by a period-restricted design; arm (L) is unchanged.

(Y*) period-restricted source pool: all source-exact training rows whose document_year is not later than the year pool's
latest document_year (the year route's training-end year; checked against Table 1 for the kinases), size n_h < m, used
whole. Two size-matched references, each drawn with the five draw seeds (RandomState(draw + 17) and RandomState(draw + 19),
uniform without replacement, original row order kept): a random source-pool subsample of size n_h, and a random year-pool
subsample of size n_h. RF seeds 42, 53, 67.
Contrasts (per draw; RF three-seed median MSE on the common test):
recency_within_source = MSE(source period-restricted) - MSE(source random, size n_h)  [positive: losing post-cutoff documents raises error]
year_vs_period_source = MSE(year random, size n_h) - MSE(source period-restricted)   [near zero if the training period explains the year-pool gap]
Readouts and interpretation rules as for F5. Planned fits: label arm 165; period design 11 x (3 + 15 + 15) = 363.

## Amendment A2 (2026-10-04T08:20Z, technical; before any F1 output existed)

First PC run: `reproduce.py --output reproduced_full_r2` stopped before doing any work, with `ValueError: 'reproduced_full_r2' is not in the subpath of ...\f1\bundle`. On Windows, Python 3.9's `Path.resolve()` returns a non-existent relative path unchanged, so the pipeline's own `out.relative_to(HERE)` guard rejects it. The F1 command therefore passes the same output folder as an absolute path, `<package>\f1\bundle\reproduced_full_r2`. The pipeline code, its inputs and the comparison rule are unchanged. F5, F2 and F8 are unaffected.

## Deviation note D1 (recorded 2026-10-04 while writing up the results; not outcome-driven)

F2 says the target index i in the replicate seed `RandomState(20261004 + 1000*b + 10*i + r)` follows the alphabetical order of the target codes. The implementation (`r2common.TARGETS`, fixed in code before any fit) instead uses the package order ALK, BRAF, EGFR, ERBB2, KDR, MET, ACHE, DPP4, PTGS2, HDAC1, PDE4D. The seeds are still fixed in advance and independent of outcomes. Only the mapping from target to seed differs from the text, and the results were not recomputed with alphabetical indices. The SI note to Table S23 reports this deviation.

## Amendment A3 (2026-10-04T12:10Z, written before any result of the extended runs)

Authorised by the author ("全做"). Reasons: the 20-replicate F2 ranges are coarse; the archived design uses three RF seeds, so seed variation should be part of the resampling distribution; and the F5 controls covered RF only.

(1) **F2-B200.**
- B = 200 replicates (b = 0..199), using the same document-resampling generator `RandomState(20261004 + 1000*b + 10*i + r)`. The index i keeps the package order (see Deviation D1) for continuity.
- RF random_state for replicate b is (42, 53, 67)[b mod 3].
- All 200 replicates are fitted fresh in a new output directory (`results/f2_b200`).
- The earlier B = 20 fixed-seed run is retained and reported as superseded.
- Readouts and interpretation are as in F2.

(2) **F5 Ridge and 1-NN.**
- For every F5 arm and draw (label-matched, period-restricted, random source n_h, random year n_h), Ridge and 1-NN are fitted exactly as in the archived runner, one deterministic fit per arm and draw:
  - Ridge: alpha 1, intercept, lsqr, tol 1e-4, max_iter 10000, sparse float64 input.
  - 1-NN: binary Tanimoto, first maximum in original training order, zero-union similarity 1.
- Contrasts are the same as for RF, using the published Ridge/1-NN `year_full_mse` and `matched_pool`.
- Guard: before the F5 run, `check_ridge_nn_equivalence.py` must reproduce the archived main/revised Ridge (|diff| <= 1e-9) and 1-NN (exact) predictions for ALK and ACHE, source exact and year exact. If the guard fails, the Ridge/1-NN arms are not run.

Interpretation rules are unchanged. All results are descriptive.

## Execution note E1 to Amendment A3 (recorded 2026-10-04T17:10Z, before any 200-replicate summary existed)

The F2 run with 200 replicates (step R3A_03) stopped at 2026-10-04T14:46:28Z, when the author's PC was interrupted. The ChEMBL 37 download, running in parallel, stopped in the same minute. By then replicates 0-142 were complete (all 22 target-route fits each); the last checkpoint was `kdr_source_exact_b143.json`. On the author's instruction ("接着把 F2 从断点续跑") the same script was restarted with identical arguments (`resume_f2_b200.ps1`). The code, snapshot, bundle, seeds, RF seed cycling and output folder are unchanged. Existing per-fit checkpoints are skipped, so no completed fit is recomputed or discarded. The resume launcher also asks Windows not to idle-sleep while it runs. This is a per-process request, not a change to any power setting.

Addendum to E1 (recorded 2026-10-04T18:35Z): at 17:23:30Z the PC entered Modern Standby after the display timed out. The resumed F2 run had then reached replicate 158. Its processes were suspended, not terminated, and continue on wake from the same state. The keep-awake request now also sets ES_DISPLAY_REQUIRED. A separate hold window (`KEEP_AWAKE.bat`) can keep already-running jobs awake. No fit was recomputed or discarded.

Second addendum to E1 (recorded 2026-10-05T01:45Z, before any 200-replicate summary existed): the suspended processes had ended by 2026-10-05T01:10Z (the author reports having closed the terminal windows). On the author's instruction the run was restarted at 01:17:10Z (3,492 fits present). The author closed the windows again at about 01:39Z (replicate 193; 4,267 fits present). On the author's instruction it was restarted at 01:42:31Z with identical arguments, now in a minimised window (`START_ALL_MINIMIZED.bat`). Checkpoints are written atomically: a fit interrupted before its checkpoint is refitted with the same seeds, and no completed fit is recomputed or discarded. The console log of the 01:17-01:39Z segment was overwritten by the restart. The per-fit checkpoints are not affected.
