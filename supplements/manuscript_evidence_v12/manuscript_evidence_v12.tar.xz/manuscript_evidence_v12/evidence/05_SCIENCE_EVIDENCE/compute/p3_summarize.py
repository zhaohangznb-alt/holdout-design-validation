"""Phase-3 readouts (PROTOCOL_PHASE3.md). Pure post-processing of the frozen fit tables; no model is fitted here.
  P3-A  : dmpnn_runs.csv + archived RF target_metrics.csv -> route skills, within-target YE-SE / SS-SE, panel medians,
          count of targets with lower temporal-exact skill, D-MPNN beside RF on the same contexts.
  P3-B  : panel_runs.csv -> target-level skills (3-seed median RF; single Ridge/1-NN) -> paired changes -> population
          summary over the sampled frame: median/mean, 10,000-rep stratified bootstrap 95% PI (seed 20261004),
          proportion with lower YE skill + Wilson interval, stratum medians. Broad and operational, RF/Ridge/1-NN.
  P3-C  : release_runs.csv -> per-target release-forward skill + MAE, internal-route skills, |internal - release| agreement;
          cross-target medians exclude targets with < 30 prospective exact-tier contexts (marked).
"""
import argparse, json, math
from pathlib import Path
import numpy as np
import pandas as pd

BOOT_SEED = 20261004
STRATA = ["Kinase", "Protease", "Other enzyme", "Membrane receptor", "Ion channel", "Transcription factor",
          "Epigenetic regulator", "Transporter", "Other"]


def save(p, obj):
    Path(p).write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=float), encoding="utf8")


def wilson(k, n, z=1.959963984540054):
    if n == 0:
        return [None, None]
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [c - h, c + h]


def median_ci(x, reps, seed):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    if len(x) == 0:
        return dict(n=0, median=None, mean=None, ci=[None, None])
    rng = np.random.default_rng(seed)
    bs = np.median(rng.choice(x, size=(reps, len(x)), replace=True), axis=1)
    return dict(n=int(len(x)), median=float(np.median(x)), mean=float(np.mean(x)), ci=[float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))])


def stratified_median_ci(df, col, reps, seed):
    """Resample targets within strata; bootstrap distribution of the overall median of `col`."""
    d = df[["stratum", col]].dropna()
    if not len(d):
        return dict(n=0, median=None, mean=None, ci=[None, None], n_strata=0)
    rng = np.random.default_rng(seed)
    groups = [g[col].to_numpy(float) for _, g in d.groupby("stratum")]
    bs = np.empty(reps)
    for r in range(reps):
        bs[r] = np.median(np.concatenate([g[rng.integers(0, len(g), len(g))] for g in groups]))
    return dict(n=int(len(d)), median=float(np.median(d[col])), mean=float(np.mean(d[col])),
                ci=[float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))], n_strata=int(d.stratum.nunique()))


def target_skills(runs, extra_keys):
    """3-seed median skill for RF, single value for Ridge/1-NN/D-MPNN."""
    keys = extra_keys + ["target", "route", "model"]
    return runs.groupby(keys, dropna=False).agg(skill=("skill", "median"), test_rows=("test_rows", "first")).reset_index()


def contrasts(ts, idx):
    piv = ts.pivot_table(index=idx, columns="route", values="skill").reset_index()
    for a, b, n in [("temporal_exact", "source_exact", "ye_minus_se"), ("source_scaffold", "source_exact", "ss_minus_se"),
                    ("temporal_scaffold", "temporal_exact", "ys_minus_ye")]:
        if {a, b} <= set(piv.columns):
            piv[n] = piv[a] - piv[b]
    return piv


# ---------------- P3-A
def p3a(dmpnn_csv, rf_metrics_csv, out):
    d = pd.read_csv(dmpnn_csv)
    d = d[d.view == "main"].copy(); d["source"] = "dmpnn"
    rf = pd.read_csv(rf_metrics_csv)
    rf = rf[(rf.view == "main") & (rf.model == "rf")].copy(); rf["source"] = "rf"
    both = pd.concat([d[["scenario", "target", "route", "seed", "skill", "test_rows", "source"]],
                      rf.assign(seed=0, test_rows=np.nan)[["scenario", "target", "route", "seed", "skill", "test_rows", "source"]]], ignore_index=True)
    ts = both.groupby(["source", "scenario", "target", "route"]).agg(skill=("skill", "median"), test_rows=("test_rows", "first")).reset_index()
    ts.to_csv(out / "p3a_target_route_skills.csv", index=False)
    con = contrasts(ts, ["source", "scenario", "target"])
    con.to_csv(out / "p3a_within_target_contrasts.csv", index=False)
    summ = {}
    for src in ["dmpnn", "rf"]:
        c = con[con.source == src]
        summ[src] = dict(contexts=int(ts[ts.source == src].groupby(["scenario", "target"]).ngroups),
                         route_median_skill={r: float(ts[(ts.source == src) & (ts.route == r)].skill.median()) for r in sorted(ts.route.unique())},
                         ye_minus_se=median_ci(c.get("ye_minus_se", pd.Series(dtype=float)), 10000, BOOT_SEED),
                         ss_minus_se=median_ci(c.get("ss_minus_se", pd.Series(dtype=float)), 10000, BOOT_SEED),
                         n_targets_lower_ye=int((c.get("ye_minus_se", pd.Series(dtype=float)) < 0).sum()),
                         n_targets=int(c["ye_minus_se"].notna().sum()) if "ye_minus_se" in c else 0)
    save(out / "P3A_SUMMARY.json", dict(analysis="P3-A D-MPNN vs RF on archived partitions", by_model=summ,
                                        note="RF skills are the archived three-seed medians (results/analysis/target_metrics.csv), reproduced by F1."))
    return summ


# ---------------- P3-B
def p3b(panel_csv, frozen_json, out):
    runs = pd.read_csv(panel_csv)
    sel = pd.DataFrame(json.loads(Path(frozen_json).read_text(encoding="utf8"))["selected"])[["symbol", "stratum", "pref_name"]].rename(columns={"symbol": "target"})
    results = {}
    for scenario in ["revised", "single_protein"]:
        ts = target_skills(runs[runs.scenario == scenario], ["scenario"])
        for model in ["rf", "ridge", "tanimoto1nn"]:
            con = contrasts(ts[ts.model == model], ["scenario", "target"]).merge(sel, on="target", how="left")
            tag = f"{scenario}__{model}"
            con.to_csv(out / f"p3b_contrasts_{tag}.csv", index=False)
            block = {}
            for metric in ["ye_minus_se", "ss_minus_se"]:
                if metric not in con:
                    continue
                v = con[metric].dropna()
                block[metric] = dict(overall=median_ci(v, 10000, BOOT_SEED),
                                     stratified=stratified_median_ci(con, metric, 10000, BOOT_SEED),
                                     n_negative=int((v < 0).sum()), n=int(v.notna().sum()),
                                     proportion_lower=(float((v < 0).mean()) if len(v) else None),
                                     proportion_lower_wilson=wilson(int((v < 0).sum()), int(len(v))),
                                     stratum_median={s: (float(con.loc[con.stratum == s, metric].median()) if con[con.stratum == s][metric].notna().any() else None) for s in STRATA})
            results[tag] = block
    save(out / "P3B_SUMMARY.json", dict(analysis="P3-B extended stratified panel (automated eligibility)",
                                        n_targets=int(sel.shape[0]), by_stratum=sel.stratum.value_counts().reindex(STRATA, fill_value=0).to_dict(),
                                        bootstrap_reps=10000, bootstrap_seed=BOOT_SEED, results=results))
    return results


# ---------------- P3-C
def p3c(release_csv, prepared_json, out):
    runs = pd.read_csv(release_csv)
    prep = json.loads(Path(prepared_json).read_text(encoding="utf8"))
    min_exact = prep.get("min_exact_for_medians", 30)
    rows = []
    for sym, t in prep["targets"].items():
        if t.get("state") != "prepared":
            rows.append(dict(target=sym, state=t.get("state"))); continue
        r = runs[runs.target == sym]

        def sk(design, test_set):
            g = r[(r.design == design) & (r.test_set == test_set)]
            return float(g.skill.median()) if len(g) else None, (float(g.mae_model.median()) if len(g) else None)
        rec = dict(target=sym, state="prepared", stratum=None, below_min_exact=t["below_min_exact"],
                   test_exact_contexts=t["test_exact_contexts"], test_scaffold_contexts=t["test_scaffold_contexts"],
                   new_documents=t["new_documents"], train_contexts=t["train_contexts"])
        rec["release_forward_exact_skill"], rec["release_forward_exact_mae"] = sk("release_forward", "exact")
        rec["release_forward_scaffold_skill"], _ = sk("release_forward", "scaffold")
        for route in ["source_exact", "source_scaffold", "temporal_exact", "temporal_scaffold"]:
            rec[f"internal_{route}_skill"], _ = sk(f"internal_{route}", "test")
        for route, tier in [("source_exact", "exact"), ("temporal_exact", "exact"), ("source_scaffold", "scaffold"), ("temporal_scaffold", "scaffold")]:
            rf = rec[f"release_forward_{tier}_skill"]; iv = rec[f"internal_{route}_skill"]
            rec[f"agree_{route}"] = (abs(iv - rf) if (rf is not None and iv is not None) else None)
        rows.append(rec)
    df = pd.DataFrame(rows)
    df.to_csv(out / "p3c_per_target.csv", index=False)
    use = df[(df.state == "prepared") & (~df.below_min_exact.astype(bool))]
    summ = dict(analysis="P3-C release-to-release (ChEMBL 36 -> 37), automated eligibility", n_targets=int((df.state == "prepared").sum()),
                n_included_in_medians=int(len(use)), min_exact_for_medians=min_exact,
                excluded_below_min=sorted(df.loc[(df.state == "prepared") & df.below_min_exact.astype(bool), "target"]),
                median_release_forward_exact_skill=float(use.release_forward_exact_skill.median()) if len(use) else None,
                median_release_forward_exact_mae=float(use.release_forward_exact_mae.median()) if len(use) else None,
                agreement_median={r: (float(use[f"agree_{r}"].median()) if len(use) and use[f"agree_{r}"].notna().any() else None)
                                  for r in ["source_exact", "temporal_exact", "source_scaffold", "temporal_scaffold"]})
    save(out / "P3C_SUMMARY.json", summ)
    return summ


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--p3root", type=Path, required=True, help="results/p3")
    ap.add_argument("--rf-metrics", type=Path, required=True, help="bundle results/analysis/target_metrics.csv (archived RF)")
    ap.add_argument("--output", type=Path, required=True)
    a = ap.parse_args()
    out = a.output.resolve(); out.mkdir(parents=True, exist_ok=True)
    done = {}
    dmpnn = a.p3root / "dmpnn" / "dmpnn_runs.csv"
    if dmpnn.exists():
        done["p3a"] = p3a(dmpnn, a.rf_metrics, out)
    panel = a.p3root / "panel" / "panel_runs.csv"
    if panel.exists():
        done["p3b"] = p3b(panel, a.p3root / "panel" / "PANEL_SELECTION_FROZEN.json", out)
    rel = a.p3root / "release" / "release_runs.csv"
    if rel.exists():
        done["p3c"] = p3c(rel, a.p3root / "release" / "RELEASE_PREPARED.json", out)
    save(out / "P3_SUMMARY_INDEX.json", dict(available=sorted(done), p3root=str(a.p3root)))
    print("summarised:", sorted(done), flush=True)


if __name__ == "__main__":
    main()
