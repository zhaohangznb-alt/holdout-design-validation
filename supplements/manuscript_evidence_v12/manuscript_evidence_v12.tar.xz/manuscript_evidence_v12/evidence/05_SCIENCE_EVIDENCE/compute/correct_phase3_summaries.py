"""Correct model aggregation and target-cluster uncertainty; post-processing only, no fitting."""
import argparse, json, math
from pathlib import Path
import numpy as np
import pandas as pd

SEED=20261004
REPS=10000
ROUTES=['source_exact','source_scaffold','temporal_exact','temporal_scaffold']
SCENARIOS=['revised','single_protein']
MODELS=['rf','ridge','tanimoto1nn']

def save(path,obj):
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=lambda x:x.item())+'\n',encoding='utf-8')

def validate_runs(df,keys,models):
    if df.duplicated(keys+['model','seed']).any(): raise ValueError('Duplicate evaluation key')
    if set(df.model)!=set(models): raise ValueError('Unexpected model set')
    cols=['skill','mse_model','mse_mean','mae_model','mae_mean','training_mean']
    if not np.isfinite(df[cols].to_numpy(float)).all(): raise ValueError('Nonfinite metrics')
    if (df.mse_mean<=0).any(): raise ValueError('Invalid baseline')
    if not np.allclose(df.skill,1-df.mse_model/df.mse_mean,atol=1e-12,rtol=1e-12): raise ValueError('Skill inconsistent')
    for _,g in df.groupby(keys,dropna=False):
        if set(g.model)!=set(models): raise ValueError('Missing model in context')
        for m,gm in g.groupby('model'):
            expected={42,53,67} if m in ['rf','dmpnn'] else {0}
            if set(gm.seed)!=expected: raise ValueError('Missing/extra seed')
        if g.test_rows.nunique()!=1 or g.training_mean.nunique()!=1: raise ValueError('Nonmatching model context')

def model_median(df,model):
    q=df[df.model==model]
    expected={42,53,67} if model in ['rf','dmpnn'] else {0}
    if set(q.seed)!=expected or len(q)!=len(expected): raise ValueError('Incomplete model seeds')
    return float(q.skill.median())

def paired(ts,index):
    p=ts.pivot(index=index,columns='route',values='skill').reset_index()
    for a,b,k in [('temporal_exact','source_exact','ye_minus_se'),('source_scaffold','source_exact','ss_minus_se'),('temporal_scaffold','temporal_exact','ys_minus_ye')]:
        p[k]=p[a]-p[b]
    return p

def cluster_samples(values,reps=REPS,seed=SEED):
    """Each row is one target, each column a cohort; every draw retains each whole row."""
    values=np.asarray(values,float)
    if values.ndim!=2 or not np.isfinite(values).all(): raise ValueError('Incomplete target clusters')
    ix=np.random.default_rng(seed).integers(0,len(values),size=(reps,len(values)))
    return values[ix]

def cluster_summary(df,col):
    wide=df.pivot(index='target',columns='scenario',values=col).reindex(columns=SCENARIOS).sort_index()
    a=wide.to_numpy(float); draws=cluster_samples(a)
    bs=np.median(draws.reshape(REPS,-1),axis=1)
    return {'n_targets':len(a),'n_target_cohort_combinations':a.size,'median':float(np.median(a)),
            'ci':np.percentile(bs,[2.5,97.5]).tolist(),'negative_combinations':int((a<0).sum()),
            'resampling_unit':'whole target with both cohorts retained','reps':REPS,'seed':SEED}

def ordinary(df,col,stratified=False):
    d=df[['stratum',col]].dropna() if stratified else df[[col]].dropna()
    v=d[col].to_numpy(float);rng=np.random.default_rng(SEED)
    if stratified:
        groups=[g[col].to_numpy(float) for _,g in d.groupby('stratum')]
        bs=np.array([np.median(np.concatenate([g[rng.integers(0,len(g),len(g))] for g in groups])) for _ in range(REPS)])
    else: bs=np.median(rng.choice(v,size=(REPS,len(v)),replace=True),axis=1)
    return {'n':len(v),'median':float(np.median(v)),'mean':float(np.mean(v)),'ci':np.percentile(bs,[2.5,97.5]).tolist()}

def wilson(k,n):
    z=1.959963984540054;p=k/n;d=1+z*z/n;c=(p+z*z/(2*n))/d;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [c-h,c+h]

def run(p3,rfmetrics,out):
    out.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(p3/'dmpnn/dmpnn_runs.csv');b=pd.read_csv(p3/'panel/panel_runs.csv');c=pd.read_csv(p3/'release/release_runs.csv')
    validate_runs(d,['scenario','target','route'],['dmpnn']);validate_runs(b,['scenario','target','route'],MODELS)
    validate_runs(c,['target','design','test_set'],MODELS)
    assert len(d)==264 and len(b)==1575 and len(c)==330
    rf=pd.read_csv(rfmetrics);rf=rf[(rf.view=='main')&(rf.model=='rf')].copy()
    rf=rf[['scenario','target','route','skill']];rf['source']='rf'
    ds=d.groupby(['scenario','target','route'],as_index=False).skill.median();ds['source']='dmpnn'
    ts=pd.concat([rf,ds],ignore_index=True)
    assert len(ts)==176 and not ts.duplicated(['source','scenario','target','route']).any()
    con=paired(ts,['source','scenario','target'])
    old=pd.read_csv(p3/'summary/p3a_within_target_contrasts.csv')
    q=con.merge(old,on=['source','scenario','target'],suffixes=('_new','_old'))
    assert len(q)==44 and np.allclose(q.ye_minus_se_new,q.ye_minus_se_old,atol=1e-12,rtol=0)
    ts.to_csv(out/'p3a_target_route_skills.csv',index=False);con.to_csv(out/'p3a_within_target_contrasts.csv',index=False)
    summary={}
    for src,g in con.groupby('source'):
        a={'ye_minus_se':cluster_summary(g,'ye_minus_se'),'ss_minus_se':cluster_summary(g,'ss_minus_se')}
        a['route_median_skill']={r:float(ts[(ts.source==src)&(ts.route==r)].skill.median()) for r in ROUTES}
        a['by_cohort']={s:{'n_targets':len(x),'ye_minus_se':float(x.ye_minus_se.median()),'negative':int((x.ye_minus_se<0).sum())} for s,x in g.groupby('scenario')}
        summary[src]=a
    save(out/'P3A_SUMMARY.json',{'by_model':summary,'method_correction':'whole-target bootstrap replaces pooled target-cohort row bootstrap; point estimates unchanged'})
    selj=json.loads((p3/'panel/PANEL_SELECTION_FROZEN.json').read_text(encoding='utf-8-sig'))
    sel=pd.DataFrame(selj['selected']).rename(columns={'symbol':'target'})
    expected={(s,t,r) for s in SCENARIOS for t in sel.target for r in ROUTES}
    absent={(x['scenario'],x['target'],x['route']) for x in selj['unavailable']}
    actual=set(map(tuple,b[['scenario','target','route']].drop_duplicates().to_numpy()))
    assert actual==expected-absent and len(actual)==315
    bts=b.groupby(['scenario','target','route','model'],as_index=False).skill.median()
    blocks={}
    for (s,m),g in bts.groupby(['scenario','model']):
        bc=paired(g,['scenario','target']).merge(sel[['target','stratum','pref_name','target_chembl_id']],on='target',how='left')
        bc.to_csv(out/f'p3b_contrasts_{s}__{m}.csv',index=False)
        block={}
        for col in ['ye_minus_se','ss_minus_se']:
            v=bc[col].dropna();k=int((v<0).sum());n=len(v)
            block[col]={'overall':ordinary(bc,col),'stratified':ordinary(bc,col,True),'n_negative':k,'n':n,
                        'proportion_lower':k/n,'proportion_lower_wilson':wilson(k,n),
                        'stratum_median':{st:float(x[col].median()) if x[col].notna().any() else None for st,x in bc.groupby('stratum')}}
        blocks[f'{s}__{m}']=block
    oldb=json.loads((p3/'summary/P3B_SUMMARY.json').read_text())
    for col in ['ye_minus_se','ss_minus_se']:
        assert np.allclose(blocks['revised__rf'][col]['stratified']['ci'],oldb['results']['revised__rf'][col]['stratified']['ci'],atol=1e-12,rtol=0)
    save(out/'P3B_SUMMARY.json',{'n_targets':42,'by_stratum':sel.stratum.value_counts().to_dict(),'results':blocks,
                              'available_contexts':len(actual),'unavailable_contexts':selj['unavailable'],'bootstrap_reps':REPS,'bootstrap_seed':SEED,
                              'interpretation':'Selected stratified panel with equal target weights; not population-weighted ChEMBL inference.'})
    prep=json.loads((p3/'release/RELEASE_PREPARED.json').read_text(encoding='utf-8-sig'))
    csumm={};allrows=[]
    for m in MODELS:
        rows=[]
        for target,t in sorted(prep['targets'].items()):
            assert t['state']=='prepared'
            r=c[c.target==target]
            rec={k:t[k] for k in ['test_exact_contexts','test_scaffold_contexts','new_documents','train_contexts','below_min_exact']}
            rec.update(target=target,model=m,new_document_years=t['new_document_years'])
            for tier in ['exact','scaffold']:
                q=r[(r.design=='release_forward')&(r.test_set==tier)]
                rec[f'release_forward_{tier}_skill']=model_median(q,m)
                rec[f'release_forward_{tier}_mae']=float(q[q.model==m].mae_model.median())
            for route in ROUTES:
                q=r[(r.design=='internal_'+route)&(r.test_set=='test')]
                rec[f'internal_{route}_skill']=model_median(q,m)
                tier='scaffold' if route.endswith('scaffold') else 'exact'
                rec[f'agree_{route}']=abs(rec[f'internal_{route}_skill']-rec[f'release_forward_{tier}_skill'])
            rows.append(rec)
        df=pd.DataFrame(rows);df.to_csv(out/f'p3c_per_target_{m}.csv',index=False);allrows.extend(rows)
        use=df[~df.below_min_exact]
        csumm[m]={'n_targets':len(df),'n_included_in_medians':len(use),'excluded_below_min':df.loc[df.below_min_exact,'target'].tolist(),
                  'median_release_forward_exact_skill':float(use.release_forward_exact_skill.median()),
                  'median_release_forward_exact_mae':float(use.release_forward_exact_mae.median()),
                  'agreement_median':{r:float(use['agree_'+r].median()) for r in ROUTES}}
    pd.DataFrame(allrows).to_csv(out/'p3c_per_target_by_model.csv',index=False)
    save(out/'P3C_SUMMARY.json',{'by_model':csumm,'min_exact_for_medians':30,'correction':'Separate models; RF aggregates only seeds42/53/67. Old five-score pooled values are superseded.'})
    oldc=json.loads((p3/'summary/P3C_SUMMARY.json').read_text())
    save(out/'CORRECTION_COMPARISON.json',{'old_pooled_release':oldc,'corrected_rf_release':csumm['rf'],
                                        'old_pooled_p3a':json.loads((p3/'summary/P3A_SUMMARY.json').read_text()),'corrected_p3a':summary})
    log='''# 阶段三汇总纠正\n\nCodex 接力时发现并纠正两处统计实现问题。原始数据、预测、模型设置、划分和训练记录均保留。\n\n1. S29 原函数未筛选 model，把三个 RF 种子及 Ridge、1-NN 合并取中位数，却称为 RF。现分别汇总三个模型，RF 只取三个种子的中位数。九靶点 RF 前向 exact skill 中位数由 0.062862 改为 0.064924；SE/YE 差距中位数改为 0.168397/0.211996。\n2. S27 的 22 个靶点×队列组合来自 11 个靶点。原区间独立抽取这 22 行。现按完整靶点抽取，保留同一靶点两队列的依赖关系；仍用 10,000 次、种子 20261004、2.5/97.5 百分位，统计量仍为 22 个组合的中位数。这是对协议中“按靶点重抽样”实现的纠正，原区间作为历史记录保留，不再用于新表。点估计和方向计数不变。\n3. S28 broad 42 靶点的汇总保持一致；operational 仅 147 条路线语境可用，YE−SE 涉及 36 个靶点。空分区按既有规则列出。所选分层面板不作整个 ChEMBL 靶点总体的加权推断。\n\n实际改前/改后数值见 CORRECTION_COMPARISON.json；聚类区间见 P3A_SUMMARY.json。未重训练任何模型。\n'''
    (out/'CORRECTION_LOG_CN.md').write_text(log,encoding='utf-8')
    save(out/'SUMMARY_VERIFICATION.json',{'status':'PASS','raw_record_counts':{'dmpnn':len(d),'panel':len(b),'release':len(c)},
                                       'old_rf_point_estimates_corroborated_from_archived_metrics':True,
                                       'p3b_broad_rf_intervals_reproduced':True,'model_seed_completeness':True})
    print(json.dumps({'status':'PASS','dmpnn':summary['dmpnn']['ye_minus_se'],'rf_release':csumm['rf']},ensure_ascii=False))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--p3root',type=Path,required=True);ap.add_argument('--rf-metrics',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();run(a.p3root,a.rf_metrics,a.output)
