"""P3-C: release-to-release (ChEMBL 36 -> 37) evaluation, automated eligibility (PROTOCOL_PHASE3.md, Clarifications C4-C6).
  prepare : export the 11 published targets from both working extracts; clean() each release; training set = all ChEMBL 36
            contexts; prospective test = ChEMBL 37 contexts from documents absent from the target's exported ChEMBL 36 records,
            exact tier (training structures removed) and scaffold tier (training scaffolds also removed); internal routes =
            split() on the ChEMBL 36 contexts (broad cohort). All model inputs are frozen as CSV (hashes) before any fit.
  fit     : RF (3 seeds), Ridge, 1-NN trained on all ChEMBL 36 contexts (scored on both tiers) and on each internal route.
"""
import argparse, json, time
from pathlib import Path
import pandas as pd
from r2common import Featurizer, save, read, stamp, sha, environment
from p3_common import PUBLISHED_IDS, ROUTES, import_bundle, roundtrip, fit_context, write_predictions
from p3_chembl import export_target

MIN_EXACT = 30


def cmd_prepare(a):
    out = a.output.resolve(); out.mkdir(parents=True, exist_ok=True)
    frozen = out / "RELEASE_PREPARED.json"
    assert not frozen.exists(), "release inputs already frozen"
    pe = import_bundle(a.bundle)
    prep = out / "prepared"
    targets, files = {}, {}
    for sym, tid in PUBLISHED_IDS.items():
        rec = dict(symbol=sym, target_chembl_id=tid)
        try:
            rec["export36"] = export_target(a.work36, tid, out / "raw36" / sym)
            rec["export37"] = export_target(a.work37, tid, out / "raw37" / sym)
            raw36 = json.loads((out / "raw36" / sym / "activities_000000.json").read_text(encoding="utf8"))["activities"]
            docs36 = {r["document_chembl_id"] for r in raw36 if r["document_chembl_id"]}
            g36, flow36, s36 = pe.clean(out / "raw36", sym, tid)
            g37, flow37, s37 = pe.clean(out / "raw37", sym, tid)
            train = roundtrip(g36, prep / f"{sym}_release_train36.csv")
            new = g37[~g37.document_chembl_id.isin(docs36)]
            exact = new[~new.smiles.isin(set(train.smiles))]
            scaffold = exact[~exact.murcko_scaffold.isin(set(train.murcko_scaffold))]
            exact = roundtrip(exact, prep / f"{sym}_release_test37_exact.csv")
            scaffold = roundtrip(scaffold, prep / f"{sym}_release_test37_scaffold.csv")
            routes, cut = pe.split(g36)
            for route in ROUTES:
                for part in ["train", "valid", "test"]:
                    roundtrip(routes[route][part], prep / f"{sym}_internal36_{route}_{part}.csv")
            rec.update(state="prepared", summary36=s36, summary37=s37, documents36_exported=len(docs36),
                       contexts37_from_new_documents=len(new), new_documents=int(new.document_chembl_id.nunique()),
                       new_document_years=sorted(int(y) for y in new.document_year.unique()),
                       test_exact_contexts=len(exact), test_scaffold_contexts=len(scaffold), train_contexts=len(train),
                       below_min_exact=len(exact) < MIN_EXACT, internal_cutoffs=cut,
                       internal_test_contexts={r: len(routes[r]["test"]) for r in ROUTES})
        except Exception as e:
            rec.update(state="failed", error=type(e).__name__ + ": " + str(e)[:300])
        targets[sym] = rec
        print(sym, rec["state"], rec.get("test_exact_contexts"), rec.get("test_scaffold_contexts"), flush=True)
    files = {p.name: sha(p) for p in sorted(prep.glob("*.csv"))}
    save(frozen, dict(targets=targets, files=files, min_exact_for_medians=MIN_EXACT, prepare_external_sha256=sha(Path(a.bundle) / "prepare_external.py"),
                      work36=str(a.work36), work37=str(a.work37), code_sha256={n: sha(Path(__file__).with_name(n)) for n in ["p3_release.py", "p3_common.py", "p3_chembl.py"]},
                      frozen=stamp()))


def cmd_fit(a):
    out = a.output.resolve(); prep = out / "prepared"
    rec = read(out / "RELEASE_PREPARED.json")
    for n, h in rec["files"].items():
        assert sha(prep / n) == h, n
    env = environment(a.test_mode)
    cfg = read(a.model_config)
    fits = out / "fits"; fits.mkdir(exist_ok=True)
    for sym, t in rec["targets"].items():
        if t["state"] != "prepared":
            continue
        feat = Featurizer(cfg["fingerprint"], fake=a.test_mode)
        jobs = [("release_forward", f"{sym}_release_train36.csv", {"exact": f"{sym}_release_test37_exact.csv", "scaffold": f"{sym}_release_test37_scaffold.csv"})]
        jobs += [(f"internal_{r}", f"{sym}_internal36_{r}_train.csv", {"test": f"{sym}_internal36_{r}_test.csv"}) for r in ROUTES]
        for design, trf, tests in jobs:
            dest = fits / f"{sym}_{design}.json"
            if dest.exists():
                continue
            t0 = time.time(); preds = []
            train = pd.read_csv(prep / trf)
            recs = fit_context(feat, train, {k: pd.read_csv(prep / v) for k, v in tests.items()}, cfg["rf"], a.n_jobs, predictions=preds)
            psha = write_predictions(preds, fits / f"{sym}_{design}.predictions.csv.gz") if preds else None
            save(dest, dict(target=sym, design=design, records=recs, predictions_sha256=psha, seconds=round(time.time() - t0, 1),
                            environment=env, finished=stamp()))
            print("FIT", sym, design, round(time.time() - t0, 1), "s", flush=True)
    rows = []
    for p in sorted(fits.glob("*.json")):
        d = read(p)
        rows += [dict(target=d["target"], design=d["design"], **r) for r in d["records"]]
    pd.DataFrame(rows).to_csv(out / "release_runs.csv", index=False)
    save(out / "RELEASE_FIT_STATUS.json", dict(runs=len(rows), model_config_sha256=sha(a.model_config), environment=env, test_mode=a.test_mode, finished=stamp()))
    print("RELEASE FIT COMPLETE", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    for n in ["prepare", "fit"]:
        p = sp.add_parser(n)
        p.add_argument("--output", type=Path, required=True)
        p.add_argument("--work36", type=Path)
        p.add_argument("--work37", type=Path)
        p.add_argument("--bundle", type=Path)
        p.add_argument("--model-config", type=Path)
        p.add_argument("--n-jobs", type=int, default=-1)
        p.add_argument("--test-mode", action="store_true", help="fake features, unpinned environment: LOGIC TEST ONLY")
    a = ap.parse_args()
    dict(prepare=cmd_prepare, fit=cmd_fit)[a.cmd](a)
