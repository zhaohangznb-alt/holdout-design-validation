# Phase-3 protocol: D-MPNN, extended target panel, release-to-release evaluation

Written 2026-10-04T12:23Z, before any phase-3 data were extracted or any phase-3 model was fitted. (An earlier draft of this line gave 12:40Z; the file time is 12:23Z.)

**Authorisation.** The author authorised all three analyses ("全做"), installation of a separate D-MPNN environment, and download of the ChEMBL 36 and 37 SQLite releases to E:.

**Status of results.** Results are descriptive and exploratory. They are reported whatever their direction; the manuscript integration is decided afterwards and documented.

**What stays fixed.** No eligibility rule, label, partition, route definition, model setting or seed of the published analyses is changed.

## Common elements

- **Fixed specifications reused.** Fingerprints, RF/Ridge/1-NN models, seeds 42/53/67, the training-mean baseline, and skill = 1 − MSE_model/MSE_mean are exactly those of `PROTOCOL.md` and `EXTERNAL_PROTOCOL.md`. Fitting uses the pinned environment (`.venv-win`, Python 3.9.10).
- **Automated cleaning.** Where new data are prepared, the database-level cleaning, aggregation, partitioning and scaffold filtering are exactly those of `EXTERNAL_PROTOCOL.md`, implemented by importing `clean()` and `split()` from the unchanged bundle file `prepare_external.py`. No manual source audit is performed; analyses on such data are labelled "automated eligibility".
- **SQLite export.** ChEMBL SQLite data are exported to records with the same field names as the ChEMBL REST responses used by `prepare_external.py`. Each query mirrors the archived API request: `target_chembl_id`, `standard_type = IC50`, `standard_relation = '='`, `standard_flag = 1`; assay fields come from the `assays` table.
- **Exporter guard (P3-0).** For the five archived additional targets (ACHE, DPP4, PTGS2, HDAC1, PDE4D), the ChEMBL 37 SQLite export must reproduce the frozen API responses: the same `activity_id` set and identical values of every field used by `clean()`. `clean()` and `split()` on the export must also reproduce the archived prepared partitions (identical record_uid, smiles and target columns for every route and partition). If the guard fails, the discrepancy is reported, and P3-B and P3-C use the export only with that discrepancy documented.

## P3-A: D-MPNN on the archived partitions

- **Contexts.** All main-view contexts: 6 kinases (curated broad and strict operational cohorts) and 5 additional targets (automated broad and operational cohorts), 4 routes each. Partitions are read from the F1 clean-directory reproduction and hash-checked against the split manifests.
- **Model.** Chemprop 2.2 defaults for single-task regression, no tuning:
  - bond message passing, hidden size 300, depth 3, dropout 0;
  - mean aggregation;
  - one-hidden-layer FFN of width 300;
  - default featuriser;
  - target standardisation fitted on the training labels;
  - batch size 64;
  - default Noam learning-rate schedule;
  - at most 50 epochs, early stopping on validation MSE with patience 10;
  - the best-validation checkpoint predicts the test rows.
- **Data use.** Training rows fit the model, validation rows are used only for early stopping (RF did not use them), and test rows are untouched.
- **Seeds and hardware.** Seeds 42, 53 and 67 (Lightning `seed_everything`). One GPU (RTX 4070 Laptop). GPU non-determinism is recorded, not removed.
- **Baseline and summaries.** Baseline is the mean of the training labels. Three-seed median skill per context. Readouts are the route skills, the within-target YE−SE and SS−SE paired changes, panel medians and the number of targets with lower YE skill, presented beside RF on the same contexts.
- **Smoke step.** One context with 2 epochs, outputs checked before the full run; its output is not a result.

## P3-B: Extended, stratified target panel (automated eligibility)

- **Frame.** Human SINGLE PROTEIN targets in ChEMBL 37 that meet these SQL counts after database-level cleaning:
  - ≥1,500 activity records;
  - ≥1,000 distinct molregno;
  - ≥20 documents;
  - document-year span ≥10 years.
- **Exclusions.** The 11 published targets and CA2.
- **Strata** (ChEMBL protein classification of the target's single component):
  - Kinase;
  - Protease;
  - Other enzyme;
  - Membrane receptor;
  - Ion channel;
  - Transcription factor;
  - Epigenetic regulator;
  - Transporter;
  - Other.
- **Sampling.**
  - Within each stratum, targets are ordered by `numpy.random.default_rng(20261004 + stratum index).permutation` of the sorted target ChEMBL IDs. Strata are indexed in the order listed above.
  - The first five targets in each stratum that pass the full `EXTERNAL_PROTOCOL.md` screening are selected; this includes ≥100 test contexts in both exact routes.
  - Targets that fail screening are recorded and replaced by the next target in the same stratum's order.
  - A stratum with fewer than five eligible targets contributes all of its eligible targets.
- **Selection is score-blind.** The selection list is frozen (hashes written) before any fit.
- **Models.** RF (3 seeds), Ridge and 1-NN on the broad and operational cohorts and all four routes, exactly as for the additional panel.
- **Primary readout.** Per target, the RF YE−SE and SS−SE paired skill changes, using the three-seed medians.
- **Population summary over the sampled frame.**
  - Median and mean paired change.
  - 95% percentile intervals from 10,000 stratified bootstrap resamples of targets (targets resampled within strata, seed 20261004).
  - The proportion of targets with lower YE skill, with a Wilson interval.
  - Stratum medians.
- **Secondary readouts.** The same summaries for Ridge and 1-NN, and for the operational cohort.
- **Interpretation.** These summaries describe the sampled frame of well-populated ChEMBL 37 human targets, with automated eligibility. They are not a census of all targets, and no causal decomposition is attempted.

## P3-C: Release-to-release (ChEMBL 36 → 37) evaluation, automated eligibility

- **Targets.** The 11 published targets.
- **Data.**
  - Each release is exported and cleaned separately with the same automated rules, then aggregated to contexts with `clean()`.
  - **Training set:** all ChEMBL 36 contexts of the target.
  - **Prospective test set:** ChEMBL 37 contexts whose `document_chembl_id` does not occur among the target's ChEMBL 36 activity records (new documents). This is applied in two tiers:
    - exact tier: test structures that occur in the training set are removed;
    - scaffold tier: training scaffolds are removed as well.
  - The test labels are those of ChEMBL 37.
- **Internal routes on ChEMBL 36 data.** `split()` gives source-document and document-year routes with exact and scaffold tiers, evaluated on their own test sets. These are the evaluation designs that a user holding only ChEMBL 36 could run.
- **Models.** RF (3 seeds), Ridge and 1-NN, trained on the full ChEMBL 36 context set (release forward), or on each internal route's training partition (internal routes).
- **Readouts.**
  - Per target: release-forward skill and absolute errors, and skill on each internal route.
  - The agreement of each internal route with release-forward skill: absolute difference, per target and median across targets.
- **Reporting threshold.** Targets with fewer than 30 prospective exact-tier test contexts are reported but marked, and they are excluded from the cross-target medians. Counts of new documents and contexts are reported for every target.
- **Interpretation.** Descriptive. One release step is a single, short prospective window.

## Clarifications (2026-10-04T12:30Z, before any phase-3 data were extracted)

- **C1 Working extract.** Each release file is opened read-only. A working SQLite extract is built from it with the columns needed by the exporter and the activity rows with `standard_type = IC50`, `standard_relation = '='` and `standard_flag = 1` (the filters of the archived API request). All exports read the extract. The P3-0 guard therefore checks the whole chain from release file to prepared partitions.
- **C2 Strata.** Level-1 and level-2 classes are taken from `protein_classification.class_level` along the lineage of each component classification. If a component has more than one classification, the lowest `protein_class_id` is used. Level 1 "Enzyme" is split into Kinase and Protease (level 2) and Other enzyme; level-1 classes not listed in the strata are "Other".
- **C3 Frame counts and screening.** The SQL counts (activities, distinct molregno, documents, year span) define the frame. Selection then requires the full `EXTERNAL_PROTOCOL.md` screen on the output of `clean()` and `split()`, where molecules are distinct RDKit canonical SMILES. A target whose `clean()` or `split()` raises an error fails screening, and the error is recorded.
- **C4 Release-to-release details.** P3-C uses the broad cohort only. "New documents" are documents that do not occur among the target's exported ChEMBL 36 records, counted before cleaning. Agreement pairs the exact tier with `source_exact` and `temporal_exact`, and the scaffold tier with `source_scaffold` and `temporal_scaffold`. The exact tier is primary.
- **C5 Inherited labels.** `clean()` writes `source_uid` with the prefix `chembl37_activity_` and `record_uid` with the prefix `ext37_` whatever the release. These labels come from the unchanged bundle code and do not identify the release. `record_uid` is a hash of the target ID and the context fields, so it is comparable across releases.
- **C6 Kinases in P3-C.** The six kinases are prepared with the automated `clean()` from their target IDs, not with the curated kinase preparation. Their P3-C results therefore describe automated cohorts.
- **C7 RF comparators in P3-A.** RF values are the archived three-seed median skills of the same contexts (`results/analysis/target_metrics.csv` of the verified bundle), which F1 reproduced.
- **C8 D-MPNN checkpoint.** The best-validation weights are kept in memory (state copied at each improvement of `val_loss`) instead of being written to and reloaded from a checkpoint file. Batch normalisation is off, which is the Chemprop 2.2 default. The effective hyperparameters are written with each run.
- **C9 Partition integrity in P3-A.** The D-MPNN environment has its own pandas version, so partitions are checked by SHA-256 and row count against the split manifests. The pandas-dependent ordered signature is recorded but not required.

## Deviations

### D-P3-1: R5 post hoc random-intercept REML analysis (2026-10-05T05:06:12.754630+00:00)

Registered BEFORE fitting the hierarchical model. The author requested a hierarchical supplement because the original planning mentioned hierarchical inference, whereas the implemented P3-B protocol used stratified target bootstrap. The original stratified bootstrap remains PRIMARY. No prediction model is refitted and no target, cohort, route, label or split is changed.

Response: per-target paired skill change, calculated after taking the three RF-seed medians within each route. Model: change ~ 1 + (1 | stratum), independent Gaussian stratum intercepts with variance tau^2 and independent Gaussian target residuals with variance sigma^2. Fit by REML with nonnegative variance components, explicitly checking the tau=0 boundary. Primary supplemental fit: broad RF YE-SE (42 targets, 9 strata). Secondary supplemental fits: broad RF SS-SE, operational RF YE-SE, operational RF SS-SE, using complete route pairs only. Do not pool the two cohorts.

Report the GLS intercept (a model-based MEAN, not the primary bootstrap MEDIAN), its estimated SE and nominal 95% normal-Wald interval, between-stratum SD tau, residual SD, stratum sample counts and conditional BLUP/shrinkage means. Predeclare an additional approximate t_(G-1) interval as a small-group sensitivity (G=number of represented strata); it is NOT a Satterthwaite or Kenward-Roger correction. No p-values or significance-based model selection. Estimated-variance intervals do not fully account for variance-component uncertainty.

Only nine strata are represented; Other has two selected targets. The panel was selected score-blind from a filtered, well-populated human-target frame and is not a simple random sample of all ChEMBL targets. Treat protein classes as exchangeable for this supplemental model and discuss that assumption. Do not infer the entire ChEMBL population, a causal effect or nine independent replications of a training intervention. The operational panel uses available complete pairs and is not silently imputed.

Implementation: existing Python/NumPy/SciPy only, no package installation. Profile the REML criterion analytically over lambda=tau^2/sigma^2; validate against a separately implemented full-covariance Cholesky REML optimization and balanced-data analytic cases, including zero-variance boundaries. Record convergence, boundary checks and tolerances. Scripts/results reside in outputs/round2/results/p3/hierarchical INSIDE this isolated R5 worktree; original R3/R4 results and the original protocol remain untouched.

### D-P3-2: inherited aggregation corrections (2026-10-05T05:06:12.754630+00:00)

The R5 task's example S27 confidence bounds are superseded by the previous Codex audit. Whole-target bootstrap retains both cohorts of each of 11 targets, rather than resampling 22 dependent target-cohort rows as independent. S29 is aggregated separately by model; RF uses only seeds 42/53/67, rather than mixing three RF runs with Ridge and 1-NN. Copy the previously corrected summaries with hashes and independently verify their manuscript values from archived run tables. This records correction provenance, not a claim that these corrections were prespecified before phase-3 fitting.

### D-P3-3: release-transition terminology (2026-10-05T05:06:12.754630+00:00)

Report P3-C as a historical cross-release evaluation. Documents absent from a target's filtered ChEMBL 36 export can include backfilled older publications (including 2021 EGFR records). This is not genuine forward experimental collection or database-wide document novelty. Designs, eligibility thresholds and existing runs remain unchanged.


Any deviation found during execution is recorded here with its date, before the affected results are reported.

- **E1 (2026-10-04T17:10Z, before any phase-3 data were extracted or any phase-3 model was fitted).** The author asked for training to start directly once the downloads and the environment are ready ("完成后直接开始训练"). The P3-A smoke step is therefore checked automatically. The full D-MPNN run starts only if `SMOKE_CHECK.json` passes all of the following checks:
  - predictions are finite and complete;
  - exactly 2 epochs were run;
  - the prediction mean lies within the training-label range;
  - validation MSE recomputed from the best weights agrees with `val_loss`·σ² within 10⁻³ relative;
  - batch normalisation is off.

  The partition signature is recorded but is not a gate (C9). The chain (`run_phase3_chain.ps1`) runs these tracks:
  - **GPU:** environment → smoke → full D-MPNN in its own window.
  - **CPU:** ChEMBL releases → P3 prep (selection and release inputs frozen before any fit) → wait for the F2 resume → P3-B/P3-C fits → summaries.

  No eligibility rule, model setting, seed or readout is changed. The setup script now resumes a partial archive instead of skipping it. A failed download is set aside under a new name, not deleted.
- **E2 (2026-10-04T18:35Z, before any phase-3 data were extracted or any model was fitted).** At 17:23:30Z the PC entered Modern Standby after the display timed out. The ChEMBL 37 download (14%) and the environment installation were suspended, not terminated. Keep-awake now includes ES_DISPLAY_REQUIRED, and `KEEP_AWAKE.bat` holds the system and display awake for jobs that are already running. Nothing else changes.
- **E3 (2026-10-05T01:45Z; D-MPNN smoke passed, no phase-3 data extracted, no P3-B/P3-C model fitted).** The phase-3 chain was restarted at 01:19Z. The environment was then ready, the smoke gate passed at 01:31:59Z and the full D-MPNN run started. At about 01:39Z the author closed the terminal windows; by then 24 of 264 D-MPNN runs were complete and ChEMBL 37 was partly downloaded. On the author's instruction the chain was restarted at 01:42Z in minimised windows (`START_ALL_MINIMIZED.bat`). D-MPNN run records are written atomically after each fit. Completed runs are skipped, and an interrupted run is refitted from the start with the same seed. The ChEMBL 37 archive resumes from its partial file. Nothing else changes.

## Logic tests (cloud, 2026-10-04, not results)

Before the drivers were sent to the PC they were exercised end to end in the cloud with the RDKit calls replaced by a
deterministic identity stub and the releases replaced by synthetic SQLite files built from the frozen API JSON (the five
additional targets and CA2, plus clones carrying the kinase and synthetic-frame target IDs). These runs confirm only the
control flow, the freezing of selections and inputs, the manifests and the summaries. No number from them is reported.
- `p3_chembl build` builds the working extract and the exporter reproduces the frozen API fields.
- `p3_guard_exporter` passes when the export matches and fails (exit 3) on an injected record drop, a changed `pchembl_value`
  and a changed assay `bao_format`, with the offending field named.
- `p3_panel frame/screen/fit` produces a seeded per-stratum order, freezes the selection before fitting, and writes the
  run table; `p3_release prepare/fit` freezes the model inputs and writes the run table; `p3_summarize` produces the P3-A,
  P3-B and P3-C readouts including the stratified bootstrap and Wilson intervals.
The D-MPNN driver (`p3_dmpnn`) is written to the published Chemprop 2.2 API and is checked on the PC by its `--smoke` step,
since the cloud has neither PyTorch nor Chemprop.
