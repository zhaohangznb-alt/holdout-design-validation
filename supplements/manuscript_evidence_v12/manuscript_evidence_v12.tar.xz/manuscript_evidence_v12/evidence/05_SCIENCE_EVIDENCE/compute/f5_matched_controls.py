"""F5: label-matched and period-restricted source pools on the published common test intersections.
Protocol: PROTOCOL_ROUND2.md (section F5 with Amendment A1). Checkpointed per fit; restartable; no model binaries kept."""
import argparse, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from r2common import TARGETS, panel_of, sha, save, read, stamp, environment, Featurizer, rf_model, csv, ridge_fit_predict, nn_predict

DRAWS = [101, 211, 307, 401, 503]
SEEDS = [42, 53, 67]


def stratified(source, year, key, rng):
    """Sample len(year) source positions matching the year-pool distribution of `key` strata (deficit filled uniformly)."""
    need = year[key].value_counts().sort_index()
    have = source[key].to_numpy()
    chosen, deficit = [], 0
    for s, n in need.items():
        pos = np.flatnonzero(have == s)
        if len(pos) >= n:
            chosen.extend(rng.choice(pos, size=n, replace=False).tolist())
        else:
            chosen.extend(pos.tolist()); deficit += n - len(pos)
    if deficit:
        rest = np.setdiff1d(np.arange(len(source)), np.array(chosen, dtype=int))
        chosen.extend(rng.choice(rest, size=deficit, replace=False).tolist())
    chosen = np.sort(np.array(chosen, dtype=int))
    assert len(chosen) == len(year) and len(set(chosen)) == len(chosen)
    return chosen, int(deficit)


def label_bins(year_y):
    edges = np.quantile(year_y, np.linspace(0, 1, 11))
    edges[0], edges[-1] = -np.inf, np.inf
    return edges


def plan_arms(source, year):
    """Return list of (arm, draw, positions-in-pool, pool-name, deficit, info)."""
    arms = []
    edges = label_bins(year.target.to_numpy(float))
    s_bins = pd.Series(np.digitize(source.target, edges[1:-1], right=True))
    y_bins = pd.Series(np.digitize(year.target, edges[1:-1], right=True))
    cutoff = int(year.document_year.max())
    hist = np.flatnonzero(source.document_year.to_numpy() <= cutoff)
    nh = len(hist)
    assert 0 < nh < len(year), (nh, len(year))
    arms.append(("period_source", 0, hist, "source", 0, dict(cutoff=cutoff, n=nh)))
    for draw in DRAWS:
        pos, deficit = stratified(pd.DataFrame({"b": s_bins}), pd.DataFrame({"b": y_bins}), "b", np.random.RandomState(draw + 7))
        arms.append(("label_matched_source", draw, pos, "source", deficit, dict(cutoff=cutoff, n=len(pos))))
        arms.append(("random_source_nh", draw, np.sort(np.random.RandomState(draw + 17).choice(len(source), size=nh, replace=False)), "source", 0, dict(cutoff=cutoff, n=nh)))
        arms.append(("random_year_nh", draw, np.sort(np.random.RandomState(draw + 19).choice(len(year), size=nh, replace=False)), "year", 0, dict(cutoff=cutoff, n=nh)))
    return arms


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--snapshot", type=Path, required=True, help="extracted controlled_comparison/ directory")
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--n-jobs", type=int, default=-1)
    ap.add_argument("--targets", default=",".join(TARGETS))
    ap.add_argument("--fake-features", action="store_true", help="TEST ONLY: random features, never a result")
    ap.add_argument("--summarize-only", action="store_true")
    ap.add_argument("--models", default="rf", help="comma list of rf, ridge, tanimoto1nn (Amendment A3 adds ridge and tanimoto1nn)")
    a = ap.parse_args()
    snap = a.snapshot.resolve(); out = a.output.resolve()
    out.mkdir(parents=True, exist_ok=True); (out / "fits").mkdir(exist_ok=True); (out / "samples").mkdir(exist_ok=True)
    env = environment(a.fake_features)
    ih = read(snap / "INPUT_HASHES.json"); cfg = read(snap / "MODEL_CONFIG.json")
    targets = a.targets.split(",")
    models = a.models.split(",")
    if not a.summarize_only:
        save(out / f"command_{time.time_ns()}.json", dict(argv=sys.argv, started=stamp(), environment=env))
        feat = Featurizer(cfg["fingerprint"], fake=a.fake_features)
        diag = []
        for t in targets:
            files = {k: f"inputs/{n}" for k, n in [("test", f"common_test_{t}.csv"), ("source", f"train_{t}_source_exact_full.csv"), ("year", f"train_{t}_temporal_exact_full.csv")]}
            for f in files.values():
                assert sha(snap / f) == ih[f], f
            test, source, year = (csv(snap / files[k]) for k in ("test", "source", "year"))
            Xte = feat.matrix(test.smiles); yte = test.target.to_numpy(float)
            pools = {"source": (source, feat.matrix(source.smiles)), "year": (year, feat.matrix(year.smiles))}
            for arm, draw, pos, pool, deficit, info in plan_arms(source, year):
                frame, Xp = pools[pool]
                samp = frame.iloc[pos]
                tag = f"{t}_{arm}" + (f"_s{draw}" if draw else "")
                pd.DataFrame({"position": pos, "record_uid": samp.record_uid.to_numpy()}).to_csv(out / "samples" / f"{tag}.csv", index=False)
                yh = year.document_year.value_counts(normalize=True); sh = samp.document_year.value_counts(normalize=True)
                diag.append(dict(panel=panel_of(t), target=t, arm=arm, draw_seed=draw, pool=pool, n=len(pos), deficit=deficit,
                                 year_route_training_end=info["cutoff"], sample_label_mean=float(samp.target.mean()),
                                 sample_label_sd=float(samp.target.std(ddof=0)), year_pool_label_mean=float(year.target.mean()),
                                 year_pool_label_sd=float(year.target.std(ddof=0)), source_pool_label_mean=float(source.target.mean()),
                                 share_rows_after_training_end=float((samp.document_year > info["cutoff"]).mean()),
                                 year_histogram_tv_vs_year_pool=0.5 * float(sum(abs(yh.get(k, 0) - sh.get(k, 0)) for k in set(yh.index) | set(sh.index)))))
                ytr = samp.target.to_numpy(float)
                for model in [m_ for m_ in models if m_ != "rf"]:
                    rec_p = out / "fits" / f"{tag}_{model}.json"
                    if rec_p.exists():
                        continue
                    t0 = time.time()
                    pred = ridge_fit_predict(Xp[pos], ytr, Xte) if model == "ridge" else nn_predict(Xp[pos], ytr, Xte)
                    mean = float(ytr.mean())
                    mse = float(np.mean((yte - pred) ** 2)); base = float(np.mean((yte - mean) ** 2))
                    save(rec_p, dict(panel=panel_of(t), target=t, arm=arm, draw_seed=draw, pool=pool, model=model, rf_seed=None, train_n=int(len(pos)),
                                     test_n=int(len(yte)), deficit=deficit, mse=mse, baseline_mse=base, training_mean_skill=1 - mse / base,
                                     training_mean=mean, fit_seconds=time.time() - t0, mode=env["mode"], completed=stamp()))
                    print("DONE", rec_p.name, round(time.time() - t0, 1), "s", flush=True)
                if "rf" not in models:
                    continue
                for seed in SEEDS:
                    rec_p = out / "fits" / f"{tag}_rf_{seed}.json"
                    if rec_p.exists():
                        continue
                    t0 = time.time()
                    m = rf_model(cfg["rf"], seed, a.n_jobs).fit(Xp[pos], ytr)
                    pred = m.predict(Xte); mean = float(ytr.mean())
                    mse = float(np.mean((yte - pred) ** 2)); base = float(np.mean((yte - mean) ** 2))
                    save(rec_p, dict(panel=panel_of(t), target=t, arm=arm, draw_seed=draw, pool=pool, rf_seed=seed, train_n=int(len(pos)),
                                     test_n=int(len(yte)), deficit=deficit, mse=mse, baseline_mse=base, training_mean_skill=1 - mse / base,
                                     training_mean=mean, fit_seconds=time.time() - t0, mode=env["mode"], completed=stamp()))
                    print("DONE", rec_p.name, round(time.time() - t0, 1), "s", flush=True)
            pd.DataFrame(diag).to_csv(out / "f5_matching_diagnostics.csv", index=False)
    summarize(snap, out, targets, env)


def summarize(snap, out, targets, env):
    allfits = pd.DataFrame([read(p) for p in sorted((out / "fits").glob("*.json"))])
    if allfits.empty:
        print("no fits yet"); return
    if "model" not in allfits:
        allfits["model"] = "rf"
    allfits["model"] = allfits["model"].fillna("rf")
    summarize_by_model(snap, out, allfits)
    fits = allfits[allfits.model == "rf"].copy()
    fits.to_csv(out / "f5_fits.csv", index=False)
    arm = fits.groupby(["panel", "target", "arm", "draw_seed"]).agg(mse=("mse", "median"), n_seeds=("mse", "size"), train_n=("train_n", "first")).reset_index()
    arm = arm[arm.n_seeds == 3]
    pdc = csv(snap / "analysis/per_draw_contrasts.csv")
    ref = pdc[pdc.model == "rf"].set_index(["target", "draw_seed"])
    rows = []
    for t in sorted(arm.target.unique()):
        g = arm[arm.target == t].set_index(["arm", "draw_seed"])
        for draw in DRAWS:
            r = dict(panel=g.reset_index().panel.iloc[0], target=t, draw_seed=draw)
            if (t, draw) in ref.index:
                x = ref.loc[(t, draw)]
                r.update(year_full_mse=x.year_full_mse, size_only_pool_contrast=x.matched_pool)
                if ("label_matched_source", draw) in g.index:
                    r["label_matched_pool_contrast"] = x.year_full_mse - g.loc[("label_matched_source", draw), "mse"]
            if ("period_source", 0) in g.index and ("random_source_nh", draw) in g.index:
                r["recency_within_source"] = g.loc[("period_source", 0), "mse"] - g.loc[("random_source_nh", draw), "mse"]
            if ("period_source", 0) in g.index and ("random_year_nh", draw) in g.index:
                r["year_vs_period_source"] = g.loc[("random_year_nh", draw), "mse"] - g.loc[("period_source", 0), "mse"]
            rows.append(r)
    per = pd.DataFrame(rows)
    per.to_csv(out / "f5_per_draw_contrasts.csv", index=False)
    cols = [c for c in ["size_only_pool_contrast", "label_matched_pool_contrast", "recency_within_source", "year_vs_period_source"] if c in per]
    agg = {}
    for c in cols:
        agg[c + "_median"] = (c, "median"); agg[c + "_min"] = (c, "min"); agg[c + "_max"] = (c, "max")
    summ = per.groupby(["panel", "target"]).agg(**agg).reset_index()
    summ.to_csv(out / "f5_target_summary.csv", index=False)
    counts = {c: dict(targets=int(summ[c + "_median"].notna().sum()), positive_median=int((summ[c + "_median"] > 0).sum())) for c in cols}
    save(out / "F5_STATUS.json", dict(completed_fits=int(len(fits)), planned_fits=len(targets) * (15 + 3 + 15 + 15), counts=counts, mode=env["mode"], summarized=stamp(),
                                      other_model_fits={m_: int((allfits.model == m_).sum()) for m_ in sorted(set(allfits.model) - {"rf"})}))
    print(summ.round(4).to_string(index=False)); print(counts)


def summarize_by_model(snap, out, allfits):
    """Amendment A3: the same four contrasts for every model (RF = three-seed median; Ridge and 1-NN deterministic)."""
    pdc = csv(snap / "analysis/per_draw_contrasts.csv")
    arm = allfits.groupby(["model", "panel", "target", "arm", "draw_seed"]).mse.median().reset_index()
    rows = []
    for (model, t), g in arm.groupby(["model", "target"]):
        g = g.set_index(["arm", "draw_seed"]).mse
        ref = pdc[(pdc.model == model) & (pdc.target == t)].set_index("draw_seed")
        for draw in DRAWS:
            r = dict(model=model, panel=panel_of(t), target=t, draw_seed=draw)
            if draw in ref.index:
                r["size_only_pool_contrast"] = ref.loc[draw, "matched_pool"]
                if ("label_matched_source", draw) in g.index:
                    r["label_matched_pool_contrast"] = ref.loc[draw, "year_full_mse"] - g[("label_matched_source", draw)]
            if ("period_source", 0) in g.index and ("random_source_nh", draw) in g.index:
                r["recency_within_source"] = g[("period_source", 0)] - g[("random_source_nh", draw)]
            if ("period_source", 0) in g.index and ("random_year_nh", draw) in g.index:
                r["year_vs_period_source"] = g[("random_year_nh", draw)] - g[("period_source", 0)]
            rows.append(r)
    per = pd.DataFrame(rows)
    per.to_csv(out / "f5_per_draw_contrasts_by_model.csv", index=False)
    cols = [c for c in ["size_only_pool_contrast", "label_matched_pool_contrast", "recency_within_source", "year_vs_period_source"] if c in per]
    agg = {}
    for c in cols:
        agg[c + "_median"] = (c, "median"); agg[c + "_min"] = (c, "min"); agg[c + "_max"] = (c, "max")
    per.groupby(["model", "panel", "target"]).agg(**agg).reset_index().to_csv(out / "f5_target_summary_by_model.csv", index=False)


if __name__ == "__main__":
    main()
