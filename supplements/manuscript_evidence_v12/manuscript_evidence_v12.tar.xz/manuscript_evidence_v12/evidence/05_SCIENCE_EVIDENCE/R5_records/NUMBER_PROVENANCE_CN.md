# R5 新增数字来源

每个新增结果表单元格及 Results 数字在 `outputs/reports/CSV_CROSSCHECK.csv` 中逐项比对。设计 / 版本 / 日期来自以下执行记录与协议；它们不作为新的模型结果。核验统计包括数值、表格文字、计数及真假检查，不能解释为 8162 个独立科学估计。

## S27 outcome/absolute errors

文件：`outputs/round2/results/p3/dmpnn/dmpnn_runs.csv; outputs/round2/compute/archived_rf_target_metrics.csv`

列 / 计算：scenario,target,route,model,seed,skill,mse_model,mse_mean,mae_model,mae_mean; main-view RF comparator; whole-target bootstrap

## S27 integrity/environment/design

文件：`outputs/round2/results/p3/dmpnn/DMPNN_INPUTS.json; DMPNN_COMPLETE.json; outputs/round2/compute/PROTOCOL_PHASE3.md`

列 / 计算：partition_checks.sha256_ok/rows_ok/signature_equal; environment; P3-A hyperparameters/seeds and C8/C9

## S28 outcomes

文件：`outputs/round2/results/p3/panel/panel_runs.csv`

列 / 计算：scenario,target,route,model,seed,skill,test_rows; seed-median paired changes; 10000 within-stratum target bootstrap; Wilson count intervals

## S28 frame/selection/timing

文件：`outputs/round2/results/p3/panel/FRAME_COMPLETE.json; frame_eligible.csv; PANEL_SELECTION_FROZEN.json; screen_log.csv; PANEL_FIT_STATUS.json`

列 / 计算：eligible; thresholds; selected.stratum/target_chembl_id/pref_name/symbol; unavailable; frozen_at; fit timing; screening row count

## S29 outcomes/counts

文件：`outputs/round2/results/p3/release/release_runs.csv; RELEASE_PREPARED.json`

列 / 计算：model,seed,target,design,test_set,skill,mae_model; per-target model-specific medians; targets.test_exact_contexts/test_scaffold_contexts/new_documents/train_contexts/below_min_exact/new_document_years

## S30 means/intervals/shrinkage

文件：`outputs/round2/results/p3/panel/panel_runs.csv; PANEL_SELECTION_FROZEN.json; hierarchical/hierarchical_reml.py`

列 / 计算：RF three-seed route medians; selected.stratum; independent profile and full-covariance REML; model_summary and stratum_shrinkage columns

## Stage/version identifiers, threshold/replicate metadata

文件：`outputs/round2/compute/PROTOCOL_PHASE3.md; outputs/round5_records/PROTOCOL_REGISTRATION.json`

列 / 计算：P3-A/B/C; D-P3-1/2/3; ChEMBL36/37; min exact 30; seed20261004; bootstrap10000; normal95% and t8 interval definitions
