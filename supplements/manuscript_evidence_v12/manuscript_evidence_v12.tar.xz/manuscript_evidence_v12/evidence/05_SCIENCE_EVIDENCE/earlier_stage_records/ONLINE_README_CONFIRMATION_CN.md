# 指定公开提交 README 的确认记录

核对日期：2026-10-04（Asia/Singapore）。
核对方式：父流程网页读取工具成功读取精确提交 raw README；GitHub目录页读取失败。
链接：https://raw.githubusercontent.com/zhaohangznb-alt/holdout-design-validation/a499bde50f98f3419be9bf96dfc8464f8119e69b/supplements/representative_replay/README.md
标题：Representative Windows and Linux replay

实际读到的内容支持以下事实：
- README位于指定提交的 supplements/representative_replay/。
- 分别描述Windows与Linux代表性回放；两者均重建408张输入表、完成6次RF拟合和2次1-NN索引。
- Windows两份NN CSV字节一致；Linux数值一致而CSV序列化字节不同，所有数值列满足1e-12容差。
- 指向 linux_replay_checks.json、LINUX_RUN_PROVENANCE.json 与执行run 37128892159。
- 明确全量680-case干净目录重训练在两平台均未完成。

这是父流程提供的网页确认摘要。原包37项公开下载核验的记录来自FINAL_STATUS.json，本次没有重复下载全部文件；也没有运行训练、评分或重采样。
