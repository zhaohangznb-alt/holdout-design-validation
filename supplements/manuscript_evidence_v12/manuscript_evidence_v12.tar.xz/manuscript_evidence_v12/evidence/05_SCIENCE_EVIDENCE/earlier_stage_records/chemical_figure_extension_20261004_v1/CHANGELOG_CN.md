# 修改记录

基线：counterexample_clarification_20261004_v1/02_editable_source。

1. 新建三张原生 ChemDraw 化学插图，均保留完整原子、键、立体化学及断连分量。蓝色表示共享 Murcko 骨架或最大片段；橙色表示 ALK 手性差异或 S10 共同结构之外的基团。新增图不使用卡片布局。
2. Figure 1 保留原矢量图的全部原内容，在 (b)/(c) 之间插入同骨架的 ALK 完整结构示例。原图未重绘；新图高度增加 158 pt。
3. 主文 L91 的 Figure 1 图注增加结构示例与 S9 A1/A2 对应关系；L352 的 Figure 7 图注增加 S10 最近邻结构对照的引用。
4. SI 开头的内容说明增加 S7(e,f)、S10。L1046 起增加 S7 结构续页，使用 ContinuedFloat 保留 S7 编号；原 S7 统计页和文件原样保留。后续 S8/S9 仍为原编号。
5. SI 的匹配训练池说明中更新了此前“Figures 1--6 remain unchanged”的文字，以准确反映 Figure 1 新增图示，其数值分析未改。
6. SI L3065 起增加 S10、完整方法图注、记录 ID、选例原则和精确相似度分数。S10 不使用 S9 记录代替实际匹配训练池近邻。
7. 正式编译主文 21 页、SI 57 页。SI 在原 55 页基础上增加 S7 续页和 S10 两页。
8. 最终核验：9 条原生保存与 CDX 重开结构均完整一致；39 个来源文件和 23 个基线文件未改。独立副本相对基线只有两份 TeX 和 Figure 1 为已有文件的修改，另新增 S7 化学图和 S10。

原始表格、公式、引用顺序、前导区、原 S9 图文件、TOC、其他统计图及数据保持原样。没有新训练、模型评分或外部提交。

可复核结果：NATIVE_VERIFICATION.json、FINAL_VERIFICATION.json、review/VISUAL_AUDIT_CN.md、COMPILE_STATUS.json。
