# R5：事后层级模型

这项补充在 R5 副本的 `PROTOCOL_PHASE3.md` 登记 D-P3-1 后实施。Table S28 的分层靶点 bootstrap 仍是主分析；S30 的模型均值不替换 S28 的面板中位数。

模型为 `change = mu + b_stratum + epsilon_target`，类别随机截距服从均值零、方差 tau² 的正态分布，靶点残差服从方差 sigma² 的独立正态分布。每条响应先由 RF 三个种子的路线中位数相减得到。两队列、两对比各自拟合，不合并，不插补缺失路线。

## 计算与核验

`hierarchical_reml.py` 使用现有 NumPy / SciPy，无新增安装。设 lambda=tau²/sigma²，类别大小 n_g，类别原始均值 ybar_g。权重为 w_g=n_g/(1+n_g lambda)，mu=sum(w_g ybar_g)/sum(w_g)。Q 为类别内平方和加 sum[w_g(ybar_g-mu)²]，sigma²=Q/(N-1)。所最小化的 profile REML criterion（省略常数）为：

`0.5 * [(N-1) log(Q/(N-1)) + sum log(1+n_g lambda) + log sum(w_g)]`。

先扫描非负方差比，再用解析一阶导数定位内部最优点，同时比较 lambda=0 边界。独立核验建立完整的 `V=sigma² I + tau² ZZ'`，用 Cholesky 分解和二参数数值优化评估 REML，检查均值、标准差、SE 与 likelihood；另检验平衡数据的 ANOVA 闭式 REML 结果及零类别方差边界。四项实际拟合的独立检查和三个解析案例均通过，误差及收敛状态保存在 JSON。

均值 SE 为 `sqrt(sigma²/sum(w_g))`。主补充区间是使用估计方差的 normal-Wald 区间；同时列出 t_(G-1) 区间作为小组数的近似敏感性。后者不是 Kenward–Roger 或 Satterthwaite 方法。两者都没有完整纳入方差分量的估计不确定性。

类别随机截距的 BLUP 为 `[n_g tau²/(sigma²+n_g tau²)] * (ybar_g-mu)`；类别收缩均值为 mu 加该 BLUP。CSV 同时保留未收缩均值、收缩权重和样本数。没有为类别均值生成置信区间或做显著性筛选。

## 解释

只有九个类别，Other 只有两个选中靶点。该模型把类别视为可交换；类别间标准差是模型描述，不是全部 ChEMBL 靶点总体的估计。靶点来自记录量和文献跨度筛选后的分层面板，并非全体靶点的简单随机样本。类别的中位数、原始均值和收缩均值是不同统计量；例如膜受体 / 转录因子的原始中位数接近零，不表示其模型收缩均值也为零。

## 文件

- `analysis_input.csv`：逐靶点的响应、类别、队列和对比。
- `model_summary.csv`：四项拟合的均值、两个区间、类别 / 残差 SD。
- `stratum_shrinkage.csv`：各类别的收缩结果及计数。
- `HIERARCHICAL_RESULTS.json`：协议时间、数值校验、完整精度结果。

运行：在既有 NumPy/SciPy 环境执行 `python hierarchical_reml.py`。它只读取相邻的原始运行表与冻结选择记录，不重训练预测模型。

随机截距与 REML 的软件接口说明可参见 [MixedLM 官方文档](https://www.statsmodels.org/stable/generated/statsmodels.regression.mixed_linear_model.MixedLM.html) 和 [REML 拟合接口](https://www.statsmodels.org/stable/generated/statsmodels.regression.mixed_linear_model.MixedLM.fit.html)。本交付没有安装或调用 statsmodels；上述链接用于方法接口参考，实际实现和独立数值检验均随包提供。
