"""One-way Gaussian random-intercept REML; existing SciPy, no installations.

Profile criterion (constants omitted), lambda=tau^2/sigma^2:
 .5*((N-1)*log(Q/(N-1))+sum(log(1+n_g*lambda))+log(sum(w_g)))
 w_g=n_g/(1+n_g*lambda); mu=sum(w_g*ybar_g)/sum(w_g)
 Q=within-group SS+sum(w_g*(ybar_g-mu)^2).
Full-covariance Cholesky REML below supplies an independent numerical check.
"""
from pathlib import Path
import json,hashlib,datetime
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar,minimize,brentq
from scipy.linalg import cho_factor,cho_solve
from scipy.stats import norm,t

HERE=Path(__file__).resolve().parent
P3=HERE.parent

def fit_profile(y,groups):
 y=np.asarray(y,float); groups=np.asarray(groups)
 names=sorted(set(groups)); ns=np.array([sum(groups==g) for g in names],float)
 means=np.array([y[groups==g].mean() for g in names]); N=len(y)
 within=sum(np.sum((y[groups==g]-means[i])**2) for i,g in enumerate(names))
 def criterion(z,details=False):
  lam=np.expm1(z); w=ns/(1+ns*lam)
  mu=np.dot(w,means)/w.sum(); Q=within+np.dot(w,(means-mu)**2)
  sig2=Q/(N-1)
  f=.5*((N-1)*np.log(sig2)+np.log1p(ns*lam).sum()+np.log(w.sum()))
  return (f,lam,mu,sig2,w) if details else f
 def derivative(z):
  lam=np.expm1(z);w=ns/(1+ns*lam);mu=np.dot(w,means)/w.sum()
  Q=within+np.dot(w,(means-mu)**2)
  Qprime=-np.dot(w*w,(means-mu)**2)
  return .5*((N-1)*Qprime/Q+w.sum()-(w*w).sum()/w.sum())*np.exp(z)
 grid=np.linspace(0,20,401); vals=np.array([criterion(z) for z in grid])
 i=int(vals.argmin()); assert i<len(grid)-1,'Minimum hits search upper boundary'
 candidates=[(criterion(0),0.0)]
 if i>0 or derivative(0)<0:
  lo=grid[max(0,i-1)];hi=grid[i+1]
  opt=minimize_scalar(criterion,bounds=(lo,hi),method='bounded',options={'xatol':1e-12})
  assert opt.success
  root=brentq(derivative,lo,hi,xtol=1e-13)
  candidates.append((criterion(root),root))
 z=min(candidates)[1]; f,lam,mu,sig2,w=criterion(z,True); tau2=lam*sig2
 se=np.sqrt(sig2/w.sum()); normal=norm.ppf(.975); tc=t.ppf(.975,len(names)-1)
 alpha=ns*tau2/(sig2+ns*tau2)
 out={'n_targets':N,'n_strata':len(names),'mean':mu,'mean_se':se,'normal_ci_low':mu-normal*se,'normal_ci_high':mu+normal*se,
      't_sensitivity_low':mu-tc*se,'t_sensitivity_high':mu+tc*se,'t_sensitivity_df':len(names)-1,
      'between_stratum_sd':np.sqrt(tau2),'residual_sd':np.sqrt(sig2),'lambda':lam,'variance_boundary':lam==0,
      'profile_criterion':f,'search_upper_boundary':False}
 rows=[{'stratum':g,'n_targets':int(ns[k]),'unshrunk_mean':means[k],'shrinkage_weight':alpha[k],
        'random_intercept_blup':alpha[k]*(means[k]-mu),'shrunken_mean':mu+alpha[k]*(means[k]-mu)} for k,g in enumerate(names)]
 return out,rows

def check_matrix(y,groups,profile):
 y=np.asarray(y,float); groups=np.asarray(groups); N=len(y)
 B=(groups[:,None]==groups[None,:]).astype(float); one=np.ones(N)
 def f(z,details=False):
  sig2=np.exp(z[0]);tau2=np.exp(z[1]); V=sig2*np.eye(N)+tau2*B
  L=cho_factor(V,lower=True); vi1=cho_solve(L,one);viy=cho_solve(L,y)
  a=np.dot(one,vi1);mu=np.dot(one,viy)/a;r=y-mu
  obj=.5*(2*np.log(np.diag(L[0])).sum()+np.log(a)+np.dot(r,cho_solve(L,r)))
  return (obj,mu,sig2,tau2,np.sqrt(1/a)) if details else obj
 start=np.log([profile['residual_sd']**2,max(profile['between_stratum_sd']**2,1e-10)])
 sols=[minimize(f,start+np.array([a,b]),method='Nelder-Mead',options={'xatol':1e-10,'fatol':1e-11,'maxiter':4000}) for a,b in [(0,0),(.6,-.5),(-.4,.6)]]
 best=min(sols,key=lambda x:x.fun);assert best.success,best.message
 obj,mu,sig2,tau2,se=f(best.x,True)
 error=max(abs(mu-profile['mean']),abs(np.sqrt(sig2)-profile['residual_sd']),abs(np.sqrt(tau2)-profile['between_stratum_sd']),abs(se-profile['mean_se']))
 tolerance=2e-6 if profile['variance_boundary'] else 2e-7
 assert error<tolerance,(error,profile)
 assert abs(obj-(profile['profile_criterion']+(N-1)/2))<1e-8
 return {'status':'PASS','max_parameter_difference':error,'tolerance':tolerance,'matrix_objective':obj,'matrix_converged':bool(best.success)}

def analytic_tests():
 checks=[]
 # Balanced data: ANOVA REML components have closed forms if tau^2>0.
 for mult in [0,1,3]:
  g=np.repeat(np.arange(6),5);res=np.tile(np.array([-2,-1,0,1,2])*0.08,6)
  y=np.repeat(np.arange(6)*.17*mult,5)+res
  fit,_=fit_profile(y,g); within=sum(np.sum((y[g==i]-y[g==i].mean())**2) for i in range(6))
  msw=within/24;means=np.array([y[g==i].mean() for i in range(6)])
  msb=5*np.sum((means-means.mean())**2)/5
  if msb>msw: s2=msw;t2=(msb-msw)/5
  else: s2=np.sum((y-y.mean())**2)/29;t2=0
  assert abs(fit['mean']-y.mean())<1e-9
  assert abs(fit['residual_sd']**2-s2)<1e-8 and abs(fit['between_stratum_sd']**2-t2)<1e-8
  check_matrix(y,g,fit)
  checks.append({'case':'balanced_'+str(mult),'status':'PASS','boundary':fit['variance_boundary']})
 return checks

def data_frames():
 raw=pd.read_csv(P3/'panel/panel_runs.csv');raw=raw[raw.model=='rf']
 assert not raw.duplicated(['scenario','target','route','seed']).any()
 assert raw.groupby(['scenario','target','route']).seed.apply(lambda x:set(x)=={42,53,67}).all()
 ts=raw.groupby(['scenario','target','route']).skill.median().unstack('route').reset_index()
 sel=json.loads((P3/'panel/PANEL_SELECTION_FROZEN.json').read_text(encoding='utf-8-sig'))['selected']
 strata={x['symbol']:x['stratum'] for x in sel}; ts['stratum']=ts.target.map(strata)
 assert ts.stratum.notna().all()
 ts['ye_minus_se']=ts.temporal_exact-ts.source_exact;ts['ss_minus_se']=ts.source_scaffold-ts.source_exact
 return ts

def run():
 packet=HERE.parents[4]
 reg=json.loads((packet/'outputs/round5_records/PROTOCOL_REGISTRATION.json').read_text())
 assert reg['before_hierarchical_fitting']
 tests=analytic_tests();ts=data_frames();allresults=[];allstrata=[];allinputs=[];matrix=[]
 for scenario in ['revised','single_protein']:
  for contrast in ['ye_minus_se','ss_minus_se']:
   d=ts[ts.scenario==scenario][['target','stratum',contrast]].dropna().copy()
   if scenario=='revised':assert len(d)==42 and d.stratum.nunique()==9
   original=pd.read_csv(P3/'summary'/f'p3b_contrasts_{scenario}__rf.csv')
   v=d.merge(original[['target','stratum',contrast]],on=['target','stratum'],suffixes=('_run','_summary'))
   assert len(v)==len(d) and np.allclose(v[contrast+'_run'],v[contrast+'_summary'],atol=1e-12,rtol=0)
   fit,rows=fit_profile(d[contrast],d.stratum)
   mc=check_matrix(d[contrast],d.stratum,fit);matrix.append(dict(scenario=scenario,contrast=contrast,**mc))
   allresults.append(dict(scenario=scenario,contrast=contrast,**fit))
   allstrata.extend(dict(scenario=scenario,contrast=contrast,**x) for x in rows)
   allinputs.extend({'scenario':scenario,'contrast':contrast,'target':x.target,'stratum':x.stratum,'change':getattr(x,contrast)} for x in d.itertuples())
 result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protocol_registered_utc':reg['registered_utc'],
         'primary_analysis':'original stratified target bootstrap','status':'post_hoc_supplement','model':'change ~ 1 + (1 | stratum)',
         'interval_method':'normal Wald with plug-in REML variance estimates; t_(G-1) sensitivity is approximate, not Kenward-Roger/Satterthwaite',
         'implementation':'NumPy/SciPy profile REML independently checked using full covariance Cholesky REML',
         'no_packages_installed':True,'source_sha256':hashlib.sha256((P3/'panel/panel_runs.csv').read_bytes()).hexdigest(),
         'fits':allresults,'independent_matrix_checks':matrix,'analytic_tests':tests}
 pd.DataFrame(allresults).to_csv(HERE/'model_summary.csv',index=False)
 pd.DataFrame(allstrata).to_csv(HERE/'stratum_shrinkage.csv',index=False)
 pd.DataFrame(allinputs).to_csv(HERE/'analysis_input.csv',index=False)
 (HERE/'HIERARCHICAL_RESULTS.json').write_text(json.dumps(result,indent=2,default=lambda x:x.item())+'\n',encoding='utf-8')
 print(pd.DataFrame(allresults)[['scenario','contrast','n_targets','mean','normal_ci_low','normal_ci_high','between_stratum_sd','t_sensitivity_low','t_sensitivity_high']].to_string(index=False))
 print('Independent matrix checks + analytic cases: PASS')

if __name__=='__main__':run()
