# V9 histogram and display dictionary

Figure 10 uses RF route medians reconstructed within the automated ChEMBL 36 cohort. Every panel uses the same target's release-forward exact-tier RF skill as its reference. The nine eligible targets and plotted scatter coordinates are unchanged.

signed_gap = internal_skill - forward_skill. Negative values indicate lower skill under the internal evaluation. absolute_gap = abs(signed_gap). The upright histograms count signed gaps; the existing panel annotations are medians of absolute gaps. These two displays answer different questions. Table S29 still reports tier-matched comparisons, including scaffold-with-scaffold values for SS and YS.

Figure10_signed_gaps.csv contains 36 target/route rows. Figure10_histogram_counts.csv contains eight shared bins per route. Bins are left-closed and right-open, with the last right boundary included. No density estimate or confidence interval is inferred from these nine-target histograms.

DISPLAY_SOURCE_INDEX.csv uses one-based pages in the V9 PDFs. Historical index pages are archived. Original ledger metadata, author acceptance, upstream-file limitations, and checkpoint scopes remain as documented in DIGITAL_TABLE_DICTIONARY_V8.md. This revision made no new fits or weight reloads.
