# V8 metadata and provenance dictionary

## Eligibility ledger

policy631_execution/policy631.csv records 631 distinct context decisions: 600 common exclusions and 31 strict-subset exclusions. Original ledger bytes are retained.

policy_status describes the decision state when the ledger was frozen. The historical string approved_frozen_not_yet_fitted occurs in 615 rows; it is not the current fitting status. Thirteen rows have approved_frozen_drop_only and three have approved_frozen. The downstream preparation script applies the frozen common and strict exclusion UID sets. application_provenance/prepare_current.py and PREPARATION_COMPLETE.json document application of this exact policy-file hash: 288 prepared tables matched the recorded ordered signatures and literal CSV hashes, with no label/structure replacement or reassigned partition. This is existing preparation evidence, not a new execution of that pipeline.

human_acceptance contains the original Chinese author response “按照你的推荐来” in 13 rows, meaning “follow your recommendation”; 618 rows are blank. This records author acceptance of assistant recommendations for those drop-only decisions. It does not certify independent human verification of publisher source values or structures.

evidence_file/source_file and similar absolute paths are historical provenance pointers on the author's computer. Upstream publisher PDFs and all audit artifacts are not supplied in this compact package. A path or hash does not give access to an omitted file. SOURCE hashes refer to the archived inputs identified in the record; SHA256_MANIFEST.json is the authoritative manifest of files actually supplied here.

## Initial screen

reproducibility/initial_target_screen.csv is a historical target-screen ledger. It is supplied unchanged and should not be used as the current cohort-size table.

## Checkpoint comparison

12 trajectories yielded 24 selected states in the earlier completed analysis. This package supplies their predictions/histories/seals, not trained weights. 43,920 test/validation prediction rows and the recorded 22,482 test-prediction weight-replay count have different scopes. V8 rechecks saved numeric evidence; it does not repeat weight loading or training. The altered eligibility/stopping rules were applied to selected routes in two outcome-known pairs. Original 22-pair results remain primary. Higher monitored validation loss under the constraint in 11/12 fits does not establish a selection error under the original rule.

## Display index and tables

pdf_page contains one-based pages in the current final PDFs; semicolons separate multiple caption/continuation pages. Display titles come from current TeX captions or numbered section headings. local_material_paths resolve to supplied package files. cited_public_locator preserves previously cited public scopes and is not a new online verification. All current reported table excerpts and graph PDFs are supplied. Counts, medians and seed aggregation remain as in the frozen analysis records.
