"""Post hoc fixed-fit document bootstrap; no training or model loading.
Run once with --prepare against frozen upstream predictions; later replay uses
the portable document-level loss sums only. Protocol recorded before calculation.
"""
from pathlib import Path
import sys,json,hashlib,csv,argparse
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
REL=Path('E:/paper/kinase_followup_execution/claude_manuscript_polish_20261002_v1/cowork_workspace/round2_claude_20261004/results/p3/release')
U=R/'evidence/forward_uncertainty'
SUMMARY_DIR=R/'results'
def configure(root=None):
    global R,U,SUMMARY_DIR
    R=Path(root).expanduser().resolve() if root is not None else Path(__file__).resolve().parents[1]
    full=R/'evidence/forward_uncertainty'
    portable=R/'forward_uncertainty'
    if (full/'PROTOCOL_V10.md').is_file():
        U=full;SUMMARY_DIR=R/'results'
    elif (portable/'PROTOCOL_V10.md').is_file():
        U=portable;SUMMARY_DIR=R/'posthoc_descriptive'
    else:
        raise FileNotFoundError(f'No PROTOCOL_V10.md under {full} or {portable}; --root must name the extracted package root.')
    for p in [R/'data',SUMMARY_DIR]:p.mkdir(parents=True,exist_ok=True)
TARGETS='ache alk dpp4 egfr hdac1 kdr met pde4d ptgs2'.split()
ROUTES=['source_exact','source_scaffold','temporal_exact','temporal_scaffold']
DESIGNS=[('release_forward','exact'),('release_forward','scaffold')]+[('internal_'+r,'test') for r in ROUTES]
B=2000; SEED=20261007
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def prepare():
    runs=pd.read_csv(R/'evidence/release_runs.csv',float_precision='round_trip')
    records=[];sources=[];checks=[]
    for t in TARGETS:
        for design,tier in DESIGNS:
            forward=design=='release_forward'
            pf=REL/f'fits/{t}_{design}.predictions.csv.gz'
            mf=REL/(f'prepared/{t}_release_test37_{tier}.csv' if forward else f'prepared/{t}_internal36_{design[9:]}_test.csv')
            pp=pd.read_csv(pf,float_precision='round_trip'); pp=pp[pp.model.eq('rf')]
            if 'test_set' in pp:pp=pp[pp.test_set.eq(tier)]
            meta=pd.read_csv(mf,float_precision='round_trip')
            assert meta.record_uid.is_unique and len(meta)>0
            joined=pp.merge(meta[['record_uid','document_chembl_id']],on='record_uid',how='left',validate='many_to_one')
            assert joined.document_chembl_id.notna().all()
            expected_labels=meta.set_index('record_uid').target
            assert np.max(np.abs(joined.target.to_numpy()-expected_labels.loc[joined.record_uid].to_numpy()))<1e-12
            reference=None;skills=[]
            for seed in [42,53,67]:
                p=joined[joined.seed.eq(seed)].sort_values('record_uid')
                assert p.record_uid.is_unique and len(p)==len(meta)
                alignment=p[['record_uid','document_chembl_id','target']].reset_index(drop=True)
                if reference is None:reference=alignment
                else:assert alignment.equals(reference), (t,design,tier,'unaligned seeds')
                rr=runs[runs.target.eq(t)&runs.design.eq(design)&runs.test_set.eq(tier)&runs.model.eq('rf')&runs.seed.eq(seed)].iloc[0]
                tm=float(rr.training_mean)
                p=p.assign(model_loss=(p.target-p.prediction)**2,baseline_loss=(p.target-tm)**2)
                mm=p.model_loss.mean();bm=p.baseline_loss.mean();sk=1-mm/bm
                assert max(abs(mm-rr.mse_model),abs(bm-rr.mse_mean),abs(sk-rr.skill))<1e-9
                skills.append(float(sk))
                for doc,g in p.groupby('document_chembl_id',sort=True):
                    records.append(dict(target=t,design=design,tier=tier,seed=seed,document=doc,contexts=len(g),model_loss=float(g.model_loss.sum()),baseline_loss=float(g.baseline_loss.sum())))
            checks.append(dict(target=t,design=design,tier=tier,contexts=len(meta),documents=int(reference.document_chembl_id.nunique()),seed_skills=skills,row_alignment=True,metrics_match=True))
            sources.append(dict(target=t,design=design,tier=tier,predictions=str(pf),predictions_sha256=sha(pf),metadata=str(mf),metadata_sha256=sha(mf)))
            print('Validated',t,design,tier,len(meta),flush=True)
    pd.DataFrame(records).to_csv(U/'document_loss_sums.csv',index=False,float_format='%.17g',lineterminator='\n')
    (U/'INPUT_CHECKS.json').write_text(json.dumps(dict(source_files=sources,design_checks=checks,protocol_sha256=sha(U/'PROTOCOL_V10.md')),indent=2),encoding='utf-8')

def calculate(write=True):
    data=pd.read_csv(U/'document_loss_sums.csv',float_precision='round_trip');rng=np.random.default_rng(SEED)
    points={};boot={};sizes={};docs={}
    for t in TARGETS:
        for design,tier in DESIGNS:
            p=data[data.target.eq(t)&data.design.eq(design)&data.tier.eq(tier)]
            names=sorted(p.document.unique());models=[];baselines=[];counts=[]
            for s in [42,53,67]:
                z=p[p.seed.eq(s)].set_index('document').loc[names]
                models.append(z.model_loss.to_numpy());baselines.append(z.baseline_loss.to_numpy());counts.append(z.contexts.to_numpy())
            assert np.array_equal(counts[0],counts[1]) and np.array_equal(counts[0],counts[2])
            ml=np.array(models).T;bl=np.array(baselines).T
            point=float(np.median(1-ml.sum(axis=0)/bl.sum(axis=0)))
            draws=rng.choice(len(names),size=(B,len(names)),replace=True)
            samples=np.empty(B)
            for i,draw in enumerate(draws):
                w=np.bincount(draw,minlength=len(names));samples[i]=np.median(1-(w@ml)/(w@bl))
            assert np.isfinite(samples).all()
            key=(t,design,tier);points[key]=point;boot[key]=samples;sizes[key]=(int(counts[0].sum()),len(names));docs[key]=set(names)
    rows=[]
    for t in TARGETS:
        for tier in ['exact','scaffold']:
            key=(t,'release_forward',tier);lo,hi=np.quantile(boot[key],[.025,.975])
            rows.append(dict(target=t,statistic='forward_skill',route='release_forward',benchmark=tier,point=points[key],lower=float(lo),upper=float(hi),internal_contexts='',internal_documents='',forward_contexts=sizes[key][0],forward_documents=sizes[key][1]))
        for r in ROUTES:
            ik=(t,'internal_'+r,'test')
            for tier in ['exact','scaffold']:
                fk=(t,'release_forward',tier)
                assert not docs[ik]&docs[fk],(t,r,tier,'test documents overlap')
                lo,hi=np.quantile(boot[ik]-boot[fk],[.025,.975])
                rows.append(dict(target=t,statistic='signed_gap',route=r,benchmark=tier,point=points[ik]-points[fk],lower=float(lo),upper=float(hi),internal_contexts=sizes[ik][0],internal_documents=sizes[ik][1],forward_contexts=sizes[fk][0],forward_documents=sizes[fk][1]))
    out=pd.DataFrame(rows)
    sensitivities={}
    for r in ['source_scaffold','temporal_scaffold']:
        vals=[abs(points[t,'internal_'+r,'test']-points[t,'release_forward','scaffold']) for t in TARGETS]
        subset=[abs(points[t,'internal_'+r,'test']-points[t,'release_forward','scaffold']) for t in TARGETS if t!='met']
        sensitivities[r]=dict(primary_targets=9,primary_median=float(np.median(vals)),omit_met_targets=8,omit_met_median=float(np.median(subset)))
    signs={r:dict(positive=sum(points[t,'internal_'+r,'test']-points[t,'release_forward','exact']>0 for t in TARGETS),negative=sum(points[t,'internal_'+r,'test']-points[t,'release_forward','exact']<0 for t in TARGETS),signed_median=float(np.median([points[t,'internal_'+r,'test']-points[t,'release_forward','exact'] for t in TARGETS]))) for r in ROUTES}
    summary=dict(replicates=B,seed=SEED,method='fixed-fit whole-test-document percentile bootstrap; median of three RF seed skills in each replicate',targets=TARGETS,interval_rows=len(out),designs=54,doc_range_exact=[min(sizes[t,'release_forward','exact'][1] for t in TARGETS),max(sizes[t,'release_forward','exact'][1] for t in TARGETS)],context_range_exact=[min(sizes[t,'release_forward','exact'][0] for t in TARGETS),max(sizes[t,'release_forward','exact'][0] for t in TARGETS)],direction=signs,met_sensitivity=sensitivities,protocol_sha256=sha(U/'PROTOCOL_V10.md'),document_sums_sha256=sha(U/'document_loss_sums.csv'),no_new_fits=True)
    if write:
        out.to_csv(R/'data/forward_conditional_intervals.csv',index=False,float_format='%.17g',lineterminator='\n')
        (SUMMARY_DIR/'FORWARD_UNCERTAINTY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    return out,summary
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,help='Root of the extracted manuscript review package or SI data ZIP')
    parser.add_argument('--prepare',action='store_true',help='Full local upstream row preparation; ordinary portable replay does not need this')
    args=parser.parse_args();configure(args.root)
    assert (U/'PROTOCOL_V10.md').exists()
    if args.prepare:prepare()
    o,s=calculate();print(json.dumps(s,indent=2))
