# Submission distribution addendum

This addendum supersedes the V12 dictionary only for distribution metadata and TOC artwork. All scientific result tables and prediction files retain their prior values and stated uncertainty scope.

| Current material | Scope |
| --- | --- |
| DISPLAY_SOURCE_INDEX.csv | 81 displays; current physical PDF page numbers and file hashes |
| source_provenance/ | Recovered API status and BRAF retrieval manifest; Harris seven-row numeric locator, without publisher PDF |
| policy631_execution/policy631.csv | 631 contexts; only private wording in human_acceptance is replaced, not decisions, source identifiers or values |
| manuscript/figures/TOC_Graphic.pdf / svg / png / tif | Current conceptual TOC; no numeric results |
| historical_artwork/toc_v12/ | Superseded TOC only; not current submission artwork |
| DISTRIBUTION_CHANGES.json | Explicit transformations and original/new hashes |
| SHA256_MANIFEST.json | Current distribution members; excludes itself and SHA256SUMS.txt |
| archived_manifests/ | Original V12 seals; do not use as the current distribution manifest |

The earlier V12 numerical dictionary continues to describe the scientific files. Absolute author-local paths document historical provenance and do not establish public availability. A public deposit or full upstream retraining is not implied by this package.
