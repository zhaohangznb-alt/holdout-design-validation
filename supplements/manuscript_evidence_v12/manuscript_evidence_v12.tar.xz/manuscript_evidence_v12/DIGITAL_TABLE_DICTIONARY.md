# Digital table dictionary

CSV files are UTF-8 with BOM. Cell strings retain the original displayed precision, TeX marks and signed values. `source_block` identifies a physical table block; `block_identity` retains its full panel/view/cohort/model subtitle. Neither column is an experimental observation. Refer to the complete original TeX for notes, headers and historical status.

| File | Rows | Data columns after the two provenance columns |
| --- | --- | --- |
| Table_S8.csv | 24 | original_cell_1: release interval; 2: target; 3: records; 4: eligible molecules; 5: source documents; 6: historical role. `\ensuremath{\to}` is the original arrow; this is the archived replay, not phase-3 C36→37. |
| Table_S13.csv | 16 | original_cell_1: cohort; 2: route; 3: v5/v6 historical version; 4: TRAIN/TEST context counts; 5: train mean; 6: RF MSE; 7: mean-baseline MSE; 8: skill. B/SP retain historical cohort aliases. |
| Table_S19.csv | 408 | target, route, model_mse, mean_mse, model_mae, mean_mae, model_rmse, mean_rmse. MSE uses squared pIC50 units; MAE/RMSE use pIC50. RF summaries retain metric-wise seed medians. |
| Table_S20.csv | 408 | target, route, test_contexts_display, test_documents, skill, lower, upper. Parentheses/asterisks in displayed counts are retained. Intervals condition on fitted models and frozen test cohorts. |

SE/SS are source exact/scaffold; YE/YS are year exact/scaffold. Each complete block has its own eligible population. All 856 rows and 6,392 data cells have been checked against the original TeX; S8 additionally has every four-interval×six-target key and all three DESCRIPTIVE roles. Do not convert these rounded strings into new full-precision statistics.

All other reported tables are retained as exact TeX cells under tables/ and linked in DISPLAY_SOURCE_INDEX.csv. These are preserved reported cells, not claims that absent per-record evidence was independently re-audited.


## V8 eligibility and checkpoint metadata

Read DIGITAL_TABLE_DICTIONARY_V8.md for policy_status at freeze, the 13 author responses accepting assistant recommendations, local source pointers and omitted upstream files, recorded application of the policy, checkpoint evidence scopes, and current display-index page definitions. Original ledger bytes are retained.


## V9 display revision

Read DIGITAL_TABLE_DICTIONARY_V9.md for the restored signed-gap histograms. Historical scientific metadata remains unchanged.
