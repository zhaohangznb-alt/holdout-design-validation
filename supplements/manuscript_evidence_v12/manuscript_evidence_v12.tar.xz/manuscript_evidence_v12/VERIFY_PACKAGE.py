from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
bad=[]
for rel,expected in manifest.items():
    p=root/rel
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:bad.append(rel)
print(f'{len(manifest)} files checked; {len(bad)} failures')
if bad:print('\n'.join(bad));raise SystemExit(1)
