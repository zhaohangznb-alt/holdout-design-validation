"""Publication layouts from frozen V4 display data; no model fitting or resampling."""
from pathlib import Path
import sys,json
sys.path.insert(0,'E:/paper/kinase_followup_execution/algorithm_validation_extension_20261003_v1/plot_dependencies')
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.transforms import Affine2D
from matplotlib.colors import LinearSegmentedColormap,Normalize
from scipy.stats import gaussian_kde
from matplotlib.text import Text
from collections import Counter
R=Path(__file__).resolve().parents[1]
BLUE='#0072B2';RED='#D55E00';GREEN='#009E73';PURPLE='#AA4499';GOLD='#E6AB02';INK='#202832';GRAY='#8195A5';PALE='#F2F5F8'
COLORS=[BLUE,GREEN,RED,PURPLE];ROUTES=['source_exact','source_scaffold','temporal_exact','temporal_scaffold'];SHORT=['SE','SS','YE','YS']
TARGETS=['alk','braf','egfr','erbb2','kdr','met','ache','dpp4','ptgs2','hdac1','pde4d']
STRATA=['Kinase','Protease','Other enzyme','Membrane receptor','Ion channel','Transcription factor','Epigenetic regulator','Transporter','Other']
CLASS_COL=dict(zip(STRATA,[BLUE,RED,GREEN,PURPLE,'#00A5CF','#E6AB02','#17857C','#6250A1','#D14F75']))
plt.rcParams.update({'font.family':'Times New Roman','font.size':8.5,'axes.titlesize':9,'axes.labelsize':8.5,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':8,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':GRAY,'axes.linewidth':.65,'figure.facecolor':'white','savefig.facecolor':'white','mathtext.fontset':'stix'})
def rd(n):return pd.read_csv(R/'data'/n,float_precision='round_trip')
PS=rd('panel42_rf_seed_scores.csv');PA=rd('panel42_with_counts.csv');FW=rd('forward_pairs.csv');MP=rd('model_pairs.csv');CI=rd('conditional_intervals.csv');F2=rd('f2.csv');LP=rd('label_pools.csv');PR=rd('alk_prediction_diagnostics.csv');AR=rd('controlled_arm_metrics.csv');FM=rd('filter_memberships.csv')
LOG={}; QA={}
def clean(a,zero=None,grid=None):
 a.tick_params(length=2.5,width=.65);a.set_axisbelow(True)
 if grid:a.grid(axis=grid,color='#E0E6EB',lw=.45)
 if zero=='x':a.axvline(0,c=GRAY,lw=.8,ls='--',zorder=1)
 if zero=='y':a.axhline(0,c=GRAY,lw=.8,ls='--',zorder=1)
def leg(f,entries,y=.995,ncol=None):
 f.legend(handles=[Line2D([],[],color=c,marker=m,lw=1.2,ms=4,mfc='white' if m=='D' else c,label=l) for l,c,m in entries],loc='upper center',bbox_to_anchor=(.5,y),ncol=ncol or len(entries),frameon=False,handletextpad=.4,columnspacing=1.2)
def save(f,name,record):
 f.canvas.draw(); ren=f.canvas.get_renderer();w,h=f.canvas.get_width_height();outside=[]
 for t in f.findobj(Text):
  if t.get_visible() and t.get_text():
   b=t.get_window_extent(ren)
   if b.x0< -2 or b.y0< -2 or b.x1>w+2 or b.y1>h+2:outside.append(t.get_text())
 QA[name]={'outside_original_canvas':outside,'font':'Times New Roman'}
 for e in ['pdf','svg','png']:f.savefig(R/'figures'/f'{name}.{e}',dpi=210,bbox_inches='tight',pad_inches=.08)
 (R/'manuscript/figures'/f'{name}.pdf').write_bytes((R/'figures'/f'{name}.pdf').read_bytes())
 LOG[name]=record;plt.close(f);print('Drawn',name,flush=True)
def panel42():
 f,a=plt.subplots(figsize=(6.78,3.7));f.subplots_adjust(left=.08,right=.995,bottom=.30,top=.85)
 ys=[];summ=[]
 for i,cl in enumerate(STRATA):
  if i%2==0:a.axvspan(i-.5,i+.5,color=PALE,zorder=0)
  p=PA[PA.stratum==cl].sort_values('target')
  for j,(r,c) in enumerate(zip(ROUTES,COLORS)):
   x=i+(j-1.5)*.19;v=p[r].to_numpy();q=np.quantile(v,[.25,.5,.75]);a.plot([x,x],q[[0,2]],c=INK,lw=.9,zorder=3)
   for k,t in enumerate(p.target):
    z=PS[(PS.target==t)&(PS.route==r)].sort_values('seed');dx=(k-(len(p)-1)/2)*.017
    a.scatter(x+dx+np.array([-.006,0,.006]),z.skill,s=7,c=c,lw=0,alpha=.85,zorder=2);ys.extend(z.skill.to_list())
   a.scatter(x,q[1],s=18,marker='D',fc='white',ec=INK,lw=.85,zorder=4);summ.append(q.tolist())
   a.text(x,-.675,SHORT[j],rotation=90,ha='center',va='top',fontsize=6.4,color=c)
  if i<8:a.axvline(i+.5,c='#DDE3EA',lw=.45,zorder=0)
 labels=['Kinase','Protease','Other\nenzyme','Membrane\nreceptor','Ion\nchannel','Transcription\nfactor','Epigenetic\nregulator','Transporter','Other']
 a.set(xlim=(-.5,8.5),ylim=(-.66,.72),xticks=range(9),xticklabels=[s+'\n(n='+str(sum(PA.stratum==cl))+')' for s,cl in zip(labels,STRATA)],yticks=[-.6,-.3,0,.3,.6],ylabel='RF skill');a.tick_params(axis='x',pad=27,length=0);a.spines['bottom'].set_visible(False);clean(a,'y','y')
 leg(f,[(s,c,'o') for s,c in zip(SHORT,COLORS)]+[('Class median / IQR',INK,'D')],.99)
 save(f,'Figure_8',{'candidate':13,'seed_skills':ys,'points':504,'class_median_IQR':summ,'targets':42,'classes':9})
def quadrant():
 f,a=plt.subplots(figsize=(5.9,5.35));f.subplots_adjust(left=.13,right=.86,bottom=.12,top=.90);x=MP.ye_minus_se_rf.to_numpy();y=MP.ye_minus_se_dmpnn.to_numpy();lim=(-.92,.55)
 grid=rd('model_response_kde_grid.csv');u=np.sort(grid.x.unique());v=np.sort(grid.y.unique());zz=grid.relative_density.to_numpy().reshape(len(v),len(u));xx,yy=np.meshgrid(u,v)
 cm=LinearSegmentedColormap.from_list('density',[PURPLE,BLUE,GREEN,'#A8CE60','#F3CD43']);levels=np.linspace(.15,1,10)
 for (left,right),(bot,top),c in [((lim[0],0),(lim[0],0),BLUE),((lim[0],0),(0,lim[1]),PURPLE),((0,lim[1]),(0,lim[1]),GREEN),((0,lim[1]),(lim[0],0),RED)]:a.add_patch(Rectangle((left,bot),right-left,top-bot,fc=c,alpha=.055,zorder=0))
 cs=a.contourf(xx,yy,zz,levels=levels,cmap=cm,alpha=.86,zorder=1);a.contour(xx,yy,zz,levels=levels[1:-1],colors=INK,alpha=.2,linewidths=.3,zorder=2)
 for sc,mark,label in [('revised','o','Broad'),('single_protein','^','Operational')]:
  z=MP[MP.scenario==sc];a.scatter(z.ye_minus_se_rf,z.ye_minus_se_dmpnn,s=35,marker=mark,fc='white',ec=RED,lw=1.1,label=label,zorder=5)
 a.axhline(0,c=INK,lw=.9,zorder=6);a.axvline(0,c=INK,lw=.9,zorder=6);a.plot([-.72,.40],[-.72,.40],c=GRAY,lw=.7,ls='--',zorder=3)
 counts=[int(((x<0)&(y<0)).sum()),int(((x<0)&(y>=0)).sum()),int(((x>=0)&(y>=0)).sum()),int(((x>=0)&(y<0)).sum())]
 for px,py,ha,va,s,n in [(.025,.025,'left','bottom','Both lower',counts[0]),(.025,.975,'left','top','RF lower only',counts[1]),(.975,.975,'right','top','Both higher',counts[2]),(.975,.025,'right','bottom','D-MPNN lower only',counts[3])]:a.text(px,py,f'{s}\n{n}/22 ({n/22:.1%})',transform=a.transAxes,ha=ha,va=va,fontsize=8,zorder=7)
 for r in MP[(MP.ye_minus_se_rf<0)&(MP.ye_minus_se_dmpnn>0)].itertuples():
  label=r.target.upper()+(' B' if r.scenario=='revised' else ' O');offset={'MET B':(5,9),'MET O':(-13,0),'PDE4D B':(-5,10),'ERBB2 O':(6,5)}[label];a.annotate(label,(r.ye_minus_se_rf,r.ye_minus_se_dmpnn),xytext=offset,textcoords='offset points',ha='right' if offset[0]<0 else 'left',fontsize=7,arrowprops={'arrowstyle':'-','lw':.4,'color':GRAY},zorder=9)
 a.set(xlim=lim,ylim=lim,aspect='equal',xticks=[-.8,-.4,0,.4],yticks=[-.8,-.4,0,.4],xlabel='RF change in skill (YE - SE)',ylabel='D-MPNN change in skill (YE - SE)');clean(a);a.legend(loc='upper center',bbox_to_anchor=(.5,1.10),ncol=2,frameon=False)
 cax=f.add_axes([.91,.31,.018,.37]);cb=f.colorbar(cs,cax=cax,ticks=[.15,.5,1]);cb.set_label('Relative KDE density',fontsize=8);cb.outline.set_visible(False)
 save(f,'Figure9',{'candidate':19,'observed_pairs':np.c_[x,y].tolist(),'counts':counts,'density_grid_from_archive':True,'levels':levels.tolist()})
def angled(a,values,c):
 edges=np.linspace(-.75,1.25,9);counts,_=np.histogram(values,edges);assert sum(counts)==9
 tr=Affine2D().scale(.34,.15).rotate_deg(-45).translate(.80,.82)+a.transAxes
 norm=lambda x:(x-edges[0])/(edges[-1]-edges[0])-.5
 for left,right,n in zip(edges[:-1],edges[1:],counts):a.add_patch(Rectangle((norm(left),0),norm(right)-norm(left),n/max(counts),transform=tr,fc=c,ec='white',lw=.3,alpha=.75,clip_on=False,zorder=5))
 a.plot([-.5,.5],[0,0],c=INK,lw=.7,transform=tr,clip_on=False);a.plot([-.5,-.5],[0,1.03],c=INK,lw=.7,transform=tr,clip_on=False)
 a.text(-.60,.98,str(int(max(counts))),transform=tr,rotation=45,ha='center',va='center',fontsize=6,zorder=7)
 a.text(-.60,0,'0',transform=tr,rotation=45,ha='center',va='center',fontsize=6,zorder=7)
 for vv in [-.75,.25,1.25]:a.text(norm(vv),-.17,f'{vv:.2f}',transform=tr,rotation=-45,ha='center',va='center',fontsize=6,zorder=7)
 med=np.median(values);a.plot([norm(med),norm(med)],[0,1.08],c=GOLD,lw=1.2,transform=tr,zorder=7,clip_on=False);a.text(norm(med)+.07,1.10,f'{med:+.3f}',transform=tr,rotation=45,fontsize=6.7,color='#A47700',fontweight='bold',clip_on=False)
 return counts.tolist()
def forward():
 f,aa=plt.subplots(2,2,figsize=(6.78,5.85),sharex=True,sharey=True);f.subplots_adjust(left=.10,right=.95,bottom=.09,top=.94,hspace=.33,wspace=.28);rec=[]
 for j,(a,r,c) in enumerate(zip(aa.flat,ROUTES,COLORS)):
  z=FW[(FW.model=='rf')&(FW.route==r)];assert len(z)==9;a.plot([-.85,1.1],[-.85,1.1],c=GRAY,ls='--',lw=.8);clean(a);a.axhline(0,c=GRAY,lw=.7,ls='--');a.axvline(0,c=GRAY,lw=.7,ls='--');a.scatter(z.internal_skill,z.forward_skill,c=c,s=27,ec='white',lw=.5,zorder=4)
  for q in z.itertuples():
   if q.target in ['alk','met','egfr','dpp4']:
    xy=(-5,4) if q.target=='met' else (4,-9 if q.target=='egfr' else 4);a.annotate(q.target.upper(),(q.internal_skill,q.forward_skill),xytext=xy,textcoords='offset points',ha='right' if q.target=='met' else 'left',fontsize=6.8)
  bins=angled(a,z.signed_gap.to_numpy(),c);rec.append({'route':r,'points':z[['internal_skill','forward_skill']].values.tolist(),'bins':bins,'median_gap':float(z.signed_gap.median())})
  a.set(xlim=(-.85,1.1),ylim=(-.85,1.1),aspect='equal',xticks=[-.8,-.4,0,.4,.8],yticks=[-.8,-.4,0,.4,.8]);a.set_title(chr(97+j)+'  '+SHORT[j],loc='left',color=c,fontweight='bold',pad=9)
  if j%2==0:a.set_ylabel('Release-forward RF skill')
  if j>=2:a.set_xlabel('Internal RF skill')
 save(f,'Figure10',{'candidate':9,'routes':rec,'eligible_targets_per_route':9,'histogram_bins':8,'inset_rotation_degrees':-45})
def conditional():
 models=['rf','ridge','tanimoto1nn'];names=['RF','Ridge','1-NN'];f,aa=plt.subplots(3,4,figsize=(6.78,7.2),sharey=True);f.subplots_adjust(left=.10,right=.99,bottom=.085,top=.975,wspace=.16,hspace=.45);rec=[]
 for i,(m,n) in enumerate(zip(models,names)):
  vals=CI[CI.model==m];lo=min(vals.ci_low.min(),0);hi=max(vals.ci_high.max(),0);span=hi-lo
  for j,(r,c) in enumerate(zip(ROUTES,COLORS)):
   a=aa[i,j];z=CI[(CI.model==m)&(CI.route==r)].set_index('target').loc[TARGETS]
   for k,q in enumerate(z.itertuples()):
    a.plot([q.ci_low,q.ci_high],[k,k],c=c,lw=1);a.scatter(q.skill,k,s=17,fc='white' if q.ci_low*q.ci_high>0 else c,ec=c,lw=.8,zorder=3);rec.append([m,r,q.Index,float(q.skill),float(q.ci_low),float(q.ci_high)])
   a.set(xlim=(lo-.06*span,hi+.06*span),ylim=(10.6,-.7),yticks=range(11),yticklabels=[t.upper() for t in TARGETS]);clean(a,'x','x');a.set_title(n+' / '+SHORT[j],loc='left',fontsize=8,color=c,fontweight='bold')
   if i==2:a.set_xlabel('Skill')
 save(f,'FigureS17',{'candidate':10,'intervals':rec,'count':132,'model_scales_separate':True})
def raincloud():
 f=plt.figure(figsize=(6.78,6.4));gs=f.add_gridspec(2,2,left=.09,right=.98,bottom=.075,top=.94,height_ratios=[2.2,1],hspace=.48,wspace=.32);a=f.add_subplot(gs[0,:]);rec=[]
 for i,t in enumerate(TARGETS):
  for j,(r,c) in enumerate([('source_exact',BLUE),('temporal_exact',RED)]):
   v=F2[(F2.target==t)&(F2.route==r)].skill.to_numpy();pos=i+(j-.5)*.43;grid=np.linspace(v.min()-.025,v.max()+.025,150);d=gaussian_kde(v)(grid)
   a.fill_betweenx(grid,pos,pos+.18*d/d.max(),fc=c,alpha=.28,lw=.6,ec=c)
   jitter=np.random.default_rng(2026+i+j*11).uniform(.025,.12,len(v));a.scatter(pos-jitter,v,c=c,s=2.3,alpha=.42,lw=0,rasterized=True)
   q=np.quantile(v,[.25,.5,.75]);a.plot([pos,pos],q[[0,2]],c=c,lw=2,zorder=4);a.scatter(pos,q[1],s=210,fc='white',ec=c,lw=1,zorder=6);a.text(pos,q[1],f'{q[1]:.2f}',ha='center',va='center',fontsize=5.5,color=c,zorder=7)
   rec.append({'target':t,'route':r,'skills':v.tolist(),'summary':q.tolist()})
 a.set(xlim=(-.45,10.5),ylim=(-1.4,.75),xticks=range(11),xticklabels=[t.upper() for t in TARGETS],ylabel='RF skill');a.tick_params(axis='x',labelsize=6.8);a.set_title('a  Individual retraining outcomes',loc='left',fontweight='bold');clean(a,'y','y');leg(f,[('Source / exact',BLUE,'o'),('Year / exact',RED,'o')],1)
 pairs=F2.pivot(index=['target','replicate'],columns='route',values='skill');pairs['difference']=pairs.temporal_exact-pairs.source_exact;panels=[]
 for j,ts in enumerate([TARGETS[:6],TARGETS[6:]]):
  b=f.add_subplot(gs[1,j]);z=pairs.reset_index();v=z[z.target.isin(ts)].groupby('replicate').difference.median().to_numpy();grid=np.linspace(v.min()-.015,v.max()+.015,150);b.fill_between(grid,gaussian_kde(v)(grid),color=BLUE if j==0 else GREEN,alpha=.23);b.plot(grid,gaussian_kde(v)(grid),c=BLUE if j==0 else GREEN,lw=1.4);b.plot(v,np.zeros_like(v),'|',c=INK,ms=4,alpha=.4);qs=np.quantile(v,[.025,.5,.975]);b.axvline(qs[1],c=INK,lw=.9);b.axvspan(qs[0],qs[2],color=GRAY,alpha=.08);b.set_xlabel('Panel median YE - SE skill');b.set_ylabel('Density');b.set_title(chr(98+j)+'  '+('Six kinases' if j==0 else 'Five non-kinases'),loc='left',fontweight='bold');clean(b,grid='y');panels.append({'panel':j,'replicate_medians':v.tolist(),'percentiles':qs.tolist()})
 save(f,'FigureS18',{'candidate':1,'archived_fits':4400,'groups':rec,'panel_medians':panels,'seeds_cycle_by_replicate':True})
def label_ridges():
 f=plt.figure(figsize=(6.78,6.9));gs=f.add_gridspec(1,2,left=.18,right=.98,bottom=.08,top=.96,width_ratios=[1,1.05],wspace=.1);a=f.add_subplot(gs[0]);b=f.add_subplot(gs[1],sharey=a);g=np.linspace(2.7,12.1,350);rec=[]
 for i,t in enumerate(TARGETS):
  c=[BLUE,RED,GREEN,PURPLE,GOLD,'#2D87B3','#B95228','#278465','#7B4493','#087E9D','#CC5473'][i]
  for j,arm in enumerate(['source_full','year_full']):
   row=2*i+j;z=LP[(LP.target==t)&(LP.arm==arm)].sort_values(['label','record_uid']);v=z.label.to_numpy();den=gaussian_kde(v)(g);height=.72*den/den.max();a.fill_between(g,row,row-height,fc=c,alpha=.15 if j==0 else .28);a.plot(g,row-height,c=c,lw=.9,ls='--' if j==0 else '-');q=np.quantile(v,[.25,.5,.75]);bar=b.barh(row,q[1],height=.62,fc='white',ec=c,lw=.8);bar[0].set_linestyle('--' if j==0 else '-');b.errorbar(q[1],row,xerr=[[q[1]-q[0]],[q[2]-q[1]]],fmt='none',ecolor=INK,lw=.8,capsize=2)
   idx=np.round(np.linspace(.05,.95,10)*(len(z)-1)).astype(int);p=z.iloc[idx];b.scatter(p.label,row+np.array([-.21,.13,-.08,.23,-.18,.07,-.25,.18,-.12,.25]),s=8,marker='D',fc='white',ec=c,lw=.7);rec.append({'target':t,'arm':arm,'n':len(v),'quartiles':q.tolist(),'points':p[['record_uid','label']].to_dict('records')})
  for ax in [a,b]:ax.axhspan(2*i-.35,2*i+1.65,color=PALE if i%2==0 else 'white',zorder=0)
 a.set(xlim=(2.7,12.1),ylim=(21.7,-1),yticks=range(22),yticklabels=[t.upper()+' / '+s for t in TARGETS for s in ['S','Y']],xticks=[3,5,7,9,11],xlabel='Training-label pChEMBL');a.tick_params(axis='y',length=0,labelsize=7);a.spines['left'].set_visible(False);b.set(xlim=(0,12.5),xticks=[0,3,6,9,12],xlabel='Training-label pChEMBL');b.tick_params(axis='y',labelleft=False,length=0);b.spines['left'].set_visible(False);clean(b,grid='x');a.set_title('a  Label distributions',loc='left',fontweight='bold');b.set_title('b  Medians and contexts',loc='left',fontweight='bold')
 save(f,'FigureS22',{'candidate':17,'archived_contexts':len(LP),'pool_summaries':rec,'selected_contexts':220})
def predictions():
 f,aa=plt.subplots(2,4,figsize=(6.78,4.4),sharex=True,sharey=True);f.subplots_adjust(left=.08,right=.91,bottom=.10,top=.93,wspace=.14,hspace=.30);records=[];norm=Normalize(0,5.5);cm=LinearSegmentedColormap.from_list('error',['#DCEBF1',BLUE,PURPLE,RED])
 for i,r in enumerate(['source_exact','temporal_exact']):
  for j,m in enumerate(['RF','Ridge','1-NN','D-MPNN']):
   a=aa[i,j];z=PR[(PR.route==r)&(PR.model==m)];q=a.scatter(z.observed,z.predicted,c=np.abs(z.residual),cmap=cm,norm=norm,s=3.5,lw=0,rasterized=True);a.plot([3,12],[3,12],c=INK,lw=.6);a.plot([3,12],[4,13],c=GRAY,lw=.45,ls='--');a.plot([3,12],[2,11],c=GRAY,lw=.45,ls='--');a.set(xlim=(3,12),ylim=(3,12),xticks=[3,6,9,12],yticks=[3,6,9,12]);clean(a);a.set_title(m+' / '+('SE' if i==0 else 'YE'),fontsize=8,fontweight='bold');err=z.predicted-z.observed;a.text(.03,.96,f'n={len(z)}\nRMSE={np.sqrt(np.mean(err**2)):.2f}\nMAE={np.mean(abs(err)):.2f}',transform=a.transAxes,va='top',fontsize=5.7)
   if i==1:a.set_xlabel('Observed')
   if j==0:a.set_ylabel('Predicted pChEMBL')
   records.append({'model':m,'route':r,'observed_predicted':z[['observed','predicted']].values.tolist(),'RMSE':float(np.sqrt(np.mean(err**2))),'MAE':float(np.mean(abs(err)))})
 cax=f.add_axes([.95,.17,.015,.64]);cb=f.colorbar(q,cax=cax);cb.set_label('Absolute error (pChEMBL)',fontsize=8)
 save(f,'FigureS23',{'candidate':4,'panels':records,'prediction_context_appearances':3712})
def common_tests():
 f,aa=plt.subplots(2,3,figsize=(6.78,5.55));f.subplots_adjust(left=.12,right=.99,bottom=.11,top=.90,wspace=.32,hspace=.46);rec=[]
 for j,(m,n) in enumerate([('rf','RF'),('ridge','Ridge'),('tanimoto1nn','1-NN')]):
  z=AR[(AR.model==m)&AR.arm.isin(['source_matched','year_matched'])];p=z.pivot(index=['target','draw_seed'],columns='arm',values='mse').reset_index()
  for i,ts in enumerate([TARGETS[:6],TARGETS[6:]]):
   a=aa[i,j]
   for k,t in enumerate(ts):
    v=p[p.target==t];s=v.source_matched;y=v.year_matched;a.plot([s.median(),y.median()],[k,k],c=GRAY,lw=1.1);a.plot([s.min(),s.max()],[k,k],c=BLUE,lw=2);a.plot([y.min(),y.max()],[k,k],c=RED,lw=2);a.scatter(s.median(),k,s=20,c=BLUE,ec='white',lw=.4,zorder=3);a.scatter(y.median(),k,s=20,c=RED,ec='white',lw=.4,zorder=4)
    rec.append({'model':m,'target':t,'pairs':v[['source_matched','year_matched']].values.tolist(),'source_summary':[s.min(),s.median(),s.max()],'year_summary':[y.min(),y.median(),y.max()]})
   a.set(ylim=(len(ts)-.4,-.6),yticks=range(len(ts)),yticklabels=[t.upper() for t in ts],xlabel='Common-test MSE (pIC50 squared)');clean(a,grid='x');a.set_title(n+' / '+('kinases' if i==0 else 'non-kinases'),loc='left',fontsize=8,fontweight='bold')
 leg(f,[('Size-matched source',BLUE,'o'),('Year pool',RED,'o')],1)
 save(f,'FigureS24',{'candidate':8,'groups':rec,'true_draw_pairs':165})
def upset():
 sets=[]
 for r in ['source_exact','temporal_exact']:
  for key in ['fragment_match','fingerprint_match']:
   z=FM[(FM.route==r)&FM[key]];sets.append(set(zip(z.target,z.record_uid)))
 union=set().union(*sets);ct=Counter(tuple(key in s for s in sets) for key in union);patterns=sorted(ct,key=lambda p:(sum(p)>1,(-ct[p] if sum(p)>1 else next(j for j,v in enumerate(p) if v))));vals=[ct[p] for p in patterns]
 f=plt.figure(figsize=(6.78,4.25));gs=f.add_gridspec(2,2,left=.045,right=.99,bottom=.10,top=.94,width_ratios=[1.5,4.5],height_ratios=[3,1.65],wspace=.48,hspace=.05);top=f.add_subplot(gs[0,1]);mat=f.add_subplot(gs[1,1],sharex=top);bar=f.add_subplot(gs[1,0],sharey=mat)
 for i,(p,v) in enumerate(zip(patterns,vals)):
  c=COLORS[next(j for j,b in enumerate(p) if b)] if sum(p)==1 else INK;top.bar(i,v,width=.62,color=c);top.text(i,v+.7,str(v),ha='center',fontsize=8);mat.scatter([i]*4,range(4),c='#D4DEE5',s=24);on=np.where(p)[0];mat.plot([i]*len(on),on,c=c,lw=1.3);mat.scatter([i]*len(on),on,c=c,s=31,zorder=3)
 top.set(ylim=(0,56),xlim=(-.6,6.6),ylabel='Exclusive intersection size');top.tick_params(axis='x',bottom=False,labelbottom=False);top.spines['bottom'].set_visible(False);clean(top,grid='y');mat.set(ylim=(3.6,-.6),xticks=[],yticks=[]);mat.spines[:].set_visible(False)
 bar.barh(range(4),[len(s) for s in sets],color=COLORS,height=.6);bar.set(yticks=range(4),yticklabels=['Source / fragment','Source / fingerprint','Year / fragment','Year / fingerprint'],xlim=(70,0),xlabel='Set size');bar.yaxis.tick_right();bar.tick_params(axis='y',labelsize=7,length=0);bar.spines[:].set_visible(False)
 for j,s in enumerate(sets):bar.text(len(s)+1.5,j,str(len(s)),ha='right',va='center',fontsize=7)
 mat.tick_params(axis='y',labelleft=False,labelright=False,left=False,right=False)
 save(f,'FigureS25',{'candidate':22,'sets':[len(s) for s in sets],'unique_target_UID_union':len(union),'patterns':[list(p) for p in patterns],'intersection_counts':vals,'route_positive_contexts':int(FM.fragment_match.sum()+FM.fingerprint_match.sum()-sum(FM.fragment_match&FM.fingerprint_match))})
def lollipops():
 order=PA.sort_values('ye_minus_se',ascending=False).reset_index(drop=True);f,aa=plt.subplots(1,2,figsize=(6.78,8.0),sharey=True);f.subplots_adjust(left=.08,right=.985,bottom=.07,top=.92,wspace=.28);rec=[]
 for j,key in enumerate(['ye_minus_se','ss_minus_se']):
  a=aa[j];lo=min(order[key].min(),0)-.65;hi=max(order[key].max(),0)+.65
  for i,q in enumerate(order.itertuples()):
   v=getattr(q,key);c=CLASS_COL[q.stratum];a.plot([0,v],[i,i],c=c,lw=1);a.scatter(v,i,c=c,s=22,zorder=3);name=q.target_chembl_id.replace('CHEMBL','');a.text(-.04 if v>=0 else .04,i,name,ha='right' if v>=0 else 'left',va='center',fontsize=6.5,color=c);rec.append([q.target,key,v])
  a.set(xlim=(lo,hi),ylim=(41.7,-.8),yticks=[],xlabel='RF change in skill');clean(a,'x','x');a.set_title('a  YE - SE' if j==0 else 'b  SS - SE',loc='left',fontweight='bold')
 leg(f,[(s,CLASS_COL[s],'o') for s in STRATA[:5]],1,5);leg(f,[(s,CLASS_COL[s],'o') for s in STRATA[5:]],.974,4)
 save(f,'FigureS26',{'candidate':14,'target_contrasts':rec,'CHEMBL_suffix_labels':42,'effects':84})
if __name__=='__main__':
 funcs=[panel42,quadrant,forward,conditional,raincloud,label_ridges,predictions,common_tests,upset,lollipops]
 if '--only' in sys.argv:
  wanted=sys.argv[sys.argv.index('--only')+1];funcs=[fun for fun in funcs if fun.__name__==wanted];assert len(funcs)==1
  LOG=json.loads((R/'reports/PLOT_RECORDS.json').read_text());QA=json.loads((R/'reports/TEXT_QA.json').read_text())
 for fun in funcs:fun()
 (R/'reports/PLOT_RECORDS.json').write_text(json.dumps(LOG,indent=2),encoding='utf-8');(R/'reports/TEXT_QA.json').write_text(json.dumps(QA,indent=2),encoding='utf-8')
