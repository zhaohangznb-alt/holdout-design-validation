from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,'E:/paper/kinase_followup_execution/algorithm_validation_extension_20261003_v1/plot_dependencies')
import numpy as np,pandas as pd
R=Path(__file__).resolve().parents[1]
L=json.loads((R/'reports/PLOT_RECORDS.json').read_text())
def rd(n):return pd.read_csv(R/'data'/n,float_precision='round_trip')
checked=0
def equal(a,b):
 global checked
 a=np.asarray(a,float);b=np.asarray(b,float);assert a.shape==b.shape,(a.shape,b.shape);assert np.array_equal(a,b),np.max(abs(a-b));checked+=a.size
PS=rd('panel42_rf_seed_scores.csv');PA=rd('panel42_with_counts.csv');MP=rd('model_pairs.csv');FW=rd('forward_pairs.csv');CI=rd('conditional_intervals.csv');F2=rd('f2.csv');LP=rd('label_pools.csv');PR=rd('alk_prediction_diagnostics.csv');AR=rd('controlled_arm_metrics.csv');FM=rd('filter_memberships.csv')
strata=['Kinase','Protease','Other enzyme','Membrane receptor','Ion channel','Transcription factor','Epigenetic regulator','Transporter','Other'];routes=['source_exact','source_scaffold','temporal_exact','temporal_scaffold']
skills=[];summ=[]
for cl in strata:
 p=PA[PA.stratum==cl].sort_values('target')
 for rt in routes:
  summ.append(np.quantile(p[rt],[.25,.5,.75]).tolist())
  for t in p.target:skills.extend(PS[(PS.target==t)&(PS.route==rt)].sort_values('seed').skill.tolist())
equal(skills,L['Figure_8']['seed_skills']);equal(summ,L['Figure_8']['class_median_IQR']);assert len(skills)==504
equal(MP[['ye_minus_se_rf','ye_minus_se_dmpnn']].values,L['Figure9']['observed_pairs'])
x=MP.ye_minus_se_rf;y=MP.ye_minus_se_dmpnn;equal([sum((x<0)&(y<0)),sum((x<0)&(y>=0)),sum((x>=0)&(y>=0)),sum((x>=0)&(y<0))],L['Figure9']['counts'])
for rec in L['Figure10']['routes']:
 z=FW[(FW.model=='rf')&(FW.route==rec['route'])];equal(z[['internal_skill','forward_skill']],rec['points']);equal(np.histogram(z.signed_gap,np.linspace(-.75,1.25,9))[0],rec['bins']);equal([z.signed_gap.median()],[rec['median_gap']])
for m,r,t,v,lo,hi in L['FigureS17']['intervals']:
 z=CI[(CI.model==m)&(CI.route==r)&(CI.target==t)];assert len(z)==1;equal(z[['skill','ci_low','ci_high']].iloc[0],[v,lo,hi])
for rec in L['FigureS18']['groups']:
 z=F2[(F2.target==rec['target'])&(F2.route==rec['route'])].skill;equal(z,rec['skills']);equal(np.quantile(z,[.25,.5,.75]),rec['summary']);assert len(z)==200
p=F2.pivot(index=['target','replicate'],columns='route',values='skill');p['difference']=p.temporal_exact-p.source_exact;p=p.reset_index()
for rec,ts in zip(L['FigureS18']['panel_medians'],[['alk','braf','egfr','erbb2','kdr','met'],['ache','dpp4','ptgs2','hdac1','pde4d']]):
 v=p[p.target.isin(ts)].groupby('replicate').difference.median().to_numpy();equal(v,rec['replicate_medians']);equal(np.quantile(v,[.025,.5,.975]),rec['percentiles'])
assert set(F2.rf_random_state)=={42,53,67};assert len(F2)==4400
for rec in L['FigureS22']['pool_summaries']:
 z=LP[(LP.target==rec['target'])&(LP.arm==rec['arm'])].sort_values(['label','record_uid']);equal(np.quantile(z.label,[.25,.5,.75]),rec['quartiles']);assert len(z)==rec['n'];idx=np.round(np.linspace(.05,.95,10)*(len(z)-1)).astype(int);assert z.iloc[idx].record_uid.tolist()==[v['record_uid'] for v in rec['points']];equal(z.iloc[idx].label,[v['label'] for v in rec['points']])
assert sum(v['n'] for v in L['FigureS22']['pool_summaries'])==87489
for rec in L['FigureS23']['panels']:
 z=PR[(PR.route==rec['route'])&(PR.model==rec['model'])];equal(z[['observed','predicted']],rec['observed_predicted']);v=z.predicted-z.observed;equal([np.sqrt(np.mean(v**2)),np.mean(abs(v))],[rec['RMSE'],rec['MAE']])
for rec in L['FigureS24']['groups']:
 z=AR[(AR.model==rec['model'])&(AR.target==rec['target'])&AR.arm.isin(['source_matched','year_matched'])]
 for key in ['test_n','train_n']:
  a=z.pivot(index='draw_seed',columns='arm',values=key);assert (a.source_matched==a.year_matched).all()
 p=z.pivot(index=['target','draw_seed'],columns='arm',values='mse').reset_index();equal(p[['source_matched','year_matched']],rec['pairs'])
 for arm,key in [('source_matched','source_summary'),('year_matched','year_summary')]:v=p[arm];equal([v.min(),v.median(),v.max()],rec[key])
 assert p.year_matched.nunique()==1
sets=[]
for rt in ['source_exact','temporal_exact']:
 for key in ['fragment_match','fingerprint_match']:
  z=FM[(FM.route==rt)&FM[key]];sets.append(set(zip(z.target,z.record_uid)))
u=set().union(*sets);equal([len(s) for s in sets],L['FigureS25']['sets']);assert len(u)==126
for pat,n in zip(L['FigureS25']['patterns'],L['FigureS25']['intersection_counts']):assert sum(tuple(v in s for s in sets)==tuple(pat) for v in u)==n
assert sum(L['FigureS25']['intersection_counts'])==126;assert L['FigureS25']['route_positive_contexts']==137
for t,key,v in L['FigureS26']['target_contrasts']:equal([PA.set_index('target').loc[t,key]],[v])
try:equal([1.0],[1.001])
except AssertionError:negative_control=True
else:raise AssertionError('Negative control failed')
files={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'data').iterdir() if p.is_file()}
(R/'reports/NUMERICAL_VERIFICATION.json').write_text(json.dumps({'status':'PASS','numeric_display_values_checked':checked,'figures_checked':10,'negative_control_perturbed_value_rejected':negative_control,'no_fits_resampling_or_new_predictions':True,'data_hashes':files},indent=2),encoding='utf-8')
print('Numeric PASS:',checked,'displayed values, 10 figures; deliberate perturbation rejected')
