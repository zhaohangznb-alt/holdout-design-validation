# Supporting data: V12-based submission candidate

This is an unpublished distribution candidate prepared on 7 October 2026. The author-approved current-version status is not inferred. The original V12 files are unchanged. No new model fits or experimental data were generated in this preparation.

Current entry points: `DISPLAY_SOURCE_INDEX.csv` (81 displays), `DIGITAL_TABLE_DICTIONARY_SUBMISSION.md`, `DIGITAL_TABLE_DICTIONARY_V12.md`, `source_provenance/SOURCE_EVIDENCE_STATUS.json`, and `DISTRIBUTION_CHANGES.json`. Historical dictionaries, indices, hash records and TOC artwork are labelled as histories, not current verification.

The results supplied here include F1 full Windows replay records, F2 training-document resampling, F5 common-test controls, F8 weighting, phase-3 D-MPNN/42-target panel/REML/release transition, limited-grid and checkpoint analyses, and post hoc conditional intervals. This is not a full training-input/model-weight/database distribution. The earlier 680-case offline pipeline and separately cited public supplements are available at https://github.com/zhaohangznb-alt/holdout-design-validation at their manuscript-cited immutable commits. No version DOI is verified; the repository records DOI pending.

## Portable conditional-interval replay

With existing NumPy and pandas, extract this package and run:
`python forward_uncertainty/forward_uncertainty.py --root /absolute/path/to/extracted/package`

Do not add `--prepare`. The portable replay uses supplied document-loss sums, holds fits and cohorts fixed, and writes `data/forward_conditional_intervals.csv` (90 intervals) and `posthoc_descriptive/FORWARD_UNCERTAINTY.json`. It needs no database or model weights. The preparation branch and other legacy fit scripts refer to the author's full local upstream environment; their presence does not establish portable full retraining. No full Linux 680-case retraining is claimed.

## Evidence boundaries

The copied contemporaneous API status reports ChEMBL 37; the BRAF retrieval manifest does not directly bind its activity pages to an immutable database release. Versioned ChEMBL 36/37 extension exports are a separate provenance chain. The seven Harris Table 1 numbers match the local original on physical PDF page 4 / printed page 4635, but biochemical/cellular endpoint ambiguity is unresolved. The publisher PDF and its page render are deliberately excluded. Initial 27h/27i retention timing and earliest adopted AI-use date are not authenticated.

Author-local path strings remain as provenance references and are not downloadable public sources. Their hashes do not substitute for absent upstream evidence. One private Cowork correspondence file is omitted; verbatim acceptance wording is removed from one CSV field while all scientific fields remain identical. The transformations and original hashes are recorded. This does not add author approval or original-source verification.

## Attribution and licensing

ChEMBL-derived records retain ChEMBL attribution and CC BY-SA 3.0 terms. The manuscript identifies author-created scripts under MIT; third-party notices remain applicable. Public-deposit metadata and final scope/licensing choices require author approval before release. This preparation does not deposit anything.
