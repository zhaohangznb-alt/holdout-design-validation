# V6 post hoc descriptive protocol

Recorded locally on 6 October 2026 before executing the V6 summary script. The received review is labelled 7 October 2026. This metadata discrepancy is retained; it is not evidence of a verified execution date.

The original results and the reviewer's preliminary summaries are already known. All analyses below are post hoc descriptive checks, without new fitting, resampling, inferential intervals, model selection or target reclassification.

1. Identify archived D-MPNN runs with zero-based best_epoch == 0; report epochs_run separately. Flag target/cohort pairs if either SE or YE has such a selected checkpoint. Summarise the remaining complete pairs without changing the primary 22-pair estimate. Export all flagged runs and retained pair values.
2. Report grid-minus-fresh-default signed route-skill changes separately for C00 selections and nondefault selections. Compare absolute differences with archived-default versus fresh-default route medians. The latter compares different recorded drivers; it does not identify a stochastic noise floor.
3. Count the eligible frame and selected targets by archived stratum. Compute a descriptive weighted median of the 42 Broad RF YE-SE contrasts with weights N_h/n_h, defined as the first sorted contrast whose cumulative weight reaches half the total. No uncertainty interval, population-representativeness claim or reclassification is added. Preserve the original target-equal primary median and stratified bootstrap.
4. Plot existing values only. Remove the 22-point KDE and tilted histogram presentation. Any display masking for n<30 must be logged and original values retained in raw digital evidence; no observation is removed from the original numerical records.

Additional minimum-training/checkpoint sensitivities and same-driver C00 repeats require separately specified computational protocols and are not executed by this revision.

Audit clarification: any selected first-epoch exact-route seed flags five pairs (not two). Alongside this pre-recorded any-seed rule, the reviewer's already known all-three-seeds rule is reproduced explicitly as a second descriptive, outcome-conditioned omission. The two denominators are kept separate. No deletion changes the primary results. Low-n S29 values are retained, with eligibility and stability explained, rather than selectively hiding BRAF while leaving other small groups unflagged.
