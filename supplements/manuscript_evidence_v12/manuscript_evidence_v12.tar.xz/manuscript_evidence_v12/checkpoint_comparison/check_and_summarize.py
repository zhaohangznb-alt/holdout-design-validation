"""Independent numerical/history verification and descriptive summaries; no refitting."""
from pathlib import Path
import hashlib,json,math
from datetime import datetime,timezone
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,obj):Path(p).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def simulate(values,start=0,patience=10):
    best=math.inf;best_ep=-1;wait=0;stop=None
    for ep,val in enumerate(values):
        if ep<start:continue
        if val<best:best=val;best_ep=ep;wait=0
        else:
            wait+=1
            if wait>=patience:stop=ep;break
    return best_ep,best,stop

reg=read(R/'REGISTRATION.json');regsha=sha(R/'REGISTRATION.json')
assert read(R/'FIT_COMPLETE.json')['fits']==12
contexts={tuple(c['key']):c for c in reg['contexts']}
records=[];histories=[];checks=[];protected=[]
for p,digest in reg['protected_source_hashes'].items():
    actual=sha(p);assert actual==digest,p
    protected.append({'path':p,'sha256':actual,'unchanged':True})
baseline=R.parent/'manuscript_review_response_v5_20261006_v6/reports/DRAFT_STATUS_V6.json'
for rel,digest in reg['bindings'].items():assert sha(R/rel)==digest,rel
row_checks=0
for p in sorted((R/'runs').glob('*/record.json')):
    q=read(p);key=tuple(q['key']);assert key in contexts and q['seed'] in reg['seeds']
    assert q['registration_sha256']==regsha and q['n_parameters']==318301
    assert q['max_epochs']==50 and q['patience']==10 and q['warmup_epochs']==2
    values=[h['val_loss_standardised'] for h in q['history']]
    assert [h['epoch_zero_based'] for h in q['history']]==list(range(len(values)))
    r_ep,r_val,r_stop=simulate(values)
    e_ep,e_val,e_stop=simulate(values,start=4)
    assert q['arms']['reference']['best_epoch_zero_based']==r_ep and q['reference_stop_epoch']==r_stop
    assert q['arms']['eligible']['best_epoch_zero_based']==e_ep>=4 and q['eligible_early_stop_epoch']==e_stop
    assert len(values)==(e_stop+1 if e_stop is not None else 50)
    assert q['epochs_completed']==len(values)
    archive=read(R/'archived_reference'/('_'.join(key)+f'_{q["seed"]}.json'))
    assert archive['best_epoch']==0 and archive['epochs_run']==11
    frames={part:pd.read_csv(R/info['path'],float_precision='round_trip') for part,info in contexts[key]['parts'].items()}
    test=frames['test'];valid=frames['valid'];tr=frames['train']
    mean=float(tr.target.mean());base=float(np.mean((test.target.to_numpy(float)-mean)**2))
    assert q['train_rows']==len(tr) and q['valid_rows']==len(valid) and q['test_rows']==len(test)
    seal=read(p.parent/'SELECTION_SEAL.json');assert seal['test_scoring_started'] is False
    for arm,expected_val in [('reference',r_val),('eligible',e_val)]:
        a=q['arms'][arm]
        for field in ('weights','predictions','valid_predictions'):
            assert sha(p.parent/a[field+'_file'])==a[field+'_sha256']
        assert seal['weights'][arm]==a['weights_sha256']
        pred=pd.read_csv(p.parent/a['predictions_file'],float_precision='round_trip')
        vp=pd.read_csv(p.parent/a['valid_predictions_file'],float_precision='round_trip')
        assert pred.record_uid.tolist()==test.record_uid.tolist() and vp.record_uid.tolist()==valid.record_uid.tolist()
        assert np.array_equal(pred.target.to_numpy(float),test.target.to_numpy(float))
        assert np.array_equal(vp.target.to_numpy(float),valid.target.to_numpy(float))
        assert np.isfinite(pred.prediction).all() and np.isfinite(vp.prediction).all()
        # The generating driver emits float32 model outputs. Reconstruct their dtype
        # from shortest-round-trip CSV strings before reproducing float64 loss arithmetic.
        mse=float(np.mean((test.target.to_numpy(float)-pred.prediction.to_numpy(np.float32))**2))
        vmse=float(np.mean((valid.target.to_numpy(float)-vp.prediction.to_numpy(np.float32))**2))
        for observed,expected in [(mse,a['test_mse']),(vmse,a['valid_mse']),(base,a['baseline_mse']),(1-mse/base,a['skill']),
                                  (expected_val,a['best_val_loss_standardised'])]:
            assert abs(observed-expected)<1e-12,(str(p),arm,observed,expected,abs(observed-expected))
        assert abs(vmse-a['valid_mse_from_loss'])<=max(1e-6,.001*vmse)
        row_checks+=len(pred)+len(vp)
        records.append({'scenario':key[0],'target':key[1],'route':key[2],'seed':q['seed'],'arm':arm,
                        'train_rows':len(tr),'valid_rows':len(valid),'test_rows':len(test),'training_mean':mean,
                        'skill':a['skill'],'test_mse':a['test_mse'],'baseline_mse':base,'valid_mse':vmse,
                        'best_epoch_completed':a['best_epoch_completed'],'epochs_completed':q['epochs_completed'],
                        'original_stop_epoch_completed':None if r_stop is None else r_stop+1,
                        'record_file':str(p),'weights_file':str(p.parent/a['weights_file']),'predictions_file':str(p.parent/a['predictions_file'])})
    records.append({'scenario':key[0],'target':key[1],'route':key[2],'seed':q['seed'],'arm':'archived',
                    'train_rows':archive['train_rows'],'valid_rows':archive['valid_rows'],'test_rows':archive['test_rows'],
                    'training_mean':archive['training_mean'],'skill':archive['skill'],'test_mse':archive['mse_model'],
                    'baseline_mse':archive['mse_mean'],'valid_mse':archive['valid_mse_best_weights'],
                    'best_epoch_completed':archive['best_epoch']+1,'epochs_completed':archive['epochs_run'],
                    'original_stop_epoch_completed':archive['epochs_run'],
                    'record_file':str(R/'archived_reference'/('_'.join(key)+f'_{q["seed"]}.json'))})
    for h in q['history']:histories.append({'scenario':key[0],'target':key[1],'route':key[2],'seed':q['seed'],**h})
    checks.append({'case':'_'.join(key),'seed':q['seed'],'best_epochs_recomputed':True,'stop_epochs_recomputed':True,
                   'prediction_metrics_recomputed':True,'selection_seal_hashes':True,'frozen_rows_and_labels_match':True})

f=pd.DataFrame(records)
f.to_csv(R/'RUN_COMPARISONS.csv',index=False)
pd.DataFrame(histories).to_csv(R/'VALIDATION_HISTORIES.csv',index=False)
route=f.groupby(['scenario','target','route','arm'],sort=True).agg(skill=('skill','median'),test_mse=('test_mse','median'),
             valid_mse=('valid_mse','median'),training_mean=('training_mean','first'),test_rows=('test_rows','first'),
             best_epoch_min=('best_epoch_completed','min'),best_epoch_max=('best_epoch_completed','max')).reset_index()
route.to_csv(R/'ROUTE_COMPARISONS.csv',index=False)
comparison=[]
for (scenario,target,rt),group in route.groupby(['scenario','target','route']):
    g=group.set_index('arm')
    comparison.append({'scenario':scenario,'target':target,'route':rt,'archived_skill':float(g.loc['archived','skill']),
         'reference_skill':float(g.loc['reference','skill']),'eligible_skill':float(g.loc['eligible','skill']),
         'reference_minus_archived':float(g.loc['reference','skill']-g.loc['archived','skill']),
         'eligible_minus_reference':float(g.loc['eligible','skill']-g.loc['reference','skill']),
         'eligible_minus_archived':float(g.loc['eligible','skill']-g.loc['archived','skill'])})
pd.DataFrame(comparison).to_csv(R/'ROUTE_CHANGES.csv',index=False)

# The other side is reused; these are targeted hybrid sensitivities, not full-panel retraining.
old=pd.read_csv(R/'archived_reference/dmpnn_runs.csv',float_precision='round_trip')
pairs=[]
for scenario,target in [('revised','pde4d'),('single_protein','kdr')]:
    for tier,left,right in [('exact','source_exact','temporal_exact'),('scaffold','source_scaffold','temporal_scaffold')]:
        for arm in ['archived','reference','eligible']:
            med={};reused=[]
            for rt in (left,right):
                z=route[(route.scenario==scenario)&(route.target==target)&(route.route==rt)&(route.arm==arm)]
                if len(z)==1:med[rt]=float(z.iloc[0].skill)
                else:
                    z=old[(old.scenario==scenario)&(old.target==target)&(old.route==rt)]
                    assert len(z)==3;med[rt]=float(z.skill.median());reused.append(rt)
            pairs.append({'scenario':scenario,'target':target,'tier':tier,'arm':arm,'source_route':left,'year_route':right,
                          'source_skill':med[left],'year_skill':med[right],'YE_minus_SE_skill':med[right]-med[left],
                          'unchanged_routes_reused':';'.join(reused),'paired_sample_size':1,'uncertainty':'none, descriptive'})
pd.DataFrame(pairs).to_csv(R/'TARGETED_PAIR_COMPARISONS.csv',index=False)
summary={'status':'PASS','fits':12,'selected_states':24,'prediction_and_validation_rows_checked':row_checks,
         'protected_source_files_unchanged':len(protected),'run_verifications':checks,
         'primary_panel_unchanged':{'median_YE_minus_SE':-.186,'negative_pairs':17,'pairs':22},
         'targeted_pairs':pairs,'route_changes':comparison,'finished_utc':datetime.now(timezone.utc).isoformat()}
save(R/'VERIFICATION.json',summary);save(R/'SOURCE_PRESERVATION.json',protected)
print(json.dumps({'status':'PASS','fits':12,'rows_checked':row_checks,'route_changes':comparison,
                  'exact_pairs':[x for x in pairs if x['tier']=='exact']},ensure_ascii=False,indent=2))
