from pathlib import Path
import json,sys
sys.path.insert(0,'E:/paper/kinase_followup_execution/algorithm_validation_extension_20261003_v1/plot_dependencies')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.lines import Line2D
from matplotlib.text import Text
from matplotlib import font_manager

R=Path(__file__).resolve().parent
D=R/'figures';D.mkdir(exist_ok=True)
font_manager.findfont('Times New Roman',fallback_to_default=False)
plt.rcParams.update({'font.family':'Times New Roman','font.size':10.5,'axes.titlesize':12,'axes.labelsize':11,
                    'xtick.labelsize':10,'ytick.labelsize':10,'legend.fontsize':10,'pdf.fonttype':42,
                    'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,
                    'axes.edgecolor':'#758592','figure.facecolor':'white','savefig.facecolor':'white','mathtext.fontset':'stix'})
BLUE='#0072B2';GREEN='#009E73';RED='#D55E00';GRAY='#637481'
armcolor={'archived':BLUE,'reference':GREEN,'eligible':RED}
armlabel={'archived':'Archived P3-A','reference':'Same-trajectory reference','eligible':'Epoch-5 eligibility'}
markers={'archived':'o','reference':'^','eligible':'s'}
cases=[('revised','pde4d','source_exact'),('revised','pde4d','source_scaffold'),
       ('single_protein','kdr','temporal_exact'),('single_protein','kdr','temporal_scaffold')]
titles=['PDE4D Broad | Source exact','PDE4D Broad | Source scaffold',
        'KDR Operational | Year exact','KDR Operational | Year scaffold']
records=[json.loads(p.read_text(encoding='utf-8')) for p in sorted((R/'runs').glob('*/record.json'))]
styles={42:'-',53:'--',67:'-.'}
run=pd.read_csv(R/'RUN_COMPARISONS.csv');pairs=pd.read_csv(R/'TARGETED_PAIR_COMPARISONS.csv')
qa=[]

def review(fig,label):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();w,h=fig.canvas.get_width_height();outside=[]
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text():continue
        b=text.get_window_extent(renderer)
        if b.x0<-.5 or b.y0<-.5 or b.x1>w+.5 or b.y1>h+.5:outside.append(text.get_text())
    assert not outside,(label,outside)
    qa.append({'figure':label,'text_inside_canvas':True,'font':'Times New Roman','numeric_points_from_archived_and_new_CSVs':True})
    fig.savefig(D/(label+'.svg'))
    fig.savefig(D/(label+'.png'),dpi=240)

fig,axs=plt.subplots(2,2,figsize=(9.6,7.2))
fig.subplots_adjust(left=.085,right=.97,bottom=.13,top=.78,wspace=.25,hspace=.39)
fig.suptitle('Validation trajectories and checkpoint selection',x=.5,y=.965,fontsize=16,fontweight='bold')
fig.text(.5,.92,'12 frozen-partition fits | 3 seeds per context | no test-based checkpoint selection',ha='center',fontsize=11,color=GRAY)
legend=[Line2D([],[],color=GRAY,ls=styles[s],lw=1.7,label=f'Seed {s}') for s in [42,53,67]]
legend += [Line2D([],[],ls='',marker='^',color=GREEN,ms=7,label='Original-rule prefix checkpoint'),
           Line2D([],[],ls='',marker='o',color=RED,ms=7,label='Epoch-5 eligible checkpoint')]
fig.legend(handles=legend,loc='upper center',bbox_to_anchor=(.5,.900),ncol=3,frameon=False,columnspacing=1.6)
for i,(ax,key,title) in enumerate(zip(axs.flat,cases,titles)):
    group=[q for q in records if tuple(q['key'])==key];assert len(group)==3
    for q in group:
        history=q['history'];xx=[h['epoch_completed'] for h in history];yy=[h['val_loss_standardised'] for h in history]
        ax.plot(xx,yy,color=GRAY,ls=styles[q['seed']],lw=1.6)
        for arm,marker,color in [('reference','^',GREEN),('eligible','o',RED)]:
            a=q['arms'][arm];ep=a['best_epoch_completed'];loss=a['best_val_loss_standardised']
            ax.scatter([ep],[loss],marker=marker,color=color,edgecolor='white',lw=.6,s=62,zorder=5)
    ax.axvspan(.5,4.5,color='#EEF1F3',zorder=-2)
    ax.axvline(4.5,color=RED,ls=':',lw=1.1)
    max_epoch=max(len(q['history']) for q in group)
    ax.set_xlim(.5,max_epoch+.8)
    ax.set_xticks([1]+list(range(5,max_epoch+1,5)))
    ax.set_title(chr(97+i)+'  '+title,loc='left',fontweight='bold',pad=9)
    ax.set_xlabel('Completed training epoch');ax.set_ylabel('Validation MSE (standardised labels)')
    ax.grid(axis='y',color='#E4E8EB',lw=.6);ax.tick_params(length=3)
fig.text(.085,.043,'Shaded epochs 1-4 cannot supply eligible weights; patience starts at epoch 5. Reference weights use the original-rule prefix.',fontsize=9.5,color=GRAY)
review(fig,'01_validation_trajectories')

f2,(a,b)=plt.subplots(1,2,figsize=(10.2,5.9),gridspec_kw={'width_ratios':[1.35,1]})
f2.subplots_adjust(left=.073,right=.975,bottom=.19,top=.74,wspace=.38)
f2.suptitle('Targeted D-MPNN checkpoint-eligibility comparison',y=.96,fontsize=16,fontweight='bold')
f2.text(.5,.906,'All seed estimates retained; large diamonds show three-seed medians',ha='center',fontsize=11,color=GRAY)
f2.legend(handles=[Line2D([],[],ls='',marker=markers[arm],color=armcolor[arm],ms=7,label=armlabel[arm]) for arm in armcolor],
          loc='upper center',bbox_to_anchor=(.5,.865),ncol=3,frameon=False)
for j,key in enumerate(cases):
    for offset,arm in zip([-.24,0,.24],armcolor):
        z=run[(run.scenario==key[0])&(run.target==key[1])&(run.route==key[2])&(run.arm==arm)].sort_values('seed')
        assert len(z)==3
        xx=j+offset+np.array([-.042,0,.042]);yy=z.skill.to_numpy(float)
        a.scatter(xx,yy,color=armcolor[arm],marker=markers[arm],s=24,alpha=.65,zorder=3)
        a.scatter([j+offset],[float(z.skill.median())],marker='D',color=armcolor[arm],edgecolor='white',lw=.6,s=64,zorder=4)
a.axhline(0,color=GRAY,ls='--',lw=.8);a.set_ylabel('Absolute test skill vs training mean')
a.set_xticks(range(4),['PDE4D B\nSE','PDE4D B\nSS','KDR O\nYE','KDR O\nYS']);a.set_xlim(-.6,3.55)
a.grid(axis='y',color='#E4E8EB',lw=.6);a.set_title('a  Affected route populations',loc='left',fontweight='bold',pad=12)
for i,(scenario,target) in enumerate([('revised','pde4d'),('single_protein','kdr')]):
    y=1-i
    for dy,arm in zip([.16,0,-.16],armcolor):
        row=pairs[(pairs.scenario==scenario)&(pairs.target==target)&(pairs.tier=='exact')&(pairs.arm==arm)].iloc[0]
        value=float(row.YE_minus_SE_skill)
        b.plot([0,value],[y+dy,y+dy],color=armcolor[arm],alpha=.50,lw=1.8)
        b.scatter([value],[y+dy],color=armcolor[arm],marker=markers[arm],s=48,zorder=5)
        b.annotate(f'{value:+.3f}'.replace('-','−'),(value,y+dy),xytext=((-5,0) if value<0 else (5,0)),textcoords='offset points',ha=('right' if value<0 else 'left'),va='center',fontsize=10)
b.axvline(0,color=GRAY,ls='--',lw=.8)
b.set_yticks([1,0],['PDE4D\nBroad','KDR\nOperational']);b.set_ylim(-.42,1.45);b.set_xlim(-.24,.235)
b.set_xticks([-.15,-.10,-.05,0,.05,.10,.15,.20])
b.set_xlabel('Year-exact minus source-exact skill');b.grid(axis='x',color='#E4E8EB',lw=.6)
b.set_title('b  Targeted route contrasts',loc='left',fontweight='bold',pad=12)
f2.text(.073,.075,'Panel b reuses archived YE for PDE4D and archived SE for KDR. This is a post hoc targeted sensitivity; the primary 22-pair result is retained.',fontsize=9.2,color=GRAY)
f2.text(.073,.039,'B = Broad; O = Operational; SE/SS = source exact/scaffold; YE/YS = year exact/scaffold. No inferential intervals are added.',fontsize=9.2,color=GRAY)
review(f2,'02_checkpoint_results')
with PdfPages(R/'CHECKPOINT_COMPARISON.pdf') as pdf:pdf.savefig(fig);pdf.savefig(f2)
plt.close('all')
(R/'VISUAL_QA.json').write_text(json.dumps({'status':'PASS','figures':qa,'PDF_pages':2,'palette':armcolor},indent=2)+'\n',encoding='utf-8')
print('DRAW PASS: two-page PDF, SVG and PNG figures')
