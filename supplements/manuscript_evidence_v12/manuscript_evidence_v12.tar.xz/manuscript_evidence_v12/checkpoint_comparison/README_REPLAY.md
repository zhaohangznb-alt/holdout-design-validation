# Targeted checkpoint sensitivity: compact supporting-data subset

This subset contains frozen input CSVs, all recorded prediction CSVs, validation histories, seals, source snapshots, protocols and numerical verification records from the completed 12-fit comparison. Trained weight files are intentionally excluded from this compact SI archive; they remain in the author's complete local checkpoint archive. No end-to-end retraining or weight reload can be run from this compact subset alone.

ORIGINAL_FULL_ARCHIVE_README.md and ORIGINAL_FULL_ARCHIVE_SHA256SUMS.txt describe the original complete local delivery, including its 24 weight states. They are provenance records, not manifests of this compact subset. The enclosing SI_DATA.zip SHA256_MANIFEST.json is authoritative for supplied files. The original scripts retain their recorded workspace paths.
