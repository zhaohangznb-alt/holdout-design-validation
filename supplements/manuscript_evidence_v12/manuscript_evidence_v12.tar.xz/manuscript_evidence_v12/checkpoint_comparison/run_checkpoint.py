"""Registered checkpoint eligibility comparison: 12 fits, same-trajectory reference."""
from pathlib import Path
import argparse, copy, hashlib, importlib.util, json, math, os, platform, sys, time
from datetime import datetime, timezone
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
SEEDS=[42,53,67]
CASES=[('revised','pde4d','source_exact'),('revised','pde4d','source_scaffold'),
       ('single_protein','kdr','temporal_exact'),('single_protein','kdr','temporal_scaffold')]
P3=Path('E:/paper/kinase_followup_execution/claude_manuscript_polish_20261002_v1/cowork_workspace/round2_claude_20261004')
F1=P3/'f1/bundle/reproduced_full_r2'
ARCH=P3/'results/p3/dmpnn/runs'
DRIVER=P3/'compute/p3_dmpnn.py'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat()
def save(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False,default=str)+'\n',encoding='utf-8')
    tmp.replace(p)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def name(key,seed=None):return '_'.join(key)+(f'_{seed}' if seed is not None else '')

def prepare():
    assert not (ROOT/'REGISTRATION.json').exists(),'Already registered; resume rather than overwrite.'
    import torch, chemprop, lightning, rdkit, sklearn
    assert torch.cuda.is_available()
    assert (torch.__version__,chemprop.__version__,lightning.__version__)==('2.6.0+cu124','2.2.4','2.6.6')
    from chemprop import models,nn
    from lightning.pytorch.callbacks import EarlyStopping
    import inspect
    default_model=models.MPNN(nn.BondMessagePassing(),nn.MeanAggregation(),nn.RegressionFFN())
    model_defaults={k:(v if isinstance(v,(int,float,str,bool,type(None))) else str(v)) for k,v in dict(default_model.hparams).items()}
    environment={'python':platform.python_version(),'platform':platform.platform(),'executable':sys.executable,
                 'torch':torch.__version__,'chemprop':chemprop.__version__,'lightning':lightning.__version__,
                 'rdkit':rdkit.__version__,'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,
                 'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'gpu_capability':torch.cuda.get_device_capability(0),
                 'cudnn_deterministic':torch.backends.cudnn.deterministic,'cudnn_benchmark':torch.backends.cudnn.benchmark,
                 'deterministic_algorithms':torch.are_deterministic_algorithms_enabled(),'matmul_precision':torch.get_float32_matmul_precision(),
                 'cuda_matmul_allow_tf32':torch.backends.cuda.matmul.allow_tf32,'threads':torch.get_num_threads(),
                 'CUDA_VISIBLE_DEVICES':os.getenv('CUDA_VISIBLE_DEVICES'),'CUBLAS_WORKSPACE_CONFIG':os.getenv('CUBLAS_WORKSPACE_CONFIG'),
                 'model_defaults':model_defaults}
    save(ROOT/'ENVIRONMENT.json',environment)
    (ROOT/'source_code').mkdir(exist_ok=True)
    (ROOT/'source_code/p3_dmpnn_original.py').write_bytes(DRIVER.read_bytes())
    (ROOT/'source_code/lightning_early_stopping.txt').write_text(inspect.getsource(EarlyStopping),encoding='utf-8')
    (ROOT/'source_code/chemprop_configure_optimizers.txt').write_text(inspect.getsource(models.MPNN.configure_optimizers),encoding='utf-8')
    sources={};contexts=[]
    for key in CASES:
        scenario,target,route=key
        origin=F1/('current_prepared' if target=='kdr' else 'external_prepared')
        manifest=origin/'split_manifest.csv';sources[str(manifest)]=sha(manifest)
        rows=pd.read_csv(manifest)
        selected=rows[(rows.view=='main')&(rows.scenario==scenario)&(rows.target==target)&(rows.route==route)]
        assert set(selected.partition)=={'train','valid','test'}
        parts={}
        for r in selected.itertuples():
            src=origin/'data/main'/Path(str(r.corrected_csv).replace('\\','/')).name
            assert sha(src)==r.corrected_sha256
            f=pd.read_csv(src,float_precision='round_trip');assert len(f)==r.corrected_rows
            dst=ROOT/'inputs'/src.name;dst.parent.mkdir(exist_ok=True);dst.write_bytes(src.read_bytes())
            parts[r.partition]={'path':dst.relative_to(ROOT).as_posix(),'sha256':sha(dst),'rows':len(f),'source':str(src),
                                'source_signature':r.corrected_ordered_signature,
                                'signature_read_round_trip':hashlib.sha256(f[['record_uid','smiles','target']].to_csv(index=False).encode()).hexdigest()}
            sources[str(src)]=sha(src)
        contexts.append({'key':list(key),'parts':parts})
    ref=ROOT/'archived_reference';ref.mkdir(exist_ok=True)
    # Both affected routes and unchanged counterparts; all 264 original metrics for accounting.
    for path in sorted(ARCH.glob('*.json')):
        obj=read(path)
        if obj['target'] not in ('pde4d','kdr'):continue
        (ref/path.name).write_bytes(path.read_bytes());sources[str(path)]=sha(path)
        pred=path.with_suffix('.predictions.csv')
        if pred.exists():(ref/pred.name).write_bytes(pred.read_bytes());sources[str(pred)]=sha(pred)
    runs=P3/'results/p3/dmpnn/dmpnn_runs.csv'
    (ref/'dmpnn_runs.csv').write_bytes(runs.read_bytes());sources[str(runs)]=sha(runs)
    for p in [DRIVER,ROOT/'PROTOCOL_CN.md',ROOT/'run_checkpoint.py',
              Path('E:/paper/visual_audit/manuscript_review_response_v5_20261006_v6/manuscript/main_optimized.tex'),
              Path('E:/paper/visual_audit/manuscript_review_response_v5_20261006_v6/manuscript/supporting_information_optimized.tex')]:
        if p.is_file():sources[str(p)]=sha(p)
    binding={p.relative_to(ROOT).as_posix():sha(p) for p in ROOT.rglob('*') if p.is_file()}
    save(ROOT/'REGISTRATION.json',{'analysis_id':'CP-E5-20261006','registered_utc':stamp(),
          'author_authorization':'User annotated 开展 checkpoint 对照 with 好 in this chat.',
          'intent':'post hoc descriptive sensitivity; original outcomes known','fits_budget':12,
          'minimum_eligible_epoch_zero_based':4,'max_epochs':50,'patience':10,'min_delta':0,
          'seeds':SEEDS,'contexts':contexts,'bindings':binding,'protected_source_hashes':sources,'environment':environment,
          'primary_results_replaced':False,'scope_excludes_132_fit_C00_repeat':True})
    save(ROOT/'RUN_STATUS.json',{'stage':'registered','actual_fits':0,'expected_fits':12,'registered_utc':stamp()})
    print('REGISTERED 4 contexts, 12 fits. Warmup:',model_defaults.get('warmup_epochs'),flush=True)

def callbacks():
    from lightning.pytorch.callbacks import EarlyStopping,Callback
    class EligibleStopping(EarlyStopping):
        def _run_early_stopping_check(self,trainer):
            if trainer.current_epoch<4:return
            super()._run_early_stopping_check(trainer)
    class ReferenceStopping(EarlyStopping):
        def __init__(self,**kwargs):
            super().__init__(**kwargs);self.frozen=False;self.reference_stop_epoch=None
        def _run_early_stopping_check(self,trainer):
            if self.frozen:return
            prior=trainer.should_stop
            super()._run_early_stopping_check(trainer)
            # This superclass's stopped_epoch is set only on its own stop signal.
            if self.stopped_epoch==trainer.current_epoch and self.stopping_reason_message is not None:
                self.frozen=True;self.reference_stop_epoch=int(trainer.current_epoch)
            trainer.should_stop=prior
    class Weights(Callback):
        def __init__(self,reference):
            self.reference=reference;self.history=[]
            self.best={'reference':float('inf'),'eligible':float('inf')};self.epochs={'reference':-1,'eligible':-1}
            self.states={'reference':None,'eligible':None}
        def on_validation_end(self,trainer,module):
            if trainer.sanity_checking:return
            epoch=int(trainer.current_epoch);v=float(trainer.callback_metrics['val_loss']);assert math.isfinite(v)
            self.history.append({'epoch_zero_based':epoch,'epoch_completed':epoch+1,'val_loss_standardised':v,
                                 'lr':float(trainer.optimizers[0].param_groups[0]['lr'])})
            for arm,allowed in [('reference',not self.reference.frozen),('eligible',epoch>=4)]:
                if allowed and v<self.best[arm]:
                    self.best[arm]=v;self.epochs[arm]=epoch
                    self.states[arm]=copy.deepcopy({k:t.detach().cpu() for k,t in module.state_dict().items()})
    return EligibleStopping,ReferenceStopping,Weights

def mechanism_check():
    import torch
    from types import SimpleNamespace
    ES,RS,W=callbacks()
    class Strategy:
        @staticmethod
        def reduce_boolean_decision(value,all=False):return value
    history=[1.0]+[2.0+i*.01 for i in range(20)]
    es=ES(monitor='val_loss',mode='min',patience=10);rs=RS(monitor='val_loss',mode='min',patience=10)
    module=torch.nn.Linear(1,1);w=W(rs)
    trainer=SimpleNamespace(current_epoch=0,callback_metrics={},fast_dev_run=False,should_stop=False,
                            strategy=Strategy(),sanity_checking=False,optimizers=[SimpleNamespace(param_groups=[{'lr':.001}])])
    for ep,value in enumerate(history):
        trainer.current_epoch=ep;trainer.callback_metrics['val_loss']=torch.tensor(value)
        w.on_validation_end(trainer,module);es._run_early_stopping_check(trainer);rs._run_early_stopping_check(trainer)
        if trainer.should_stop:break
    assert w.epochs=={'reference':0,'eligible':4}
    assert rs.reference_stop_epoch==10 and ep==14 and len(w.history)==15
    assert float(rs.best_score)==1.0 and abs(float(es.best_score)-2.03)<1e-5
    save(ROOT/'MECHANISM_CHECK.json',{'status':'PASS','test_type':'synthetic validation sequence, no scientific fit',
         'reference_best_epoch':0,'reference_stop_epoch':10,'eligible_best_epoch':4,'eligible_stop_epoch':14,
         'reference_updates_frozen_after_original_stop':True,'eligible_patience_does_not_start_before_epoch4':True})
    print('CHECKPOINT MECHANISM PASS',flush=True)

def frame(part):
    p=ROOT/part['path'];assert sha(p)==part['sha256']
    f=pd.read_csv(p,float_precision='round_trip');assert len(f)==part['rows'];return f

def fit(context,seed,registration):
    import torch
    from torch.utils.data import DataLoader
    from lightning import pytorch as pl
    from chemprop import data,featurizers,models,nn
    key=context['key'];dest=ROOT/'runs'/name(key,seed);dest.mkdir(parents=True,exist_ok=True)
    recfile=dest/'record.json'
    if recfile.exists():
        rec=read(recfile);assert rec['registration_sha256']==registration
        for arm in ('reference','eligible'):
            for field in ('weights','predictions','valid_predictions'):
                assert sha(dest/rec['arms'][arm][field+'_file'])==rec['arms'][arm][field+'_sha256']
        return rec
    parts={p:frame(q) for p,q in context['parts'].items()};trf,vaf,tef=[parts[p] for p in ('train','valid','test')]
    pl.seed_everything(seed,workers=True)
    feat=featurizers.SimpleMoleculeMolGraphFeaturizer()
    def dset(f):
        d=data.MoleculeDataset([data.MoleculeDatapoint.from_smi(s,y=np.array([float(y)])) for s,y in zip(f.smiles,f.target)],feat)
        d.cache=True;return d
    tr,va,te=dset(trf),dset(vaf),dset(tef)
    scaler=tr.normalize_targets();va.normalize_targets(scaler)
    model=models.MPNN(nn.BondMessagePassing(),nn.MeanAggregation(),nn.RegressionFFN(output_transform=nn.UnscaleTransform.from_standard_scaler(scaler)))
    trl=data.build_dataloader(tr,num_workers=0,seed=seed)
    val=DataLoader(va,batch_size=64,shuffle=False,collate_fn=data.collate_batch)
    tel=DataLoader(te,batch_size=64,shuffle=False,collate_fn=data.collate_batch)
    ES,RS,W=callbacks();es=ES(monitor='val_loss',mode='min',patience=10)
    rs=RS(monitor='val_loss',mode='min',patience=10);best=W(rs)
    trainer=pl.Trainer(logger=False,enable_checkpointing=False,enable_progress_bar=False,enable_model_summary=False,
        accelerator='gpu',devices=1,max_epochs=50,callbacks=[es,best,rs],num_sanity_val_steps=0,default_root_dir=str(dest/'lightning'))
    started=stamp();t0=time.monotonic();trainer.fit(model,trl,val)
    assert best.states['reference'] is not None and best.states['eligible'] is not None
    assert best.epochs['eligible']>=4
    # Seal BOTH validation-selected states before any new test metric is computed.
    for arm,state in best.states.items():torch.save(state,dest/(arm+'_weights.pt'))
    save(dest/'SELECTION_SEAL.json',{'sealed_utc':stamp(),'registration_sha256':registration,
        'weights':{arm:sha(dest/(arm+'_weights.pt')) for arm in best.states},'selected_epochs':best.epochs,
        'selected_val_loss':best.best,'reference_stop_epoch':rs.reference_stop_epoch,'test_scoring_started':False})
    arms={};mean=float(trf.target.mean());y=tef.target.to_numpy(float);base=float(np.mean((y-mean)**2));assert base>0
    for arm in ('reference','eligible'):
        model.load_state_dict(best.states[arm])
        pred=torch.cat(trainer.predict(model,tel)).float().cpu().numpy().reshape(-1)
        vp=torch.cat(trainer.predict(model,DataLoader(dset(vaf),batch_size=64,shuffle=False,collate_fn=data.collate_batch))).float().cpu().numpy().reshape(-1)
        assert len(pred)==len(y) and np.isfinite(pred).all() and len(vp)==len(vaf) and np.isfinite(vp).all()
        mse=float(np.mean((y-pred)**2));vmse=float(np.mean((vaf.target.to_numpy(float)-vp)**2))
        expected=best.best[arm]*float(scaler.scale_[0])**2
        assert abs(vmse-expected)<=max(1e-6,.001*vmse)
        pd.DataFrame({'record_uid':tef.record_uid,'target':y,'prediction':pred}).to_csv(dest/(arm+'_predictions.csv'),index=False)
        pd.DataFrame({'record_uid':vaf.record_uid,'target':vaf.target,'prediction':vp}).to_csv(dest/(arm+'_valid_predictions.csv'),index=False)
        arms[arm]={'best_epoch_zero_based':best.epochs[arm],'best_epoch_completed':best.epochs[arm]+1,
                   'best_val_loss_standardised':best.best[arm],'valid_mse':vmse,'valid_mse_from_loss':expected,
                   'test_mse':mse,'baseline_mse':base,'skill':1-mse/base,'rmse':math.sqrt(mse),
                   'mae':float(np.mean(np.abs(y-pred))),'training_mean':mean}
        for field,filename in [('weights',arm+'_weights.pt'),('predictions',arm+'_predictions.csv'),('valid_predictions',arm+'_valid_predictions.csv')]:
            arms[arm][field+'_file']=filename;arms[arm][field+'_sha256']=sha(dest/filename)
    rec={'key':key,'seed':seed,'registration_sha256':registration,'started_utc':started,'finished_utc':stamp(),
         'train_rows':len(trf),'valid_rows':len(vaf),'test_rows':len(tef),'epochs_completed':len(best.history),
         'eligible_early_stop_epoch':int(es.stopped_epoch) if es.stopped_epoch>0 else None,
         'reference_stop_epoch':rs.reference_stop_epoch,'history':best.history,'arms':arms,
         'elapsed_seconds':time.monotonic()-t0,'max_epochs':50,'patience':10,'warmup_epochs':model.warmup_epochs,
         'scaler_mean':float(scaler.mean_[0]),'scaler_scale':float(scaler.scale_[0]),
         'n_parameters':sum(p.numel() for p in model.parameters()),'training_batches_per_epoch':len(trl),
         'early_stopping_check_on_train_epoch_end':es._check_on_train_epoch_end}
    save(recfile,rec);return rec

def run():
    registration=sha(ROOT/'REGISTRATION.json');reg=read(ROOT/'REGISTRATION.json')
    for rel,digest in reg['bindings'].items():assert sha(ROOT/rel)==digest,rel
    assert read(ROOT/'MECHANISM_CHECK.json')['status']=='PASS'
    completed=[]
    for c in reg['contexts']:
        for seed in reg['seeds']:
            rec=fit(c,seed,registration);completed.append(rec)
            save(ROOT/'RUN_STATUS.json',{'stage':'fitting','completed_fits':len(completed),'expected_fits':12,
                                        'last':name(c['key'],seed),'updated_utc':stamp(),'registration_sha256':registration})
            print('FIT',len(completed),'/12',name(c['key'],seed),'epochs',rec['epochs_completed'],
                  'reference skill',round(rec['arms']['reference']['skill'],6),'eligible skill',round(rec['arms']['eligible']['skill'],6),
                  'best',rec['arms']['reference']['best_epoch_completed'],rec['arms']['eligible']['best_epoch_completed'],flush=True)
    save(ROOT/'FIT_COMPLETE.json',{'status':'PASS','fits':len(completed),'expected_fits':12,'completed_utc':stamp(),
                                  'registration_sha256':registration,'new_models_from_fit_trajectories':12,'validation_selected_states':24})

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['prepare','check','run']);args=parser.parse_args()
    {'prepare':prepare,'check':mechanism_check,'run':run}[args.phase]()
