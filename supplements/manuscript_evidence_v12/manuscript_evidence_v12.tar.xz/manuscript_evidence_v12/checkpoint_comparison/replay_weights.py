"""Reload all saved validation-selected states and independently regenerate test predictions."""
from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from lightning import pytorch as pl
from chemprop import data,featurizers,models,nn
from sklearn.preprocessing import StandardScaler

R=Path(__file__).resolve().parent
reg=json.loads((R/'REGISTRATION.json').read_text(encoding='utf-8'))
contexts={tuple(c['key']):c for c in reg['contexts']};results=[]
for p in sorted((R/'runs').glob('*/record.json')):
    rec=json.loads(p.read_text(encoding='utf-8'));context=contexts[tuple(rec['key'])]
    src=R/context['parts']['test']['path'];assert hashlib.sha256(src.read_bytes()).hexdigest()==context['parts']['test']['sha256']
    f=pd.read_csv(src,float_precision='round_trip')
    ds=data.MoleculeDataset([data.MoleculeDatapoint.from_smi(sm,y=np.array([float(y)])) for sm,y in zip(f.smiles,f.target)],featurizers.SimpleMoleculeMolGraphFeaturizer())
    ds.cache=True;loader=DataLoader(ds,batch_size=64,shuffle=False,collate_fn=data.collate_batch)
    scaler=StandardScaler();scaler.mean_=np.array([rec['scaler_mean']]);scaler.scale_=np.array([rec['scaler_scale']])
    scaler.var_=scaler.scale_**2;scaler.n_features_in_=1
    trainer=pl.Trainer(logger=False,enable_checkpointing=False,enable_progress_bar=False,enable_model_summary=False,accelerator='gpu',devices=1)
    for arm in ('reference','eligible'):
        info=rec['arms'][arm];weights=p.parent/info['weights_file']
        assert hashlib.sha256(weights.read_bytes()).hexdigest()==info['weights_sha256']
        model=models.MPNN(nn.BondMessagePassing(),nn.MeanAggregation(),nn.RegressionFFN(output_transform=nn.UnscaleTransform.from_standard_scaler(scaler)))
        model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True))
        prediction=torch.cat(trainer.predict(model,loader)).float().cpu().numpy().reshape(-1)
        expected=pd.read_csv(p.parent/info['predictions_file'],float_precision='round_trip')
        assert f.record_uid.tolist()==expected.record_uid.tolist() and np.array_equal(f.target,expected.target)
        err=float(np.max(np.abs(prediction.astype(float)-expected.prediction.to_numpy(np.float32).astype(float))))
        assert np.isfinite(prediction).all() and err<=1e-6,(p.parent.name,arm,err)
        results.append({'run':p.parent.name,'arm':arm,'rows':len(f),'max_abs_prediction_difference':err,'tolerance':1e-6,'passed':True})
print('REPLAY PASS',len(results),'states; max difference',max(x['max_abs_prediction_difference'] for x in results),flush=True)
(R/'WEIGHT_REPLAY_CHECK.json').write_text(json.dumps({'status':'PASS','new_fits':0,'states_reloaded':len(results),
             'rows':sum(x['rows'] for x in results),'checks':results,'finished_utc':datetime.now(timezone.utc).isoformat()},indent=2)+'\n',encoding='utf-8')
