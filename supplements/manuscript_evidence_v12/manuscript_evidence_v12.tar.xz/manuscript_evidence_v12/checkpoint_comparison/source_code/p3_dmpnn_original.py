"""P3-A: D-MPNN (Chemprop 2.2 defaults, no tuning) on the archived main-view partitions (PROTOCOL_PHASE3.md, C8-C9).
Runs in the separate environment E:\\paper\\kinase_followup_execution\\.venv-dmpnn (Python 3.11, PyTorch CUDA, Chemprop 2.2).
  --smoke : one context (main/revised/alk/source_exact), seed 42, 2 epochs, with consistency checks; NOT a result
  full    : 88 contexts x seeds 42/53/67, <= 50 epochs, early stopping (patience 10) on val_loss (validation MSE on standardised
            labels); best-validation weights kept in memory; test rows predicted once with those weights. Restartable.
"""
import argparse, json, time, hashlib, platform, sys, copy, datetime
from pathlib import Path
import numpy as np
import pandas as pd

SEEDS = [42, 53, 67]
ROUTES = ["source_exact", "source_scaffold", "temporal_exact", "temporal_scaffold"]
KINASES = ["alk", "braf", "egfr", "erbb2", "kdr", "met"]


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, obj):
    p = Path(p); tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str), encoding="utf8"); tmp.replace(p)


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sig(f):
    return hashlib.sha256(f[["record_uid", "smiles", "target"]].to_csv(index=False).encode()).hexdigest()


def load_contexts(roots):
    """Main-view partitions from the F1 reproduction, checked by SHA-256 and row count (C9); signature recorded."""
    ctx, checks = {}, []
    for root in roots:
        root = Path(root).resolve()
        s = pd.read_csv(root / "split_manifest.csv")
        s = s[s.view == "main"]
        for r in s.itertuples():
            p = root / "data" / str(r.view) / str(r.corrected_csv).replace("\\", "/").rsplit("/", 1)[-1]
            assert sha(p) == r.corrected_sha256, p
            f = pd.read_csv(p, float_precision="round_trip")
            assert len(f) == r.corrected_rows, p
            checks.append(dict(file=p.name, sha256_ok=True, rows_ok=True, signature_equal=sig(f) == r.corrected_ordered_signature))
            ctx.setdefault((r.scenario, r.target, r.route), {})[r.partition] = f
    return ctx, checks


def versions():
    import torch, chemprop, lightning, rdkit, sklearn
    return dict(python=platform.python_version(), platform=platform.platform(), torch=torch.__version__, cuda=torch.version.cuda,
                cuda_available=torch.cuda.is_available(), gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
                chemprop=chemprop.__version__, lightning=lightning.__version__, rdkit=rdkit.__version__, numpy=np.__version__,
                pandas=pd.__version__, sklearn=sklearn.__version__, cudnn_deterministic=torch.backends.cudnn.deterministic,
                executable=sys.executable)


def train_one(parts, seed, max_epochs, patience, workdir):
    import torch
    from torch.utils.data import DataLoader
    from lightning import pytorch as pl
    from lightning.pytorch.callbacks import EarlyStopping, Callback
    from chemprop import data, featurizers, models, nn

    class Best(Callback):
        def __init__(self):
            self.best, self.state, self.epoch, self.history = float("inf"), None, -1, []

        def on_validation_end(self, trainer, pl_module):
            if trainer.sanity_checking:
                return
            v = trainer.callback_metrics.get("val_loss")
            if v is None:
                return
            v = float(v); self.history.append([int(trainer.current_epoch), v])
            if v < self.best:
                self.best, self.epoch = v, int(trainer.current_epoch)
                self.state = copy.deepcopy({k: t.detach().cpu() for k, t in pl_module.state_dict().items()})

    pl.seed_everything(seed, workers=True)
    feat = featurizers.SimpleMoleculeMolGraphFeaturizer()

    def dset(f):
        d = data.MoleculeDataset([data.MoleculeDatapoint.from_smi(s, y=np.array([float(y)])) for s, y in zip(f.smiles, f.target)], feat)
        d.cache = True
        return d
    tr, va, te = dset(parts["train"]), dset(parts["valid"]), dset(parts["test"])
    scaler = tr.normalize_targets(); va.normalize_targets(scaler)
    model = models.MPNN(nn.BondMessagePassing(), nn.MeanAggregation(), nn.RegressionFFN(output_transform=nn.UnscaleTransform.from_standard_scaler(scaler)))
    trl = data.build_dataloader(tr, num_workers=0, seed=seed)                       # Chemprop default: batch 64, seeded shuffle
    val = DataLoader(va, batch_size=64, shuffle=False, collate_fn=data.collate_batch)   # no row dropped from validation
    tel = DataLoader(te, batch_size=64, shuffle=False, collate_fn=data.collate_batch)   # no row dropped from test
    best = Best()
    es = EarlyStopping(monitor="val_loss", mode="min", patience=patience)
    trainer = pl.Trainer(logger=False, enable_checkpointing=False, enable_progress_bar=False, enable_model_summary=False,
                         accelerator="gpu" if torch.cuda.is_available() else "cpu", devices=1, max_epochs=max_epochs,
                         callbacks=[es, best], num_sanity_val_steps=0, default_root_dir=str(workdir))
    t0 = time.time()
    trainer.fit(model, trl, val)
    fit_s = time.time() - t0
    assert best.state is not None, "no validation epoch completed"
    model.load_state_dict(best.state)
    pred = torch.cat(trainer.predict(model, tel)).float().cpu().numpy().reshape(-1)
    vpred = torch.cat(trainer.predict(model, DataLoader(dset(parts["valid"]), batch_size=64, shuffle=False, collate_fn=data.collate_batch))).float().cpu().numpy().reshape(-1)
    hp = {k: (v if isinstance(v, (int, float, str, bool, type(None))) else str(v)) for k, v in dict(model.hparams).items()}
    info = dict(epochs_run=int(trainer.current_epoch), best_epoch=best.epoch, best_val_loss_standardised=best.best, history=best.history,
                stopped_early=bool(es.stopped_epoch > 0), fit_seconds=round(fit_s, 1), scaler_mean=float(scaler.mean_[0]),
                scaler_scale=float(scaler.scale_[0]), hparams=hp, n_parameters=int(sum(p.numel() for p in model.parameters())),
                train_batches_per_epoch=len(trl))
    return pred, vpred, info


def metrics(y, p, mean):
    mse = float(np.mean((y - p) ** 2)); base = float(np.mean((y - mean) ** 2))
    return dict(mse_model=mse, mse_mean=base, rmse_model=float(np.sqrt(mse)), rmse_mean=float(np.sqrt(base)),
                mae_model=float(np.mean(np.abs(y - p))), mae_mean=float(np.mean(np.abs(y - mean))), skill=1 - mse / base if base > 0 else None)


def run(key, parts, seed, max_epochs, patience, outdir):
    scenario, target, route = key
    name = f"{scenario}_{target}_{route}_{seed}"
    dest = outdir / f"{name}.json"
    if dest.exists():
        return json.loads(dest.read_text(encoding="utf8"))
    pred, vpred, info = train_one(parts, seed, max_epochs, patience, outdir / "_lightning")
    tr, va, te = parts["train"], parts["valid"], parts["test"]
    mean = float(tr.target.mean()); y = te.target.to_numpy(float)
    assert len(pred) == len(te) and np.isfinite(pred).all()
    pd.DataFrame(dict(record_uid=te.record_uid, target=y, prediction=pred)).to_csv(outdir / f"{name}.predictions.csv", index=False)
    vmse = float(np.mean((va.target.to_numpy(float) - vpred) ** 2))
    rec = dict(view="main", scenario=scenario, target=target, route=route, model="dmpnn", seed=seed, train_rows=len(tr), valid_rows=len(va),
               test_rows=len(te), training_mean=mean, **metrics(y, pred, mean), valid_mse_best_weights=vmse,
               valid_mse_from_val_loss=info["best_val_loss_standardised"] * info["scaler_scale"] ** 2,
               prediction_sha256=sha(outdir / f"{name}.predictions.csv"), max_epochs=max_epochs, patience=patience, finished=stamp(), **info)
    save(dest, rec)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--current", type=Path, required=True, help="F1 reproduction: reproduced_full_r2/current_prepared")
    ap.add_argument("--external", type=Path, required=True, help="F1 reproduction: reproduced_full_r2/external_prepared")
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--max-epochs", type=int, default=50)
    ap.add_argument("--patience", type=int, default=10)
    a = ap.parse_args()
    out = a.output.resolve(); out.mkdir(parents=True, exist_ok=True)
    ctx, checks = load_contexts([a.current, a.external])
    keys = sorted(ctx, key=lambda k: (k[1] not in KINASES, k[1], k[0], ROUTES.index(k[2])))
    assert len(keys) == 88 and all(set(ctx[k]) == {"train", "valid", "test"} for k in keys), len(keys)
    env = versions()
    if a.smoke:
        sd = out / "smoke"; sd.mkdir(exist_ok=True)
        key = ("revised", "alk", "source_exact")
        for f in sd.glob("*"):
            if f.is_file():
                f.unlink()
        rec = run(key, ctx[key], 42, 2, a.patience, sd)
        tr = ctx[key]["train"].target
        chk = dict(
            predictions_finite_and_complete=True,
            epochs_run_is_2=rec["epochs_run"] == 2,
            prediction_mean_within_label_range=bool(tr.min() <= pd.read_csv(sd / "revised_alk_source_exact_42.predictions.csv").prediction.mean() <= tr.max()),
            validation_consistency_rel=abs(rec["valid_mse_best_weights"] - rec["valid_mse_from_val_loss"]) / rec["valid_mse_best_weights"],
            batch_norm_off=str(rec["hparams"].get("batch_norm")) == "False",
            partitions_signature_equal=all(c["signature_equal"] for c in checks), partitions_checked=len(checks))
        chk["validation_consistent"] = chk["validation_consistency_rel"] < 1e-3
        required = ["predictions_finite_and_complete", "epochs_run_is_2", "prediction_mean_within_label_range", "validation_consistent", "batch_norm_off"]
        chk["required_checks"] = required  # partition signatures are recorded but not required (Clarification C9)
        chk["passed"] = all(bool(chk[k]) for k in required)
        save(sd / "SMOKE_CHECK.json", dict(note="SMOKE TEST - NOT A RESULT", record=rec, checks=chk, environment=env, checked=stamp()))
        print(json.dumps(chk, indent=1), flush=True)
        raise SystemExit(0 if chk["passed"] else 4)
    rd = out / "runs"; rd.mkdir(exist_ok=True)
    save(out / "DMPNN_INPUTS.json", dict(contexts=len(keys), partition_checks=checks, environment=env, started=stamp()))
    for key in keys:
        for seed in SEEDS:
            t0 = time.time()
            rec = run(key, ctx[key], seed, a.max_epochs, a.patience, rd)
            print("DMPNN", *key, seed, "skill", round(rec["skill"], 4), "epochs", rec["epochs_run"], "best", rec["best_epoch"], round(time.time() - t0, 1), "s", flush=True)
    recs = [json.loads(p.read_text(encoding="utf8")) for p in sorted(rd.glob("*.json"))]
    pd.DataFrame([{k: v for k, v in r.items() if k not in ("history", "hparams")} for r in recs]).to_csv(out / "dmpnn_runs.csv", index=False)
    save(out / "DMPNN_COMPLETE.json", dict(runs=len(recs), expected=len(keys) * len(SEEDS), environment=env, finished=stamp()))
    print("DMPNN COMPLETE", len(recs), flush=True)


if __name__ == "__main__":
    main()
