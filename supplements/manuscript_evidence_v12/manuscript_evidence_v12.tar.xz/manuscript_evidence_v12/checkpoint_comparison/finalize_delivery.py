"""Verify final bindings and package the completed local experiment, without fitting."""
from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, json, zipfile

R = Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()
def save(p, obj): p.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

reg = read(R/'REGISTRATION.json')
for rel, expected in reg['bindings'].items(): assert digest(R/rel) == expected, rel
for path, expected in reg['protected_source_hashes'].items(): assert digest(Path(path)) == expected, path
records = [read(p) for p in sorted((R/'runs').glob('*/record.json'))]
assert len(records) == 12
assert all(q['started_utc'] > reg['registered_utc'] for q in records)
checks = {name: read(R/(name+'.json')) for name in ['MECHANISM_CHECK','FIT_COMPLETE','VERIFICATION','WEIGHT_REPLAY_CHECK','VISUAL_QA']}
assert all(q['status'] == 'PASS' for q in checks.values())
assert checks['WEIGHT_REPLAY_CHECK']['states_reloaded'] == 24
assert checks['VERIFICATION']['prediction_and_validation_rows_checked'] == 43920
assert checks['VERIFICATION']['protected_source_files_unchanged'] == 116
with (R/'TARGETED_PAIR_COMPARISONS.csv').open(encoding='utf-8', newline='') as f: pairs=list(csv.DictReader(f))
for target, old, new in [('pde4d', '+0.082086', '-0.131141'), ('kdr', '+0.140364', '+0.108505')]:
    z={p['arm']:float(p['YE_minus_SE_skill']) for p in pairs if p['target']==target and p['tier']=='exact'}
    assert f"{z['archived']:+.6f}" == old and f"{z['eligible']:+.6f}" == new
    report=(R/'RESULTS_CN.md').read_text(encoding='utf-8')
    assert old in report and new in report
now=datetime.now(timezone.utc).isoformat()
visual=checks['VISUAL_QA']
visual['manual_review']={'status':'PASS','reviewer':'Codex agent','pages_reviewed':[1,2],
    'render_engine':'Poppler pdftoppm, 120 dpi','legend_panel_title_spacing_corrected':True,
    'clipping_or_overlapping_labels_observed':False,'reviewed_utc':now}
save(R/'VISUAL_QA.json',visual)
status={
    'analysis_id':reg['analysis_id'],'stage':'complete','status':'PASS',
    'completed_fits':12,'expected_fits':12,'selected_weight_states':24,
    'new_fits_in_weight_replay':0,'prediction_and_validation_rows_checked':43920,
    'weight_replay_test_rows':checks['WEIGHT_REPLAY_CHECK']['rows'],
    'weight_replay_max_abs_difference':max(q['max_abs_prediction_difference'] for q in checks['WEIGHT_REPLAY_CHECK']['checks']),
    'weight_replay_tolerance':1e-6,'protected_source_files_unchanged':116,
    'registration_bindings_unchanged':True,'registration_sha256':digest(R/'REGISTRATION.json'),
    'fits_completed_epochs_range':[min(q['epochs_completed'] for q in records),max(q['epochs_completed'] for q in records)],
    'eligible_checkpoint_epochs_range':[min(q['arms']['eligible']['best_epoch_completed'] for q in records),max(q['arms']['eligible']['best_epoch_completed'] for q in records)],
    'fit_elapsed_seconds_sum':sum(q['elapsed_seconds'] for q in records),
    'primary_panel_unchanged':checks['VERIFICATION']['primary_panel_unchanged'],
    'targeted_exact_pairs':[p for p in checks['VERIFICATION']['targeted_pairs'] if p['tier']=='exact'],
    'intent':'post hoc descriptive sensitivity; checkpoint eligibility and early-stopping start jointly changed',
    'manuscripts_modified':False,'author_review_of_new_results':'pending',
    'manuscript_wording_prepared':True,'public_release_performed':False,
    'new_packages_installed':False,'followup_protocol_B_132_repeat_fits_performed':False,
    'verification_dtype_note':'CSV predictions restored to original float32 before metric/replay comparison; tolerance unchanged; failed and passing logs retained',
    'checks':{name:q['status'] for name,q in checks.items()},'finished_utc':now
}
save(R/'RUN_STATUS.json', status)
files=[p for p in sorted(R.rglob('*')) if p.is_file() and p.name not in {'SHA256SUMS.txt','PACKAGE_STATUS.json'} and p.suffix.lower()!='.zip' and '__pycache__' not in p.parts]
(R/'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.relative_to(R).as_posix()}\n' for p in files),encoding='utf-8')
archive=R/'CHECKPOINT_COMPARISON_DELIVERY.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[R/'SHA256SUMS.txt']: z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.infolist())==len(files)+1
    for line in z.read('SHA256SUMS.txt').decode('utf-8').splitlines():
        expected, rel=line.split('  ',1)
        assert hashlib.sha256(z.read(rel)).hexdigest()==expected,rel
package={'status':'PASS','file':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),
    'entries':len(files)+1,'all_archive_file_hashes_verified':True,'created_utc':datetime.now(timezone.utc).isoformat()}
save(R/'PACKAGE_STATUS.json',package)
print(json.dumps({'status':status['status'],'package':package,'fits':12,'protected_unchanged':116},ensure_ascii=False))
