# Checkpoint comparison delivery

Start with RESULTS_CN.md, CHECKPOINT_COMPARISON.pdf and MANUSCRIPT_INSERTION_EN.md. Full-precision route and pair summaries are in ROUTE_CHANGES.csv and TARGETED_PAIR_COMPARISONS.csv. Each run contains its history, validation/test predictions, selection seal and both saved weight states.

## Local checks

Use the existing experiment environment; no installation was performed:

```powershell
& 'E:\paper\kinase_followup_execution\.venv-dmpnn\python.exe' 'E:\paper\visual_audit\checkpoint_comparison_20261006_v1\check_and_summarize.py'
& 'E:\paper\kinase_followup_execution\.venv-dmpnn\python.exe' 'E:\paper\visual_audit\checkpoint_comparison_20261006_v1\replay_weights.py'
```

The first command checks original protected-source hashes in this workspace as well as copied inputs and results. The second command reloads all 24 weight states and regenerates test predictions on the GPU without fitting. Predictions were originally float32; the verifier restores that dtype before comparing them. The replay threshold is 1e-6.

The frozen training driver is run_checkpoint.py. Its `run` phase validates registration bindings and resumes completed runs; existing completed runs are reused. Do not rerun `prepare` on this registered delivery: it would attempt to recreate registration from the original workspace. A fresh repetition should use a separate directory and a new registration. The copied inputs and weights are included; the Python environment and original 116 protected files are not duplicated in this delivery.

## Figure regeneration

```powershell
& 'E:\paper\kinase_followup_execution\.venv-win\Scripts\python.exe' 'E:\paper\visual_audit\checkpoint_comparison_20261006_v1\draw_comparison.py'
```

draw_comparison.py uses an already available local Matplotlib dependency directory and the installed Times New Roman font. PNG/SVG outputs are in figures/. The two-page PDF is CHECKPOINT_COMPARISON.pdf. Both PDF pages were rendered with Poppler and inspected.

## Records

- PROTOCOL_CN.md and REGISTRATION.json: prespecified execution details for this post hoc analysis, stored before the new fits.
- FIT_COMPLETE.json: fit completion record.
- VERIFICATION.json and SOURCE_PRESERVATION.json: independent numeric/history and source-preservation checks.
- WEIGHT_REPLAY_CHECK.json: reload/inference checks; no new fits.
- VISUAL_QA.json: drawing and manual page review.
- RUN_STATUS.json: final status and interpretation scope.
- SHA256SUMS.txt: delivery file hashes, excluding itself and the ZIP.

This delivery changes no existing manuscript, input or primary result. Proposed English text awaits author adoption. No public release was performed.
