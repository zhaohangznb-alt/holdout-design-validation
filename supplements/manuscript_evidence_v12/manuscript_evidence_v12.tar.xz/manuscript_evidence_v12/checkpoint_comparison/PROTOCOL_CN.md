# 第五轮起 checkpoint 资格对照：固定执行协议

分析 ID：CP-E5-20261006。作者在本对话中批准“开展 checkpoint 对照”。本协议根据 V6 的 `FUTURE_COMPUTE_PROTOCOLS_CN.md` A 项落实；原结果与反例已知，属于事后描述性敏感性。

## 范围与预算

固定四个情境，各种子 42/53/67，共 **12 次新拟合**：

- PDE4D Broad：source_exact、source_scaffold。
- KDR Operational：temporal_exact、temporal_scaffold。

不执行 B 项的 132 次同驱动全队列重复。原 V5/V6 主结果不替换，不删除反例，不修改冻结输入。不安装新包，不公开发布。

## 原驱动与唯一主动干预

复用 P3-A 的同一冻结输入、float_precision=round_trip、Chemprop 2.2.4 默认 MPNN、目标训练标准化、Adam/NoamLike 调度、batch 64、原种子与 GPU 设置。最大 50 epoch、patience=10、min_delta=0；validation MSE 为选择依据。默认 warmup=2 epoch，最大学习率等保持实际模型默认值，由环境探针记录。

最早合格权重为第 **5 个完成训练的 epoch**（zero-based epoch>=4）。该轮以前不更新合格最佳权重，也不消耗合格规则的早停 patience；第 5 轮初始化合格验证基准，以后按原 Lightning EarlyStopping 逻辑计数。只设 min_epochs=5 不等同于此规则。

## 同轨迹原规则参照

每次拟合在同一轨迹上额外记录一个“影子原规则”参照：直接使用原 Lightning EarlyStopping 条件，记下原规则本应停止的位置，但恢复 trainer.should_stop，让合格规则决定实际训练终点。参照最佳权重只能来自该原规则停止前的轨迹；原停止后不再更新。参照与合格规则的 checkpoint 均在测试评分前冻结。

这使一次拟合同时给出原规则前缀与第五轮资格结果，不增加拟合次数。原驱动的构图、训练加载和优化设置保持；额外回调仅观察验证损失、保存权重和控制早停。保存模型状态不是额外优化步骤。原驱动已构建测试 dataset，但其标签/误差不参与训练或权重选择；本轮同样不以测试分数调整规则。

报告三种来源，不能混称：归档 P3-A；本次同轨迹原规则前缀；本次第五轮资格结果。归档与本次参照的差异单独列出，不归为纯 checkpoint 效应或通用随机噪声。模型随机性/浮点执行设置原样，不开启额外确定性开关。

## 固定汇总

逐种子、逐情境报告：训练/验证/测试行数、训练均值、完整验证曲线与学习率、完成轮数、所选权重轮次、validation MSE、test MSE、baseline MSE、绝对 skill、权重/预测哈希。

主要解释两对 exact YE−SE：PDE4D Broad 复用归档 YE；KDR Operational 复用归档 SE。变动一侧用新三种子 skill 中位数。并列归档、同轨迹参照和第五轮资格三种对比，明确未重训另一侧。Scaffold 对照及训练/验证曲线也全部报告。只对这两对作描述，不把它们直接解释为模型“训练失败”，不新增 bootstrap、区间或显著性检验。

## 核验

执行前保存协议、代码、环境、所有新训练输入及归档参照文件哈希。注册记录生成后才允许新拟合。每个运行完成即时保存，可按原绑定恢复。

用固定的合成验证历史检验：前四轮不能入选；patience 从合格后计数；原规则前缀在其本应停止的位置封闭。再对实际运行独立重算最佳轮次、早停终点、预测指标、种子汇总；检查各行 UID/标签与冻结输入一致，以及原输入和稿件哈希保持。

软件流程参考：Scientific Writing（本地 skill）；Kassis, T.; Agarwal, V.; He, Y.; Patel, D.; Brueckner, A. M. Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents. 2026. https://doi.org/10.48550/arXiv.2609.00065 （2026-10-06 核对 arXiv 当前记录）。该工具出处记在本实验报告，不加入论文参考文献。
