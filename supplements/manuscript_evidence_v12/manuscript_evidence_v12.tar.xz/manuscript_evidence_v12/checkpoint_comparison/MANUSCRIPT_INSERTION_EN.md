# Current V8 checkpoint wording

This replaces the earlier proposed insertion. The completed experiment is unchanged; this revision adds interpretation verified from saved records.

## Main text

A post hoc checkpoint-eligibility sensitivity examined two of the five non-negative primary contrasts (Table S33; Figures S28--S29). It applied the altered checkpoint and stopping rules only to selected routes within each pair; the primary 22-pair result is retained.

## Supporting Information

\section*{Table S33 Targeted checkpoint-eligibility sensitivity}
This post hoc analysis was recorded as CP-E5-20261006 before its new fits, after the original results and counterexamples were known. Four contexts were refitted with the original three seeds (42, 53 and 67): PDE4D Broad SE/SS and KDR Operational YE/YS, giving 12 new fits. Frozen input partitions, training-label standardisation, Chemprop defaults, optimiser and the two-epoch learning-rate warmup were retained. The maximum duration was 50 epochs, with patience 10 and min\_delta 0. Checkpoints became eligible after the fifth completed epoch; earlier epochs could not supply eligible weights or consume this patience budget. Early-stopping monitoring was initialised at that epoch. A parallel observer saved an original-rule checkpoint from the same trajectory and froze its selection when that rule would have stopped training. Both selected states were hashed before test scoring, yielding 24 weight states from 12 fitted trajectories. Fits completed 16--32 epochs, with eligible checkpoints selected at epochs 6--22. The change therefore combines checkpoint eligibility and the start of early-stopping monitoring.

The two examined pairs were among the five non-negative primary contrasts and were selected after results were known because all three seeds in an exact route had selected the first-epoch checkpoint. The rules were applied asymmetrically: archived PDE4D year routes and KDR source routes were retained. Both retained PDE4D year routes include a first-epoch checkpoint for seed 42. In 11 of the 12 refits, eligible weights had higher monitored validation MSE than the original-rule prefix weights; the remaining selection coincided. The original-rule choices met their validation-loss selection criterion; epoch eligibility imposes an additional constraint. Eligible PDE4D Broad SE seed skills were 0.215, 0.043 and 0.214 for seeds 42, 53 and 67, respectively.

\begingroup\small\setlength{\LTpre}{3pt}\setlength{\LTpost}{3pt}
\renewcommand{\thetable}{S33}
\begin{longtable}{llrrr}
\caption{Absolute route skill under archived, same-trajectory original-rule and epoch-5-eligible selection. Each entry is the three-seed median.}\label{tab:S33}\\
\toprule Target/cohort & Route & Archived & Original-rule prefix & Epoch-5 eligible \\
\midrule\endfirsthead
\toprule Target/cohort & Route & Archived & Original-rule prefix & Epoch-5 eligible \\
\midrule\endhead
PDE4D Broad & SE & +0.000404 & +0.000404 & +0.213631 \\
PDE4D Broad & SS & +0.001664 & +0.001664 & +0.175032 \\
KDR Operational & YE & +0.035419 & +0.035437 & +0.003560 \\
KDR Operational & YS & +0.026166 & +0.026100 & −0.022669 \\
\bottomrule\end{longtable}
\endgroup

The PDE4D Broad exact route contrast changed from +0.082 to −0.131, and its scaffold contrast from +0.122 to −0.051, with the archived year-route results held fixed. KDR Operational retained positive exact and scaffold contrasts, changing from +0.140 to +0.109 and from +0.205 to +0.156, with the archived source-route results held fixed. Each contrast is the difference of two route medians. The largest absolute difference between archived and same-trajectory-reference route medians was 0.000066. This sensitivity concerns these two target--cohort pairs; the primary 22-pair estimate remains −0.186 (17 negative), with no new inferential interval. Full-precision values, all seed estimates and frozen prediction records are supplied in \path{checkpoint_comparison/}. Independent checks covered 43,920 test/validation prediction rows; reloading the 24 saved states checked 22,482 test predictions within a $10^{-6}$ tolerance, with a maximum difference of $9.54\times10^{-7}$.



The corresponding captions are in the final SI, Figures S28 and S29.
