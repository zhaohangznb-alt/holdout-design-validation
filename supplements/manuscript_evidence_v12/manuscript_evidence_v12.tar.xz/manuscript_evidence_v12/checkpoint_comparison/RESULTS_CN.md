# D-MPNN checkpoint 资格对照结果

分析 ID：CP-E5-20261006。执行日期：2026-10-06。状态：此前 12 次拟合完成；结果已在 V7 合入，V8 补全解释与索引。V8 未新增拟合或重新加载权重。

**PDE4D Broad 的年份减来源 skill 由 +0.082 变为 -0.131；KDR Operational 由 +0.140 降为 +0.109，仍为方向反例。** 两者对第五轮起允许选择权重并开始早停计数的规则反应不同。

## 1. 实际实施的比较

四个情境各使用种子 42、53、67，共 12 次拟合：PDE4D Broad 的 source-exact/source-scaffold，KDR Operational 的 year-exact/year-scaffold。冻结训练、验证、测试输入，模型默认设置、优化器与种子保持。最大 50 轮，patience=10，学习率 warmup=2 轮。

新规则从第 5 个完成的训练轮次开始允许入选 checkpoint，并从该轮初始化早停基准。前四轮不参与合格最佳权重选择，也不消耗合格规则的 patience。完整拟合完成 16-32 轮，合格权重选中第 6-22 轮。

每次拟合另保存同轨迹的“原规则前缀”权重：观察原规则本应停止的轮次，之后冻结该参照的最佳权重。它没有另行训练，因此本轮共有 12 条拟合轨迹、24 组保存权重，而不是 24 次独立拟合。

注册时间早于本轮训练开始；测试评分在两组验证选择的权重封存之后才进行。原反例与结果在制定规则之前已知，本分析属于事后定向敏感性。证据：PROTOCOL_CN.md、REGISTRATION.json、各运行的 SELECTION_SEAL.json 与 record.json。

## 2. 两个 exact 配对

表中各路线 skill 先取三种子中位数，再计算 year-exact 减 source-exact。PDE4D 的 year-exact、KDR 的 source-exact 继续使用原归档结果。

| 靶点/队列 | 归档 YE-SE | 本次原规则前缀 YE-SE | 第五轮资格 YE-SE | 变化 |
|---|---:|---:|---:|---|
| PDE4D Broad | +0.082086 | +0.082086 | -0.131141 | 方向反转 |
| KDR Operational | +0.140364 | +0.140382 | +0.108505 | 仍为正值 |

证据：TARGETED_PAIR_COMPARISONS.csv；完整精度保留在 CSV/JSON 中。

## 3. 四个受影响路线的绝对 skill

| 靶点/队列/路线 | 归档 | 本次原规则前缀 | 第五轮资格 |
|---|---:|---:|---:|
| PDE4D Broad / source-exact | +0.000404 | +0.000404 | +0.213631 |
| PDE4D Broad / source-scaffold | +0.001664 | +0.001664 | +0.175032 |
| KDR Operational / year-exact | +0.035419 | +0.035437 | +0.003560 |
| KDR Operational / year-scaffold | +0.026166 | +0.026100 | -0.022669 |

PDE4D 的 scaffold 配对 YS-SS 从 +0.122238 变为 -0.051129；KDR 对应 scaffold 配对从 +0.205147 变为 +0.156312。全部四个情境及三个种子均保留，未按测试表现选择报告结果。

归档与本次原规则前缀的路线中位 skill 最大差异为 0.00006633。逐种子差异另列在 RUN_COMPARISONS.csv；这项定向对照不能用于估计全队列重新执行的随机性。

## 4. 结果如何用于论文

原归档中相关 12 次运行都完成了 11 轮训练，但最优验证权重保留在第 1 轮。“保存第一轮”与“只训练一轮”不同。

本轮显示 PDE4D 的反例对所考察的训练/选择规则敏感；KDR 仍保留反例。干预同时改变了 checkpoint 资格和早停起点，不能把变化全部归结为“只换权重、不变训练长度”。这是两对靶点/队列的描述性分析，没有新增推断区间，也没有重做整面板。

原 22 对主分析的中位 YE-SE=-0.186、17/22 为负保持原样。V8 正文只保留范围明确的指引，具体对照位于 Table S33 和 Figures S28–S29。历史 V5/V6/V7 和原始计算档案均保留。

V8 独立复核了 12 份记录、选择封存和验证历史：11 次合格权重的标准化验证 MSE 高于原规则前缀权重；其余一次为 KDR Operational YS、seed 42，两规则选中同一轮次和验证损失。原规则选择符合当时的验证损失准则，新规则增加了轮次限制。

资格规则只施加在每个配对的选中一侧；PDE4D 未改变的 YE 和 YS 两路线中，seed 42 也都选中首轮权重。复核的两对是主分析五个非负对照中的两对，按已知结果和 checkpoint 特征选取。PDE4D Broad SE 的合格结果分别为 seed 42：0.215，53：0.043，67：0.214。这些局限随数值一同写入 SI。

## 5. 核验与图件

- 12 条验证历史独立重算：最佳轮次、原规则停止点、合格规则停止点全部一致。
- 43,920 行测试与验证预测：UID、标签、输入哈希、MSE、baseline MSE 与 skill 核验通过。
- 此前 24 组权重重新加载，22,482 行测试预测回放通过；行数为 24 个逐项回放记录的合计。最大差值 9.5367431640625e-7，预设容差 1e-6。
- 116 个受保护源文件哈希未变；注册绑定未变。
- 两页对照 PDF 已渲染并逐页检查；Times New Roman、蓝/绿/橙红配色，另提供 SVG 和 PNG。

预测由 float32 数组写入 CSV；核验先恢复 float32 再计算 float64 的误差。这修正了首次核验时把短十进制序列化误当作完整 float64 数值的问题。原始失败日志和成功日志均保留，拟合结果未改，回放阈值未放宽。

证据：VERIFICATION.json、SOURCE_PRESERVATION.json、WEIGHT_REPLAY_CHECK.json、VISUAL_QA.json。PDF 第一页显示验证轨迹与权重轮次，第二页显示各种子绝对 skill 及两个 exact 配对。

## 6. 软件与写作工具

Windows；Python 3.11.16；Chemprop 2.2.4；PyTorch 2.6.0+cu124；Lightning 2.6.6；RDKit 2026.03.6；NVIDIA RTX 4070 Laptop GPU。实际环境与模型参数见 ENVIRONMENT.json；本轮未安装新包。

Scientific Writing skill 用于证据记录、科学范围和英文建议整理。工具出处：Kassis, T.; Agarwal, V.; He, Y.; Patel, D.; Brueckner, A. M. Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents. 2026. https://doi.org/10.48550/arXiv.2609.00065 。该出处保留在实验报告的软件部分，未加入论文参考文献。

本报告的证据由本地脚本与 agent 检查；作者尚未审阅本轮结果。英文建议见 MANUSCRIPT_INSERTION_EN.md。
