# Limited-grid D-MPNN sensitivity: actual executed scope

Read PROTOCOL.md and D-TUNE-1_DEFAULT_CONTROL.md before interpreting the results. The protocol was local and exploratory after original study results were known. Candidate selection used validation only; a fixed fresh-default control was registered before new test access. Original and new default executions are separately identified.

SELECTED_CONFIGURATIONS.csv, ROUTE_SUMMARIES.csv and PAIRED_CONTRASTS.csv preserve full-precision summaries. Raw selected-grid and fixed-default test predictions are under evaluation/ and fresh_default_evaluation/. Candidate and additional-seed directories contain epoch histories and Torch state dictionaries. The model states are files created in this experiment; the driver loads them with weights_only=True. Input CSVs are hash-bound to the original F1 partitions. Original external source paths in manifests identify run provenance, while executed input paths are relative to this tuning folder.

ENVIRONMENT_FREEZE.txt records the installed environment verbatim. Its packaging file:// entry comes from the original Conda build; requirements-pinned.txt replaces that entry with the installed version, but is a record rather than an automatically tested installer. CUDA-compatible PyTorch wheels and driver access are required for the GPU workflow. No package installation was performed here.

For an isolated replay, run scripts/prepare_clean_tuning_replay.py --name a_unique_name from the extracted full archive. It copies the sealed protocol, executed drivers, archived comparison summaries and all inputs into clean_replays/a_unique_name, with no existing fitted outputs, and verifies file hashes. In that prepared folder, use the recorded model environment and run these commands in order:

```text
python scripts/tune_dmpnn.py smoke
python scripts/tune_dmpnn.py search
python scripts/tune_dmpnn.py evaluate
python scripts/run_fresh_default_control.py
python scripts/summarize_tuning.py
```

These commands refit both the grid and its contemporaneous fixed-default control. GPU trajectories can differ, so the original sealed outputs remain a distinct reference. Relocation was exercised with four two-epoch validation smoke fits and all 132 input hashes checked; this is not a second full GPU repeat (RELOCATION_SMOKE_CHECK.json).

The comparison is not nested cross-validation, exhaustive model optimization or a causal estimate. Test metric checks recompute prediction-level errors at the driver's float32 precision, check labels/IDs/baselines and verify selection chronology. No new confidence intervals are presented.
