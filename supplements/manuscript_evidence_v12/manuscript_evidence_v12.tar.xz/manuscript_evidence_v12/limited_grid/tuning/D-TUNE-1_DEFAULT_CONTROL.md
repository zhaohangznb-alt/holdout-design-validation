# D-TUNE-1: contemporaneous fixed-default control

Recorded 2026-10-06T09:06:58.808535+00:00, during validation-only search, before the global selection freeze and before any new test evaluation. The original four-candidate grid and selection rule stay fixed.

At this review, 16 completed C00 seed-42 validation fits had a maximum validation-MSE difference of 0.0672758563 from the archived P3-A seed-42 records. This observation does not identify its cause. A comparison with only the archived default could conflate parameter selection with old/new driver or execution variation.

Add a contemporaneous default C00 control with the same executed driver and seeds42/53/67 for all44 contexts. Seed42 weights already exist in the search. If C00 is selected, reuse the identical selected runs for seeds53/67; otherwise fit C00 with those two seeds. Thus at most88 additional full fits are needed; the actual count depends solely on validation selection, never on test performance. Predict all132 default-control records after the frozen selections. Do not change any grid, data, early-stopping budget, seed or original result.

New results must show both contemporaneous default and selected-grid skills/contrasts; archived default remains a separately identified historical comparator. Report original/fresh default differences rather than asserting they are due to GPU nondeterminism. This is an exploratory implementation/selection sensitivity and does not imply nested validation or an exhaustive tuned-model benchmark.
