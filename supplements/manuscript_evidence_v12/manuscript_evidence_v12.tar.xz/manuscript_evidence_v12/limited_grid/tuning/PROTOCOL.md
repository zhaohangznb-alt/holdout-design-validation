# Limited-grid D-MPNN sensitivity protocol

Registered locally at 2026-10-06T08:52:36.314326+00:00, before any fit in this new analysis. This is an exploratory extension after the original results were known, not a retrospective claim of preregistration. Author authorization: "全权交给你" on 6 October 2026, continuing the authorized modern-model extension. V4 and all original analyses remain intact.

## Question and scope

Does the descriptive source-document versus document-year contrast persist when the same D-MPNN receives an equal, small validation-only search budget? Use all 11 archived targets, both broad/operational cohorts, source_exact and temporal_exact: 44 contexts. No target/cohort/partition, label, endpoint policy, RF setting or baseline is altered. Scaffold routes, other models and new databases are outside this small sensitivity.

## Fixed search

Four candidates: message depth 3/5 crossed with dropout 0/0.1, hidden dimension 300. Dropout is applied to message passing and the one-hidden-layer regression FFN. Other settings match the P3-A Chemprop 2.2.4 default driver: mean aggregation, default featurizer and learning-rate schedule, batch 64, training-only target scaler, no batch normalization, maximum 50 epochs, patience 10 and best validation weights.

Fit all four candidates with seed 42 within every context (176 fits). Select by lowest validation MSE, with an exact tie resolved by C00,C01,C02,C03 order. Freeze every context's selected configuration before opening any test CSV in the experiment driver. Then predict selected seed-42 weights and fit/evaluate the same selected configuration with seeds 53 and 67 (88 additional fits, 132 selected test predictions). No candidate receives test-based selection; a failed candidate stops the batch rather than being silently omitted. Smoke fits are two epochs on one context for all four configurations and are excluded from results.

The validation set serves both early stopping and finite-grid selection. This is not nested cross-validation or exhaustive optimization. A single search seed can make configuration selection noisy. These limitations must accompany any manuscript interpretation. Archived test results were already known at study level; the new code enforces validation-only candidate selection.

## Readouts

Report selected configuration, validation MSE, each seed's test absolute MSE/MAE/RMSE, training-mean errors and skill. Take the three-seed median skill within each route, then YE-SE per target/cohort, the median across all 22 pairs, direction counts and exceptions. Compare with the frozen original default D-MPNN and RF summaries on identical route-specific contexts. Show absolute skill as well as differences. No causal, superiority, full-optimization or confirmatory claim, and no newly inferred interval is planned in this limited extension.

## Integrity and compute

Every copied input is bound to the original F1 split manifest by SHA-256 and row count. Registration stores script/config/protocol hashes. Search modules do not load test inputs. All selections are sealed together; evaluation checks that seal and permits only selected configurations. Resume requires unchanged binding. Results, predictions, histories and state dictionaries remain under this independent directory. Package installation is unnecessary: existing .venv-dmpnn Python 3.11 / Torch 2.6.0+cu124 / Chemprop 2.2.4 / Lightning 2.6.6 and RTX 4070 Laptop are reused.

Original 264 P3-A fits ran in approximately 47 minutes on this machine. This plan has 264 new full fits, with depth-5 candidates potentially slower; 45–100 minutes is a provisional estimate rather than a completion promise. Record actual time and environment. GPU nondeterminism is retained and disclosed. Stop on a failed integrity/finite-value gate; do not revise the grid after seeing results.

## Publication status

Results are new local research outputs. They do not automatically enter V4 or change its disclosure/version/status. Manuscript incorporation requires a separate documented version change. No external service receives unpublished text or these outputs in this execution.
