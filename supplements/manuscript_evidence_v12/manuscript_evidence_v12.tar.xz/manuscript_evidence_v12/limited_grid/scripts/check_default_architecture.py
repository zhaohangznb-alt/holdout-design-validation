from pathlib import Path
import json,sys
import numpy as np
import torch
from lightning import pytorch as pl
from sklearn.preprocessing import StandardScaler
from chemprop import models,nn
sys.path.insert(0,str(Path(__file__).resolve().parent))
from tune_dmpnn import build_model
R=Path(__file__).resolve().parents[1]
scaler=StandardScaler();scaler.mean_=np.array([6.1]);scaler.scale_=np.array([1.2]);scaler.var_=scaler.scale_**2;scaler.n_features_in_=1
pl.seed_everything(42,workers=True)
original=models.MPNN(nn.BondMessagePassing(),nn.MeanAggregation(),nn.RegressionFFN(output_transform=nn.UnscaleTransform.from_standard_scaler(scaler)))
pl.seed_everything(42,workers=True)
current=build_model({'id':'C00','depth':3,'dropout':0.0,'hidden_dim':300},6.1,1.2)
old=original.state_dict();new=current.state_dict()
assert set(old)==set(new)
differences=[key for key in old if not torch.equal(old[key],new[key])]
assert not differences,differences
record={'status':'PASS','same_seed_initial_state_tensors_equal':True,'state_tensor_count':len(old),
 'original_parameter_count':sum(p.numel() for p in original.parameters()),'new_C00_parameter_count':sum(p.numel() for p in current.parameters()),
 'scope':'CPU constructor equivalence only; not a proof of identical GPU training trajectories or a cause for run differences'}
(R/'tuning/DEFAULT_ARCHITECTURE_CHECK.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
