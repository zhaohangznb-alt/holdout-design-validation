"""Prepare a fresh isolated replay without overwriting fits or installing packages."""
from pathlib import Path
import argparse,hashlib,json,shutil
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--name',required=True);a=ap.parse_args()
if not a.name or not all(c.isalnum() or c in '-_' for c in a.name):raise SystemExit('Use a simple unique replay name.')
out=(R/'clean_replays'/a.name).resolve();out.relative_to((R/'clean_replays').resolve())
out.mkdir(parents=True,exist_ok=False)
srcs=[R/'scripts/tune_dmpnn.py',R/'tuning/configs.json',R/'tuning/INPUT_MANIFEST.json',
      R/'tuning/PROTOCOL.md',R/'tuning/PROTOCOL_REGISTRATION.json']
srcs += [R/p for p in ['scripts/run_fresh_default_control.py','scripts/summarize_tuning.py',
          'tuning/DEFAULT_CONTROL_REGISTRATION.json','tuning/D-TUNE-1_DEFAULT_CONTROL.md',
          'tuning/ARCHIVED_DEFAULT_DMPNN.csv','tuning/ARCHIVED_P3A_SUMMARY.json','tuning/ARCHIVED_RF_PAIRS.csv'] if (R/p).is_file()]
srcs += [p for p in (R/'tuning/inputs').rglob('*') if p.is_file()]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in srcs:
    q=out/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert sha(p)==sha(q)
registration=json.loads((out/'tuning/PROTOCOL_REGISTRATION.json').read_text())
for rel,digest in registration['bindings'].items():assert sha(out/rel)==digest
manifest=json.loads((out/'tuning/INPUT_MANIFEST.json').read_text())
for ctx in manifest['contexts']:
    for part in ctx['parts'].values():assert sha(out/'tuning'/part['path'])==part['sha256']
(out/'REPLAY_PREPARED.json').write_text(json.dumps({'fresh_directory':str(out),'source_registration_preserved':True,
 'source_absolute_paths_in_manifest_are_historical':True,'copied_input_hashes_checked':132,'new_training_started':False,
 'commands':['python scripts/tune_dmpnn.py smoke','python scripts/tune_dmpnn.py search','python scripts/tune_dmpnn.py evaluate','python scripts/run_fresh_default_control.py'],
 'requirements':'use the archived Chemprop/Torch environment; packages not auto-installed'},indent=2),encoding='utf-8')
print(str(out))
