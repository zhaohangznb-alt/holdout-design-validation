"""Fixed C00 contemporaneous default control, added before new test results were opened."""
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import tune_dmpnn as core
T=core.T
def main():
    binding=core.check_binding();cfg=core.read(T/'configs.json');default=cfg['configs'][0]
    assert default=={'id':'C00','depth':3,'dropout':0.0,'hidden_dim':300}
    assert core.read(T/'RUN_STATUS.json')['stage']=='complete_new_sensitivity'
    deviation=core.read(T/'DEFAULT_CONTROL_REGISTRATION.json')
    assert core.sha(Path(__file__))==deviation['control_script_sha256']
    seal=core.read(T/'SELECTION_FROZEN.json');selected={s['context']:s for s in seal['selections']}
    contexts=core.read(T/'INPUT_MANIFEST.json')['contexts'];rows=[];new_fit_count=0
    for c in contexts:
        stem=core.name(c)
        for seed in [42,53,67]:
            if seed==42:
                rp=T/'search'/stem/'C00'/'record.json'
            elif selected[c['key']]['config']['id']=='C00':
                rp=T/'additional_seed_fits'/stem/str(seed)/'record.json'
            else:
                folder=T/'fresh_default_seed_fits'/stem/str(seed)
                core.train_validate(c,default,seed,cfg['max_epochs'],cfg['patience'],folder,binding)
                rp=folder/'record.json';new_fit_count+=1
            rec=core.read(rp);assert rec['config']==default and rec['seed']==seed
            rec['weights_relative']=(rp.parent/'weights.pt').relative_to(T).as_posix()
            m=core.predict_test(c,rec,T/'fresh_default_evaluation'/stem/str(seed),binding)
            rows.append(m)
            core.save(T/'DEFAULT_CONTROL_STATUS.json',{'stage':'running','predictions_complete':len(rows),'expected':132,
                       'additional_control_fits':new_fit_count,'updated_utc':core.stamp()})
            print('DEFAULT_CONTROL',len(rows),'/132',c['key'],seed,round(m['skill'],6),flush=True)
    core.pd.DataFrame(rows).to_csv(T/'FRESH_DEFAULT_TEST_RUNS.csv',index=False)
    core.save(T/'DEFAULT_CONTROL_STATUS.json',{'stage':'complete','test_records':132,'additional_control_fits':new_fit_count,
                   'selected_default_reused_without_refitting':True,'finished_utc':core.stamp()})
if __name__=='__main__':main()
