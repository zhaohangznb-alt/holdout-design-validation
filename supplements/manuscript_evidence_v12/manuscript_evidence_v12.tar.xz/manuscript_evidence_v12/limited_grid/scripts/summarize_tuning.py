"""Recompute selected metrics from prediction rows and summarize the registered sensitivity."""
from pathlib import Path
from collections import Counter
import ast, csv, hashlib, json, math
from datetime import datetime, timezone
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parents[1];T=R/'tuning'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
def save(n,obj):(T/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def near(a,b):assert math.isclose(float(a),float(b),rel_tol=2e-10,abs_tol=2e-10),(a,b)
manifest=read(T/'INPUT_MANIFEST.json');contexts={c['key']:c for c in manifest['contexts']}
reg=read(T/'PROTOCOL_REGISTRATION.json');binding=sha(T/'PROTOCOL_REGISTRATION.json')
for name,digest in reg['bindings'].items():assert sha(R/name)==digest
originals_opened=0
for context in manifest['contexts']:
    for part in context['parts'].values():assert sha(T/part['path'])==part['sha256']
for record in manifest['files']:
    if Path(record['source']).is_file():
        assert sha(record['source'])==record['sha256'];originals_opened+=1
assert read(T/'RUN_STATUS.json')['stage']=='complete_new_sensitivity'
sealed=read(T/'SELECTION_FROZEN.json');assert len(sealed['selections'])==44 and sealed['test_accessed'] is False
assert sealed['registration_sha256']==binding
assert sha(T/'VALIDATION_SEARCH.csv')==sealed['search_table_sha256']

# Static access check of the actual executed training function: only train/valid frame calls.
tree=ast.parse((R/'scripts/tune_dmpnn.py').read_text())
fn=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='train_validate')
frame_args=[ast.unparse(call.args[0]) for call in ast.walk(fn) if isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id=='frame']
assert len(frame_args)==2 and set(frame_args)=={"context['parts']['train']","context['parts']['valid']"}
assert not any(isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id=='predict_test' for call in ast.walk(fn))
metrics=[];selection_rows=[];newfits=[]
for select in sealed['selections']:
    key=select['context'];ctx=contexts[key];stem=key.replace('|','_')
    candidates=[read(T/'search'/stem/q/'record.json') for q in ['C00','C01','C02','C03']]
    assert all(row['test_accessed'] is False for row in candidates)
    winner=min(candidates,key=lambda row:(row['valid_mse'],row['config']['id']))
    assert winner['config']==select['config']
    near(winner['valid_mse'],select['seed42_valid_mse'])
    for rec in candidates:
        assert rec['registration_sha256']==binding and rec['seed']==42
        assert rec['finished_utc']<=sealed['frozen_utc']
        near(rec['valid_mse_from_loss'],min(loss for _,loss in rec['validation_history'])*rec['scaler_scale']**2)
        assert abs(rec['valid_mse']-rec['valid_mse_from_loss'])<=max(1e-6,1e-3*rec['valid_mse'])
        assert sha(T/'search'/stem/rec['config']['id']/'weights.pt')==rec['weights_sha256']
        newfits.append(rec)
    default=next(q for q in candidates if q['config']['id']=='C00')
    selection_rows.append({'scenario':ctx['scenario'],'target':ctx['target'],'route':ctx['route'],'selected_config':winner['config']['id'],
       'depth':winner['config']['depth'],'dropout':winner['config']['dropout'],'default_valid_mse':default['valid_mse'],
       'selected_valid_mse':winner['valid_mse'],'validation_mse_change':winner['valid_mse']-default['valid_mse']})
    tf=pd.read_csv(T/ctx['parts']['test']['path'],float_precision='round_trip')
    tr=pd.read_csv(T/ctx['parts']['train']['path'],float_precision='round_trip')
    for seed in [42,53,67]:
        folder=T/'evaluation'/stem/str(seed);m=read(folder/'test_metrics.json')
        assert m['context']==key and m['seed']==seed and m['scenario']==ctx['scenario'] and m['route']==ctx['route']
        assert m['registration_sha256']==binding and m['config_id']==winner['config']['id']
        assert m['finished_utc']>=sealed['frozen_utc']
        p=pd.read_csv(folder/'test_predictions.csv',float_precision='round_trip')
        assert sha(folder/'test_predictions.csv')==m['prediction_sha256']
        assert p.record_uid.tolist()==tf.record_uid.tolist()
        assert np.array_equal(p.target.to_numpy(float),tf.target.to_numpy(float))
        # The executed driver writes float32 predictions; CSV decimals reconstruct that dtype.
        # Recreate it explicitly rather than treating their short display strings as full float64 predictions.
        y=p.target.to_numpy(float);pred=p.prediction.to_numpy(dtype=np.float32);mean=float(tr.target.mean())
        assert np.isfinite(pred).all();mse=float(np.mean((y-pred)**2));base=float(np.mean((y-mean)**2))
        for field,computed in [('mse_model',mse),('mse_mean',base),('rmse_model',np.sqrt(mse)),('mae_model',np.mean(abs(y-pred))),('skill',1-mse/base),('training_mean',mean)]:near(m[field],computed)
        metrics.append(m)
        if seed!=42:
            rec=read(T/'additional_seed_fits'/stem/str(seed)/'record.json')
            assert rec['config']==winner['config'] and rec['seed']==seed
            assert sha(T/'additional_seed_fits'/stem/str(seed)/'weights.pt')==rec['weights_sha256']
            newfits.append(rec)
assert len(metrics)==132 and len(newfits)==264
assert read(T/'DEFAULT_CONTROL_STATUS.json')['stage']=='complete'
deviation=read(T/'DEFAULT_CONTROL_REGISTRATION.json')
assert deviation['registered_utc']<sealed['frozen_utc']
assert sha(R/'scripts/run_fresh_default_control.py')==deviation['control_script_sha256']
default_metrics=[];extra_control_records=[]
for key,ctx in contexts.items():
    stem=key.replace('|','_')
    tf=pd.read_csv(T/ctx['parts']['test']['path'],float_precision='round_trip')
    tr=pd.read_csv(T/ctx['parts']['train']['path'],float_precision='round_trip')
    for seed in [42,53,67]:
        folder=T/'fresh_default_evaluation'/stem/str(seed);m=read(folder/'test_metrics.json')
        assert m['context']==key and m['seed']==seed and m['scenario']==ctx['scenario'] and m['route']==ctx['route']
        assert m['finished_utc']>=sealed['frozen_utc']
        p=pd.read_csv(folder/'test_predictions.csv',float_precision='round_trip')
        assert m['config_id']=='C00' and m['registration_sha256']==binding
        assert sha(folder/'test_predictions.csv')==m['prediction_sha256']
        assert p.record_uid.tolist()==tf.record_uid.tolist()
        assert np.array_equal(p.target.to_numpy(float),tf.target.to_numpy(float))
        y=p.target.to_numpy(float);pred=p.prediction.to_numpy(dtype=np.float32);mean=float(tr.target.mean())
        mse=float(np.mean((y-pred)**2));base=float(np.mean((y-mean)**2))
        for field,computed in [('mse_model',mse),('mse_mean',base),('rmse_model',np.sqrt(mse)),('mae_model',np.mean(abs(y-pred))),('skill',1-mse/base)]:near(m[field],computed)
        default_metrics.append(m)
        recpath=T/'fresh_default_seed_fits'/stem/str(seed)/'record.json'
        if recpath.exists():
            rec=read(recpath);assert rec['seed']==seed and rec['config']['id']=='C00'
            assert sha(recpath.parent/'weights.pt')==rec['weights_sha256']
            extra_control_records.append(rec)
assert len(default_metrics)==132
# The registration helper hashed text.encode() before Windows write_text()
# translated LF to CRLF. Preserve the original record and validate exactly the
# representation it registered; also report the actual on-disk byte hash.
deviation_lf_hash=hashlib.sha256((T/'D-TUNE-1_DEFAULT_CONTROL.md').read_text(encoding='utf-8').encode('utf-8')).hexdigest()
assert deviation_lf_hash==deviation['deviation_sha256']
assert len(extra_control_records)<=88
assert len(extra_control_records)==read(T/'DEFAULT_CONTROL_STATUS.json')['additional_control_fits']
assert len(extra_control_records)==2*sum(row['selected_config']!='C00' for row in selection_rows)
pd.DataFrame(selection_rows).to_csv(T/'SELECTED_CONFIGURATIONS.csv',index=False)
actual=pd.DataFrame(metrics)
saved=pd.read_csv(T/'SELECTED_TEST_RUNS.csv',float_precision='round_trip')
for row in actual.itertuples():
    q=saved[(saved.context==row.context)&(saved.seed==row.seed)];assert len(q)==1;near(q.iloc[0].skill,row.skill)

assert sha(T/'ARCHIVED_DEFAULT_DMPNN.csv')==reg['archived_baseline_sha256']
rfsource=Path('E:/paper/visual_audit/manuscript_review_response_20261006_v4/data/model_pairs.csv')
if rfsource.exists():assert sha(rfsource)==sha(T/'ARCHIVED_RF_PAIRS.csv')
rf=pd.read_csv(T/'ARCHIVED_RF_PAIRS.csv',float_precision='round_trip')
assert len(rf)==22
rfsummary=read(T/'ARCHIVED_P3A_SUMMARY.json')['by_model']['rf']['ye_minus_se']
near(rf.ye_minus_se_rf.median(),rfsummary['median'])
assert int(sum(rf.ye_minus_se_rf<0))==rfsummary['negative_combinations']
archived=pd.read_csv(T/'ARCHIVED_DEFAULT_DMPNN.csv',float_precision='round_trip')
archived=archived[archived.route.isin(['source_exact','temporal_exact'])]
assert len(archived)==132
rows=[]
for source,df in [('archived_default',archived),('fresh_default',pd.DataFrame(default_metrics)),('limited_grid',actual)]:
    med=df.groupby(['scenario','target','route'])[['skill','mse_model','mse_mean','mae_model']].median().reset_index()
    for r in med.itertuples():
        rows.append({'model_specification':source,'scenario':r.scenario,'target':r.target,'route':r.route,'skill':r.skill,
                     'mse_model':r.mse_model,'mse_mean':r.mse_mean,'mae_model':r.mae_model})
route=pd.DataFrame(rows);route.to_csv(T/'ROUTE_SUMMARIES.csv',index=False)
pairs=[]
for (spec,scen,target),group in route.groupby(['model_specification','scenario','target']):
    q=group.set_index('route');pairs.append({'model_specification':spec,'scenario':scen,'target':target,
      'source_skill':q.loc['source_exact','skill'],'year_skill':q.loc['temporal_exact','skill'],
      'ye_minus_se':q.loc['temporal_exact','skill']-q.loc['source_exact','skill'],
      'source_mse':q.loc['source_exact','mse_model'],'year_mse':q.loc['temporal_exact','mse_model']})
pair=pd.DataFrame(pairs);pair.to_csv(T/'PAIRED_CONTRASTS.csv',index=False)
summary={}
for spec in ['archived_default','fresh_default','limited_grid']:
    d=pair[pair.model_specification==spec];r=route[route.model_specification==spec]
    summary[spec]={'target_cohort_pairs':len(d),'ye_minus_se_median':float(d.ye_minus_se.median()),
                   'negative_pairs':int(sum(d.ye_minus_se<0)), 'nonnegative_pairs':int(sum(d.ye_minus_se>=0)),
                   'source_skill_median':float(r[r.route=='source_exact'].skill.median()),
                   'year_skill_median':float(r[r.route=='temporal_exact'].skill.median()),
                   'by_cohort':{c:{'pairs':len(x),'median':float(x.ye_minus_se.median()),'negative_pairs':int(sum(x.ye_minus_se<0))} for c,x in d.groupby('scenario')}}
old=read(T/'ARCHIVED_P3A_SUMMARY.json')['by_model']['dmpnn']
near(summary['archived_default']['ye_minus_se_median'],old['ye_minus_se']['median'])
assert summary['archived_default']['negative_pairs']==old['ye_minus_se']['negative_combinations']
comparison=[]
for (scen,target,route_name),g in route.groupby(['scenario','target','route']):
    q=g.set_index('model_specification');before=q.loc['fresh_default'];after=q.loc['limited_grid']
    comparison.append({'scenario':scen,'target':target,'route':route_name,'default_skill':before.skill,'limited_grid_skill':after.skill,
                       'skill_change':after.skill-before.skill,'default_mse':before.mse_model,'limited_grid_mse':after.mse_model,'mse_change':after.mse_model-before.mse_model})
comparison=pd.DataFrame(comparison).merge(pd.DataFrame(selection_rows)[['scenario','target','route','selected_config']],on=['scenario','target','route'],validate='one_to_one')
comparison.to_csv(T/'DEFAULT_VS_GRID.csv',index=False)
summary['selection_counts']=dict(Counter(row['selected_config'] for row in selection_rows))
changed=comparison[comparison.selected_config!='C00'];same=comparison[comparison.selected_config=='C00']
assert len(changed)+len(same)==44
summary['absolute_skill_comparison']={'nondefault_routes_improved':int(sum(changed.skill_change>0)),'nondefault_routes_worse':int(sum(changed.skill_change<0)),
    'same_default_specification_routes':len(same),'maximum_repeated_C00_route_skill_difference':float(max(abs(same.skill_change))),
    'median_skill_change':float(comparison.skill_change.median()),
    'note':'the seven selected-C00 contexts reuse the same fitted weights; raw repeated-prediction differences are retained but not counted as parameter-selection gains'}
aligned=route[route.model_specification=='fresh_default'].merge(route[route.model_specification=='archived_default'],on=['scenario','target','route'],suffixes=('_fresh','_archived'),validate='one_to_one')
assert len(aligned)==44
summary['archived_vs_fresh_default']={'maximum_route_skill_difference':float(max(abs(aligned.skill_fresh-aligned.skill_archived))),
                                    'note':'driver/execution variation is documented; no unique cause is attributed'}
summary['scope']={'new_model_fits':264+len(extra_control_records),'original_plan_fits':264,'additional_fixed_default_control_fits':len(extra_control_records),
                   'search_seed':42,'evaluation_seeds':[42,53,67],'no_new_interval':True,
                   'exploratory_after_prior_results_known':True,'validation_not_nested':True,'external_publication':False}
save('TUNING_SUMMARY.json',summary)
# Check a meaningful negative control in the independent prediction metric verifier.
try:near(float(actual.iloc[0].skill)+0.001,float(actual.iloc[0].skill))
except AssertionError:negative_control=True
else:raise AssertionError('perturbed skill escaped verifier')
if (R/'V4_LOCK.json').exists():
    assert all(sha(path)==digest for path,digest in read(R/'V4_LOCK.json').items());v4_unchanged=True
else:v4_unchanged=None
save('VERIFICATION.json',{'status':'PASS','prediction_rows_checked':int(sum(m['test_rows'] for m in metrics+default_metrics)),
     'test_metric_records':264,'new_fits_bound_to_registration':264+len(extra_control_records),'selected_configurations_independently_recomputed':44,
     'test_label_and_UID_order_match':True,'predictions_reconstructed_at_recorded_float32_precision':True,'all_inputs_equal_original_manifest_hashes':True,'original_source_files_opened':originals_opened,'search_only_train_valid_frame_calls':frame_args,
     'all_search_finished_before_selection_freeze':True,'all_test_records_after_global_selection_freeze':True,
     'default_control_deviation_registered_before_test_access':True,'archived_default_summary_reproduced':True,'deliberate_metric_perturbation_rejected':negative_control,
     'default_control_deviation_hash_representation':'original helper registered UTF-8 logical LF text; Windows file uses CRLF; text is identical',
     'default_control_deviation_registered_text_sha256':deviation_lf_hash,'default_control_deviation_file_byte_sha256':sha(T/'D-TUNE-1_DEFAULT_CONTROL.md'),
     'V4_unchanged':v4_unchanged,'verification_utc':datetime.now(timezone.utc).isoformat()})
impl='''# Implementation notes

The new driver reuses the Chemprop default training dataloader behavior of P3-A. When the training count modulo 64 equals one, Chemprop drops the last one-row batch even though the model has batch normalization disabled. All four candidates in a context use the same inherited sampler setting; validation and test use explicit unshuffled loaders without dropped rows. This batching behavior is distinct from changing a cohort or partition.

The protocol was locally registered after the published/default results were known. A finite grid selected with one seed and the same validation split used for early stopping is a limited exploratory sensitivity, not nested cross-validation or exhaustive modern-model tuning. The final three-seed test metrics do not provide a new confidence interval. GPU nondeterminism and the lower-level defaults are recorded, not suppressed by post-result changes.

Evaluation begins after the single global selection seal. This refers to new model predictions/metrics: preparation had read archived input CSVs for hash/ID/count checks, and prior study results were known. The fitting/search function itself reads only training and validation data. Independent verification recomputes test errors from every prediction CSV and confirms input IDs/labels, selected configurations, hashes and chronology. It does not claim that all candidate validation predictions were archived row-by-row; validation MSE is recorded alongside the best-loss reconstruction and full epoch histories.
'''
(T/'IMPLEMENTATION_NOTES.md').write_text(impl,encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
