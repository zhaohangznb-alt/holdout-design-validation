from pathlib import Path
import json,sys,importlib.util
if importlib.util.find_spec('matplotlib') is None:
    deps=Path('E:/paper/kinase_followup_execution/algorithm_validation_extension_20261003_v1/plot_dependencies')
    if deps.exists():sys.path.insert(0,str(deps))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D

R=Path(__file__).resolve().parents[1];T=R/'tuning';D=R/'tuning_manuscript_v5/manuscript/figures';D.mkdir(parents=True,exist_ok=True)
font=font_manager.findfont('Times New Roman',fallback_to_default=False)
plt.rcParams.update({'font.family':'Times New Roman','font.size':9,'axes.labelsize':9,'axes.titlesize':10,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,
 'axes.linewidth':.7,'xtick.major.width':.6,'ytick.major.width':.6,'savefig.facecolor':'white'})
pair=pd.read_csv(T/'PAIRED_CONTRASTS.csv',float_precision='round_trip');routes=pd.read_csv(T/'ROUTE_SUMMARIES.csv',float_precision='round_trip')
rf=pd.read_csv(T/'ARCHIVED_RF_PAIRS.csv',float_precision='round_trip')
summary=json.loads((T/'TUNING_SUMMARY.json').read_text())
order=['alk','braf','egfr','erbb2','kdr','met','ache','dpp4','ptgs2','hdac1','pde4d']
colors={'rf':'#0072B2','archived_default':'#9CA9B5','fresh_default':'#4D5965','limited_grid':'#AA4499','SE':'#0072B2','YE':'#D55E00'}
fig,axes=plt.subplots(2,2,figsize=(6.85,6.95),gridspec_kw={'height_ratios':[1.6,1]},layout='constrained')
value=pair[pair.model_specification.isin(['fresh_default','limited_grid'])].ye_minus_se
span=max(value.max()-value.min(),.2);limits=(min(value.min()-.09*span,-.05),max(value.max()+.09*span,.05))
records={}
for ax,cohort,letter in zip(axes[0],['revised','single_protein'],['a','b']):
    q=pair[pair.scenario==cohort].pivot(index='target',columns='model_specification',values='ye_minus_se').loc[order]
    y=np.arange(len(order))[::-1]
    for i,target in enumerate(order):
        ax.plot([q.loc[target,'fresh_default'],q.loc[target,'limited_grid']],[y[i],y[i]],color='#A6ADB5',lw=.8,zorder=1)
    ax.scatter(q.fresh_default,y,s=42,marker='o',facecolors='white',edgecolors=colors['fresh_default'],lw=1,zorder=3,label='Fresh default')
    ax.scatter(q.limited_grid,y,s=26,marker='D',color=colors['limited_grid'],edgecolors='white',lw=.3,zorder=4,label='Validation grid')
    ax.axvline(0,color='#424A52',lw=.7,ls=(0,(4,3)))
    ax.set_yticks(y,[s.upper() for s in order]);ax.tick_params(axis='y',length=0,pad=4)
    ax.set_xlim(limits);ax.set_ylim(-.65,len(order)-.35)
    ax.set_xlabel('Year minus source skill')
    ax.set_title(('Broad' if cohort=='revised' else 'Operational')+' cohort',loc='left',fontweight='bold',pad=24)
    ax.text(-.17,1.05,letter,transform=ax.transAxes,fontweight='bold',fontsize=12)
    if letter=='a':ax.legend(loc='lower left',bbox_to_anchor=(0,1.005),ncols=2,frameon=False,fontsize=8,handletextpad=.3,columnspacing=.9)
    records[cohort]=q.reset_index().to_dict('records')
ax=axes[1,0]
specs=['rf','archived_default','fresh_default','limited_grid'];labels=['RF archived','D-MPNN archived','D-MPNN fresh','D-MPNN grid']
for i,spec in enumerate(specs):
    v=rf.ye_minus_se_rf.to_numpy() if spec=='rf' else pair[pair.model_specification==spec].ye_minus_se.to_numpy()
    # Deterministic display offsets, not resampling or inferred data.
    offsets=np.linspace(-.23,.23,len(v))
    ax.scatter(v,i+offsets,s=12,color=colors[spec],alpha=.85,edgecolors='none',zorder=2)
    ax.scatter([np.median(v)],[i],marker='|',s=170,linewidths=1.8,color='black',zorder=3)
    records['summary_'+spec]={'actual_pairs':v.tolist(),'median':float(np.median(v))}
ax.axvline(0,color='#424A52',lw=.7,ls=(0,(4,3)));ax.set_yticks(range(4),labels);ax.invert_yaxis();ax.tick_params(axis='y',length=0)
ax.set_xlabel('Year minus source skill');ax.set_title('All 22 target-cohort pairs',loc='left',fontweight='bold',pad=24)
ax.legend(handles=[Line2D([],[],marker='o',linestyle='none',color='#66727D',markersize=4,label='Actual pairs'),
                   Line2D([],[],marker='|',linestyle='none',color='black',markersize=8,markeredgewidth=1.6,label='Median')],
          frameon=False,ncols=2,loc='lower left',bbox_to_anchor=(0,1.01),fontsize=8,handletextpad=.3,columnspacing=.7)
ax.text(-.17,1.07,'c',transform=ax.transAxes,fontweight='bold',fontsize=12)
ax=axes[1,1]
for i,spec in enumerate(specs):
    if spec=='rf':se,ye=0.0,0.0
    else:
        se=summary[spec]['source_skill_median'];ye=summary[spec]['year_skill_median']
    if spec=='rf':
        original=json.loads((T/'ARCHIVED_P3A_SUMMARY.json').read_text())['by_model']['rf']['route_median_skill']
        se,ye=original['source_exact'],original['temporal_exact']
    ax.plot([se,ye],[i,i],color='#C4CAD1',lw=.9,zorder=1)
    ax.scatter([se],[i],s=28,color=colors['SE'],marker='o',edgecolor='white',lw=.3,zorder=3,label='Source exact' if i==0 else None)
    ax.scatter([ye],[i],s=28,color=colors['YE'],marker='s',edgecolor='white',lw=.3,zorder=3,label='Year exact' if i==0 else None)
    records['absolute_'+spec]={'source_route_median_skill':se,'year_route_median_skill':ye}
ax.axvline(0,color='#424A52',lw=.7,ls=(0,(4,3)));ax.set_yticks(range(4),labels);ax.invert_yaxis();ax.tick_params(axis='y',length=0)
ax.set_xlabel('Median route-specific skill');ax.set_title('Absolute utility level',loc='left',fontweight='bold',pad=24)
ax.legend(frameon=False,ncols=2,loc='lower left',bbox_to_anchor=(0,1.01),fontsize=8,handletextpad=.3,columnspacing=.6)
ax.text(-.17,1.07,'d',transform=ax.transAxes,fontweight='bold',fontsize=12)
for ax in axes.flat:
    ax.spines['left'].set_color('#87919B');ax.spines['bottom'].set_color('#87919B');ax.tick_params(labelsize=8)
for ext in ['pdf','svg','png']:fig.savefig(D/f'FigureS27.{ext}',dpi=300)
plt.close(fig)
(T/'FIGURE_S27_RECORDS.json').write_text(json.dumps({'font_file':font,'figure_records':records,'no_new_resampling_or_fits':True},indent=2),encoding='utf-8')
print('Figure S27 vector/PNG outputs created from actual archived and newly verified results.')
