from pathlib import Path
import csv, hashlib, json, shutil
from datetime import datetime, timezone

R = Path(__file__).resolve().parents[1]
V4 = Path('E:/paper/visual_audit/manuscript_review_response_20261006_v4')
F1 = Path('E:/paper/kinase_followup_execution/claude_manuscript_polish_20261002_v1/cowork_workspace/round2_claude_20261004/f1/bundle/reproduced_full_r2')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
stamp = lambda: datetime.now(timezone.utc).isoformat()
T = R / 'tuning'
T.mkdir(parents=True, exist_ok=True)
if (T / 'PROTOCOL_REGISTRATION.json').exists():
    raise SystemExit('Already registered; do not overwrite a running protocol.')

configs = [
    {'id': 'C00', 'depth': 3, 'dropout': 0.0, 'hidden_dim': 300},
    {'id': 'C01', 'depth': 3, 'dropout': 0.1, 'hidden_dim': 300},
    {'id': 'C02', 'depth': 5, 'dropout': 0.0, 'hidden_dim': 300},
    {'id': 'C03', 'depth': 5, 'dropout': 0.1, 'hidden_dim': 300},
]
cfg = {'schema': 1, 'analysis_id': 'DMPNN_LIMITED_GRID_20261006', 'intent': 'post-hoc exploratory sensitivity; registered before these new fits',
       'routes': ['source_exact', 'temporal_exact'], 'search_seed': 42, 'evaluation_seeds': [42,53,67],
       'max_epochs': 50, 'patience': 10, 'batch_size': 64, 'configs': configs,
       'selection': 'minimum validation MSE within each target/cohort/route; exact ties choose lowest config ID',
       'test_access': 'only after every context selection is frozen; search reads train/valid files only',
       'additional_seed_fits': 88, 'search_fits': 176, 'expected_selected_test_predictions':132,
       'test_population': 'same frozen route-specific test population as P3-A',
       'primary_summary': 'three-seed median skill by route; YE minus SE by target/cohort; panel median across 22 pairs',
       'uncertainty': 'descriptive only; no new confidence interval claimed',
       'baseline': 'archived P3-A default D-MPNN three-seed results and frozen RF results',
       'stop_on': ['input-hash mismatch', 'non-finite labels/predictions', 'empty partition', 'candidate failure', 'CUDA unavailable'],
       'new_packages': False}
(T / 'configs.json').write_text(json.dumps(cfg, indent=2), encoding='utf-8')
contexts = {}
files = []
for group in ['current_prepared','external_prepared']:
    root = F1 / group
    with (root / 'split_manifest.csv').open(encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            if row['view']!='main' or row['route'] not in cfg['routes']:
                continue
            name = row['corrected_csv'].replace('\\','/').rsplit('/',1)[-1]
            src = root / 'data' / 'main' / name
            assert sha(src)==row['corrected_sha256'],str(src)
            with src.open(encoding='utf-8-sig', newline='') as stream:
                rows = list(csv.DictReader(stream))
            assert len(rows)==int(row['corrected_rows']) and rows
            assert len({x['record_uid'] for x in rows})==len(rows)
            key = '|'.join([row['scenario'],row['target'],row['route']])
            context = contexts.setdefault(key, {'key':key, 'scenario':row['scenario'],'target':row['target'],'route':row['route'],'parts':{}})
            dst = T / 'inputs' / group / name
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dst)
            assert sha(dst)==row['corrected_sha256']
            part = row['partition']
            context['parts'][part] = {'path':dst.relative_to(T).as_posix(),'sha256':sha(dst),'rows':len(rows)}
            files.append({'source':str(src),'copy':str(dst),'sha256':sha(dst),'partition':part,'rows':len(rows)})
assert len(contexts)==44 and all(set(c['parts'])=={'train','valid','test'} for c in contexts.values())
assert len({c['target'] for c in contexts.values()})==11
kinases = ['alk','braf','egfr','erbb2','kdr','met']
ordered = sorted(contexts.values(),key=lambda x:(x['target'] not in kinases,x['target'],x['scenario'],cfg['routes'].index(x['route'])))
(T/'INPUT_MANIFEST.json').write_text(json.dumps({'contexts':ordered,'files':files,'source_F1':str(F1)},indent=2),encoding='utf-8')
baseline = V4/'evidence/05_SCIENCE_EVIDENCE/round2/results/p3/dmpnn/dmpnn_runs.csv'
shutil.copy2(baseline,T/'ARCHIVED_DEFAULT_DMPNN.csv')
shutil.copy2(V4/'evidence/05_SCIENCE_EVIDENCE/round2/results/p3/corrected/P3A_SUMMARY.json',T/'ARCHIVED_P3A_SUMMARY.json')
protocol = f'''# Limited-grid D-MPNN sensitivity protocol

Registered locally at {stamp()}, before any fit in this new analysis. This is an exploratory extension after the original results were known, not a retrospective claim of preregistration. Author authorization: "全权交给你" on 6 October 2026, continuing the authorized modern-model extension. V4 and all original analyses remain intact.

## Question and scope

Does the descriptive source-document versus document-year contrast persist when the same D-MPNN receives an equal, small validation-only search budget? Use all 11 archived targets, both broad/operational cohorts, source_exact and temporal_exact: 44 contexts. No target/cohort/partition, label, endpoint policy, RF setting or baseline is altered. Scaffold routes, other models and new databases are outside this small sensitivity.

## Fixed search

Four candidates: message depth 3/5 crossed with dropout 0/0.1, hidden dimension 300. Dropout is applied to message passing and the one-hidden-layer regression FFN. Other settings match the P3-A Chemprop 2.2.4 default driver: mean aggregation, default featurizer and learning-rate schedule, batch 64, training-only target scaler, no batch normalization, maximum 50 epochs, patience 10 and best validation weights.

Fit all four candidates with seed 42 within every context (176 fits). Select by lowest validation MSE, with an exact tie resolved by C00,C01,C02,C03 order. Freeze every context's selected configuration before opening any test CSV in the experiment driver. Then predict selected seed-42 weights and fit/evaluate the same selected configuration with seeds 53 and 67 (88 additional fits, 132 selected test predictions). No candidate receives test-based selection; a failed candidate stops the batch rather than being silently omitted. Smoke fits are two epochs on one context for all four configurations and are excluded from results.

The validation set serves both early stopping and finite-grid selection. This is not nested cross-validation or exhaustive optimization. A single search seed can make configuration selection noisy. These limitations must accompany any manuscript interpretation. Archived test results were already known at study level; the new code enforces validation-only candidate selection.

## Readouts

Report selected configuration, validation MSE, each seed's test absolute MSE/MAE/RMSE, training-mean errors and skill. Take the three-seed median skill within each route, then YE-SE per target/cohort, the median across all 22 pairs, direction counts and exceptions. Compare with the frozen original default D-MPNN and RF summaries on identical route-specific contexts. Show absolute skill as well as differences. No causal, superiority, full-optimization or confirmatory claim, and no newly inferred interval is planned in this limited extension.

## Integrity and compute

Every copied input is bound to the original F1 split manifest by SHA-256 and row count. Registration stores script/config/protocol hashes. Search modules do not load test inputs. All selections are sealed together; evaluation checks that seal and permits only selected configurations. Resume requires unchanged binding. Results, predictions, histories and state dictionaries remain under this independent directory. Package installation is unnecessary: existing .venv-dmpnn Python 3.11 / Torch 2.6.0+cu124 / Chemprop 2.2.4 / Lightning 2.6.6 and RTX 4070 Laptop are reused.

Original 264 P3-A fits ran in approximately 47 minutes on this machine. This plan has 264 new full fits, with depth-5 candidates potentially slower; 45–100 minutes is a provisional estimate rather than a completion promise. Record actual time and environment. GPU nondeterminism is retained and disclosed. Stop on a failed integrity/finite-value gate; do not revise the grid after seeing results.

## Publication status

Results are new local research outputs. They do not automatically enter V4 or change its disclosure/version/status. Manuscript incorporation requires a separate documented version change. No external service receives unpublished text or these outputs in this execution.
'''
(T/'PROTOCOL.md').write_text(protocol,encoding='utf-8')
bind_files = [T/'configs.json',T/'INPUT_MANIFEST.json',T/'PROTOCOL.md',R/'scripts/tune_dmpnn.py']
registration = {'registered_utc':stamp(),'status':'registered_before_new_fitting','bindings':{p.relative_to(R).as_posix():sha(p) for p in bind_files},
                'source_files':files,'archived_baseline_sha256':sha(T/'ARCHIVED_DEFAULT_DMPNN.csv'),'selected_contexts':44,'model_fits_planned':264,
                'prior_results_known':True,'external_registration':False}
(T/'PROTOCOL_REGISTRATION.json').write_text(json.dumps(registration,indent=2),encoding='utf-8')
print(json.dumps({'registered':True,'contexts':44,'input_files':len(files),'planned_fits':264}))
