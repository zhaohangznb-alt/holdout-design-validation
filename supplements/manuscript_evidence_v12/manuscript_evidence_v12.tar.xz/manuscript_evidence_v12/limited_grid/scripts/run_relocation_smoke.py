"""Exercise the sealed driver from a new directory, without another full search."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,subprocess,sys,time
R=Path(__file__).resolve().parents[1];T=R/'tuning'
assert json.loads((T/'DEFAULT_CONTROL_STATUS.json').read_text())['stage']=='complete'
name='relocation_smoke_verified'
subprocess.run([sys.executable,'-X','utf8',str(R/'scripts/prepare_clean_tuning_replay.py'),'--name',name],check=True)
copy=R/'clean_replays'/name
python='E:/paper/kinase_followup_execution/.venv-dmpnn/python.exe'
started=datetime.now(timezone.utc).isoformat();clock=time.monotonic()
with (copy/'smoke_execution.log').open('wb') as f:
    process=subprocess.run([python,'-X','utf8',str(copy/'scripts/tune_dmpnn.py'),'smoke'],cwd=copy,stdout=f,stderr=subprocess.STDOUT)
assert process.returncode==0,'Relocated smoke failed; inspect isolated log'
result=json.loads((copy/'tuning/SMOKE_CHECK.json').read_text())
assert result['status']=='PASS' and result['four_configs']==4 and result['test_accessed'] is False
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for p in sorted((copy/'tuning/smoke').rglob('record.json')):
    row=json.loads(p.read_text());assert row['epochs_run']==2 and row['test_accessed'] is False
    records.append({'config':row['config'],'validation_mse':row['valid_mse'],'record_sha256':sha(p),'weights_sha256':sha(p.parent/'weights.pt')})
assert len(records)==4
status={'status':'PASS','scope':'relocated four-configuration two-epoch validation smoke only; no second full retrain',
    'excluded_from_scientific_results':True,'new_test_access':False,'new_directory':str(copy),
    'input_files':132,'driver_registration_preserved':True,'records':records,
    'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-clock,
    'log_sha256':sha(copy/'smoke_execution.log')}
(T/'RELOCATION_SMOKE_CHECK.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
print(json.dumps(status,indent=2))
