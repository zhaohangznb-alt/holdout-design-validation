from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
R=Path(__file__).resolve().parents[1];T=R/'tuning'
assert not (T/'SELECTION_FROZEN.json').exists(),'Register this deviation before any test evaluation'
assert not (T/'DEFAULT_CONTROL_REGISTRATION.json').exists()
when=datetime.now(timezone.utc).isoformat()
text=f'''# D-TUNE-1: contemporaneous fixed-default control

Recorded {when}, during validation-only search, before the global selection freeze and before any new test evaluation. The original four-candidate grid and selection rule stay fixed.

At this review, 16 completed C00 seed-42 validation fits had a maximum validation-MSE difference of 0.0672758563 from the archived P3-A seed-42 records. This observation does not identify its cause. A comparison with only the archived default could conflate parameter selection with old/new driver or execution variation.

Add a contemporaneous default C00 control with the same executed driver and seeds42/53/67 for all44 contexts. Seed42 weights already exist in the search. If C00 is selected, reuse the identical selected runs for seeds53/67; otherwise fit C00 with those two seeds. Thus at most88 additional full fits are needed; the actual count depends solely on validation selection, never on test performance. Predict all132 default-control records after the frozen selections. Do not change any grid, data, early-stopping budget, seed or original result.

New results must show both contemporaneous default and selected-grid skills/contrasts; archived default remains a separately identified historical comparator. Report original/fresh default differences rather than asserting they are due to GPU nondeterminism. This is an exploratory implementation/selection sensitivity and does not imply nested validation or an exhaustive tuned-model benchmark.
'''
(T/'D-TUNE-1_DEFAULT_CONTROL.md').write_text(text,encoding='utf-8')
script=R/'scripts/run_fresh_default_control.py'
record={'registered_utc':when,'status':'registered_before_new_test_evaluation','reason':'validation discrepancy observed in fixed C00; cause not established',
        'validation_records_observed':16,'maximum_observed_validation_mse_change':0.06727585625344634,
        'grid_changed':False,'maximum_additional_fits':88,'control_script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
        'deviation_sha256':hashlib.sha256(text.encode()).hexdigest()}
(T/'DEFAULT_CONTROL_REGISTRATION.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
