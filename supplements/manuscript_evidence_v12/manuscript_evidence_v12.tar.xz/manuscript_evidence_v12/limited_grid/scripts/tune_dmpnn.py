"""Independent validation-only finite-grid sensitivity. Search never opens test CSVs."""
from pathlib import Path
import argparse, copy, csv, hashlib, json, math, platform, time
from datetime import datetime, timezone
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
T = ROOT / 'tuning'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
stamp = lambda: datetime.now(timezone.utc).isoformat()
def save(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8');tmp.replace(p)
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def check_binding():
    registration=read(T/'PROTOCOL_REGISTRATION.json')
    for rel,digest in registration['bindings'].items():assert sha(ROOT/rel)==digest,rel
    return sha(T/'PROTOCOL_REGISTRATION.json')
def frame(part):
    p=T/part['path'];assert sha(p)==part['sha256']
    f=pd.read_csv(p,float_precision='round_trip')
    assert len(f)==part['rows'] and len(f)>0
    assert f['target'].notna().all() and np.isfinite(f['target'].to_numpy(float)).all()
    return f
def versions():
    import torch,chemprop,lightning,rdkit
    assert torch.cuda.is_available(),'CUDA unavailable; no silent CPU fallback'
    return {'python':platform.python_version(),'torch':torch.__version__,'chemprop':chemprop.__version__,
            'lightning':lightning.__version__,'rdkit':rdkit.__version__,'gpu':torch.cuda.get_device_name(0),'platform':platform.platform()}
def build_model(config,mean,scale):
    from chemprop import models,nn
    from sklearn.preprocessing import StandardScaler
    scaler=StandardScaler();scaler.mean_=np.array([mean]);scaler.scale_=np.array([scale]);scaler.var_=scaler.scale_**2;scaler.n_features_in_=1
    mp=nn.BondMessagePassing(d_h=config['hidden_dim'],depth=config['depth'],dropout=config['dropout'])
    ffn=nn.RegressionFFN(input_dim=config['hidden_dim'],hidden_dim=300,n_layers=1,dropout=config['dropout'],
                         output_transform=nn.UnscaleTransform.from_standard_scaler(scaler))
    return models.MPNN(mp,nn.MeanAggregation(),ffn,batch_norm=False)
def dataset(f):
    from chemprop import data,featurizers
    d=data.MoleculeDataset([data.MoleculeDatapoint.from_smi(s,y=np.array([float(y)])) for s,y in zip(f.smiles,f.target)],
                          featurizers.SimpleMoleculeMolGraphFeaturizer())
    d.cache=True
    return d
def train_validate(context,config,seed,max_epochs,patience,out,registration):
    """Only train and valid are read. No test predictions or test metrics exist here."""
    import torch
    from torch.utils.data import DataLoader
    from lightning import pytorch as pl
    from lightning.pytorch.callbacks import EarlyStopping,Callback
    from chemprop import data
    recfile=out/'record.json';weightfile=out/'weights.pt'
    if recfile.exists():
        rec=read(recfile);assert rec['registration_sha256']==registration and sha(weightfile)==rec['weights_sha256']
        return rec
    started=time.monotonic();pl.seed_everything(seed,workers=True)
    trf,vaf=frame(context['parts']['train']),frame(context['parts']['valid'])
    tr,va=dataset(trf),dataset(vaf);scaler=tr.normalize_targets();va.normalize_targets(scaler)
    mean,scale=float(scaler.mean_[0]),float(scaler.scale_[0])
    model=build_model(config,mean,scale)
    class Best(Callback):
        def __init__(self):self.best=float('inf');self.state=None;self.epoch=-1;self.history=[]
        def on_validation_end(self,trainer,module):
            if trainer.sanity_checking:return
            loss=float(trainer.callback_metrics['val_loss']);assert math.isfinite(loss)
            self.history.append([int(trainer.current_epoch),loss])
            if loss<self.best:
                self.best=loss;self.epoch=int(trainer.current_epoch)
                self.state=copy.deepcopy({k:v.detach().cpu() for k,v in module.state_dict().items()})
    best=Best();es=EarlyStopping(monitor='val_loss',mode='min',patience=patience)
    trainer=pl.Trainer(logger=False,enable_checkpointing=False,enable_progress_bar=False,enable_model_summary=False,
                       accelerator='gpu',devices=1,max_epochs=max_epochs,callbacks=[es,best],num_sanity_val_steps=0,
                       default_root_dir=str(out/'lightning'))
    trl=data.build_dataloader(tr,num_workers=0,seed=seed,batch_size=64)
    val=DataLoader(va,batch_size=64,shuffle=False,collate_fn=data.collate_batch)
    trainer.fit(model,trl,val);assert best.state is not None
    model.load_state_dict(best.state)
    original_val=DataLoader(dataset(vaf),batch_size=64,shuffle=False,collate_fn=data.collate_batch)
    vpred=torch.cat(trainer.predict(model,original_val)).float().cpu().numpy().reshape(-1)
    assert len(vpred)==len(vaf) and np.isfinite(vpred).all()
    vmse=float(np.mean((vaf.target.to_numpy(float)-vpred)**2))
    expected=best.best*scale**2
    assert abs(vmse-expected)<=max(1e-6,1e-3*vmse),'validation-scale mismatch'
    out.mkdir(parents=True,exist_ok=True);tmp=weightfile.with_suffix('.tmp');torch.save(best.state,tmp);tmp.replace(weightfile)
    rec={'context':context['key'],'config':config,'seed':seed,'train_rows':len(trf),'valid_rows':len(vaf),
         'valid_mse':vmse,'valid_mse_from_loss':expected,'scaler_mean':mean,'scaler_scale':scale,
         'epochs_run':len(best.history),'best_epoch_zero_based':best.epoch,'validation_history':best.history,
         'elapsed_seconds':time.monotonic()-started,'registration_sha256':registration,
         'weights_sha256':sha(weightfile),'finished_utc':stamp(),'test_accessed':False}
    save(recfile,rec)
    return rec
def predict_test(context,rec,out,registration):
    import torch
    from torch.utils.data import DataLoader
    from lightning import pytorch as pl
    from chemprop import data
    predfile=out/'test_predictions.csv';metricfile=out/'test_metrics.json'
    if metricfile.exists():
        m=read(metricfile);assert m['registration_sha256']==registration and sha(predfile)==m['prediction_sha256'];return m
    weights=T/rec['weights_relative'];assert sha(weights)==rec['weights_sha256']
    model=build_model(rec['config'],rec['scaler_mean'],rec['scaler_scale'])
    model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True))
    tf=frame(context['parts']['test']);tr=frame(context['parts']['train'])
    loader=DataLoader(dataset(tf),batch_size=64,shuffle=False,collate_fn=data.collate_batch)
    trainer=pl.Trainer(logger=False,enable_checkpointing=False,enable_progress_bar=False,enable_model_summary=False,accelerator='gpu',devices=1)
    pred=torch.cat(trainer.predict(model,loader)).float().cpu().numpy().reshape(-1)
    y=tf.target.to_numpy(float);assert len(pred)==len(y) and np.isfinite(pred).all()
    mean=float(tr.target.mean());mse=float(np.mean((y-pred)**2));base=float(np.mean((y-mean)**2));assert base>0
    out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame({'record_uid':tf.record_uid,'target':y,'prediction':pred}).to_csv(predfile,index=False)
    m={'context':context['key'],'scenario':context['scenario'],'target':context['target'],'route':context['route'],
       'seed':rec['seed'],'config_id':rec['config']['id'],'test_rows':len(tf),'training_mean':mean,
       'mse_model':mse,'mse_mean':base,'mae_model':float(np.mean(np.abs(y-pred))),
       'rmse_model':math.sqrt(mse),'skill':1-mse/base,'valid_mse':rec['valid_mse'],
       'prediction_sha256':sha(predfile),'registration_sha256':registration,'finished_utc':stamp()}
    save(metricfile,m);return m
def name(c):return c['key'].replace('|','_')
def run(phase):
    binding=check_binding();cfg=read(T/'configs.json');ctx=read(T/'INPUT_MANIFEST.json')['contexts'];env=versions()
    if phase=='smoke':
        records=[]
        for config in cfg['configs']:
            out=T/'smoke'/config['id'];rec=train_validate(ctx[0],config,42,2,10,out,binding)
            assert rec['epochs_run']==2;records.append(rec)
        save(T/'SMOKE_CHECK.json',{'status':'PASS','excluded_from_results':True,'four_configs':len(records),'test_accessed':False,'environment':env,'finished_utc':stamp()})
        return
    assert read(T/'SMOKE_CHECK.json')['status']=='PASS'
    if phase=='search':
        started=stamp();save(T/'RUN_STATUS.json',{'stage':'search','started_utc':started,'environment':env,'registration_sha256':binding})
        rows=[]
        for c in ctx:
            for config in cfg['configs']:
                out=T/'search'/name(c)/config['id']
                rec=train_validate(c,config,42,cfg['max_epochs'],cfg['patience'],out,binding)
                rows.append({'context':c['key'],'config_id':config['id'],'valid_mse':rec['valid_mse'],'epochs_run':rec['epochs_run'],'elapsed_seconds':rec['elapsed_seconds']})
                save(T/'RUN_STATUS.json',{'stage':'search','search_complete':len(rows),'search_expected':176,'last_context':c['key'],'last_config':config['id'],'updated_utc':stamp(),'environment':env,'registration_sha256':binding})
                print('SEARCH',len(rows),'/176',c['key'],config['id'],round(rec['valid_mse'],6),flush=True)
        selected=[]
        for c in ctx:
            candidates=[read(T/'search'/name(c)/q['id']/'record.json') for q in cfg['configs']]
            best=min(candidates,key=lambda r:(r['valid_mse'],r['config']['id']))
            selected.append({'context':c['key'],'config':best['config'],'seed42_valid_mse':best['valid_mse'],'record_relative':f'search/{name(c)}/{best["config"]["id"]}/record.json'})
        pd.DataFrame(rows).to_csv(T/'VALIDATION_SEARCH.csv',index=False)
        if (T/'SELECTION_FROZEN.json').exists():
            assert read(T/'SELECTION_FROZEN.json')['selections']==selected
        else:
            save(T/'SELECTION_FROZEN.json',{'frozen_utc':stamp(),'registration_sha256':binding,'selections':selected,'test_accessed':False,'search_records':len(rows),'search_table_sha256':sha(T/'VALIDATION_SEARCH.csv')})
        save(T/'RUN_STATUS.json',{'stage':'selection_frozen','search_complete':176,'selected_contexts':44,'environment':env,'updated_utc':stamp()})
        return
    seal=read(T/'SELECTION_FROZEN.json');assert seal['registration_sha256']==binding and len(seal['selections'])==44
    assert sha(T/'VALIDATION_SEARCH.csv')==seal['search_table_sha256']
    sealhash=sha(T/'SELECTION_FROZEN.json');allmetrics=[]
    lookup={c['key']:c for c in ctx}
    for selected in seal['selections']:
        c=lookup[selected['context']];config=selected['config']
        for seed in cfg['evaluation_seeds']:
            assert sha(T/'SELECTION_FROZEN.json')==sealhash
            if seed==42:
                rp=T/selected['record_relative'];rec=read(rp);rec['weights_relative']=(rp.parent/'weights.pt').relative_to(T).as_posix()
            else:
                out=T/'additional_seed_fits'/name(c)/str(seed)
                rec=train_validate(c,config,seed,cfg['max_epochs'],cfg['patience'],out,binding)
                rec['weights_relative']=(out/'weights.pt').relative_to(T).as_posix()
            assert rec['config']==config
            m=predict_test(c,rec,T/'evaluation'/name(c)/str(seed),binding)
            allmetrics.append(m)
            save(T/'RUN_STATUS.json',{'stage':'selected_test_evaluation','predictions_complete':len(allmetrics),'predictions_expected':132,'selection_seal_sha256':sealhash,'environment':env,'updated_utc':stamp()})
            print('EVALUATE',len(allmetrics),'/132',c['key'],seed,round(m['skill'],6),flush=True)
    pd.DataFrame(allmetrics).to_csv(T/'SELECTED_TEST_RUNS.csv',index=False)
    save(T/'RUN_STATUS.json',{'stage':'complete_new_sensitivity','search_fits':176,'additional_seed_fits':88,'selected_test_predictions':132,'selection_seal_sha256':sealhash,'environment':env,'finished_utc':stamp(),'manuscript_incorporated':False})
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['smoke','search','evaluate']);args=ap.parse_args()
    try:run(args.phase)
    except Exception as e:
        save(T/'FAILURE.json',{'phase':args.phase,'error_type':type(e).__name__,'message':str(e),'failed_utc':stamp()});raise
