"""Independent validation of prepared samples and completed common-test predictions."""
from pathlib import Path
import json, hashlib, argparse, datetime
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text(encoding='utf8'))
def csv(p): return pd.read_csv(p,float_precision='round_trip')
def verify(stage):
    plan=read(ROOT/'ANALYSIS_PLAN.json'); binding=read(ROOT/'BINDING.json'); prepared=read(ROOT/'PREPARED.json')
    assert sha(ROOT/'ANALYSIS_PLAN.json')==binding['plan_sha256']
    assert sha(ROOT/'experiment.py')==binding['runner_sha256']
    assert sha(ROOT/'MODEL_CONFIG.json')==binding['config_sha256']
    assert sha(ROOT/'SOURCE_HASHES.json')==binding['source_hashes_sha256']
    assert prepared['binding']==binding and sha(ROOT/'manifest.csv')==prepared['manifest_sha256']
    assert sha(ROOT/'INPUT_HASHES.json')==prepared['input_hashes_sha256']
    sources=read(ROOT/'SOURCE_HASHES.json'); inputs=read(ROOT/'INPUT_HASHES.json')
    for p,h in sources.items(): assert sha(p)==h,p
    for p,h in inputs.items(): assert sha(ROOT/p)==h,p
    counts=csv(ROOT/'POOL_COUNTS.csv'); manifest=csv(ROOT/'manifest.csv')
    assert list(counts.target)==plan['targets'] and len(counts)==11
    assert set(manifest.draw_seed)==set(plan['subsample_seeds'])
    assert len(manifest)==11*4*5*5 and manifest.prediction_file.nunique()==385
    assert len(manifest.drop_duplicates(['target','arm','draw_seed','model','model_seed']))==len(manifest)
    assert dict(manifest.groupby('model').model_seed.apply(lambda x:sorted(set(x))))==plan['models']
    cache={}
    def f(name):
        if name not in cache: cache[name]=csv(ROOT/name)
        return cache[name]
    from rdkit import Chem, DataStructs
    from rdkit.Chem import rdFingerprintGenerator
    for t in plan['targets']:
        common=f(f'inputs/common_test_{t}.csv'); co=counts[counts.target==t].iloc[0]
        assert common.record_uid.is_unique and len(common)==co.common_test_n and len(common)>0
        for route in plan['routes']:
            full=f(f'inputs/train_{t}_{route}_full.csv')
            assert len(full)==co['source_full_n' if route=='source_exact' else 'year_full_n']
            for col in ['record_uid','smiles','document_chembl_id']:
                assert not set(common[col])&set(full[col]),(t,route,col)
            for seed in plan['subsample_seeds']:
                sample=f(f'inputs/train_{t}_{route}_s{seed}.csv')
                pos=np.sort(np.random.RandomState(seed).choice(len(full),int(co.matched_n),replace=False)) if len(full)>co.matched_n else np.arange(len(full))
                expected=full.iloc[pos].reset_index(drop=True)
                assert list(sample.columns)==list(expected.columns)
                pd.testing.assert_frame_equal(sample,expected,check_exact=True)
                assert len(sample)==co.matched_n and sample.record_uid.is_unique
    res=dict(stage=stage,status='PASS',source_files_unchanged=len(sources),prepared_files_checked=len(inputs),targets=11,common_test_rows=int(counts.common_test_n.sum()),logical_prediction_references=len(manifest),unique_prediction_cases=int(manifest.prediction_file.nunique()),prepared_sampling_checks=110,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if stage=='prepared':
        (ROOT/'PREPARATION_VERIFICATION.json').write_text(json.dumps(res,indent=2),encoding='utf8'); print(json.dumps(res,indent=2)); return
    records=[]; max_error=0.; nearest_checks=0; fits=[]; reused=0
    gen=rdFingerprintGenerator.GetMorganGenerator(**plan['fingerprint']); intcache={}
    def bits(s):
        if s not in intcache:
            mol=Chem.MolFromSmiles(s); assert mol is not None
            arr=gen.GetFingerprintAsNumPy(mol).astype(np.int32); intcache[s]=arr
        return intcache[s]
    for r in manifest.drop_duplicates('prediction_file').itertuples():
        p=ROOT/r.prediction_file; ledger=read(ROOT/'ledgers'/p.with_suffix('.complete.json').name)
        assert ledger['state']=='complete' and ledger['binding']==binding and sha(p)==ledger['prediction_sha256']
        assert ledger['reused_frozen_prediction']==r.reused_frozen_prediction and ledger['actual_fit']==r.actual_fit_expected and ledger['index_built']==r.index_build_expected
        te=f(r.test_file); tr=f(r.train_file); pred=csv(p)
        assert list(pred.record_uid)==list(te.record_uid) and list(pred.smiles)==list(te.smiles)
        assert np.array_equal(pred.target.to_numpy(),te.target.to_numpy()) and np.isfinite(pred.prediction).all()
        mean=tr.target.mean(); assert np.max(abs(pred.training_mean-mean))<=1e-12
        loss=(te.target.to_numpy()-pred.prediction.to_numpy())**2; base=(te.target.to_numpy()-mean)**2
        assert np.max(abs(loss-pred.squared_model_error))<=1e-12
        assert np.max(abs(base-pred.squared_baseline_error))<=1e-12
        if r.reused_frozen_prediction:
            reused+=1
            assert sha(ledger['source_prediction'])==ledger['source_prediction_sha256']
            original=csv(ledger['source_prediction']).set_index('record_uid').loc[te.record_uid]
            assert np.array_equal(original.prediction.to_numpy(),pred.prediction.to_numpy())
        else:
            fit=read(ROOT/ledger['fit_ledger']); assert fit['state']=='complete' and fit['binding']==binding and fit['identity']['training_signature']==r.train_signature
            assert sha(ROOT/fit['model_file'])==fit['model_sha256'] and fit['identity']['model']==r.model and fit['identity']['model_seed']==r.model_seed
            fits.append((ledger['fit_key'],r.model,fit['actual_fit'],fit['index_built']))
        if r.model=='tanimoto1nn':
            a=np.stack([bits(s) for s in tr.smiles]); n=a.sum(axis=1)
            for j in sorted(set([0,len(te)//2,len(te)-1])):
                q=bits(te.smiles.iloc[j]); inter=np.sum(a*q,axis=1,dtype=np.int32); union=n+q.sum()-inter
                sim=np.divide(inter,union,out=np.ones(len(a),dtype=float),where=union!=0)
                k=int(np.argmax(sim)); assert abs(pred.prediction.iloc[j]-tr.target.iloc[k])<=1e-12
                nearest_checks+=1
        records.append((r.prediction_file,float(loss.mean()),float(base.mean()),float(np.var(te.target))))
    assert reused==110 and len(fits)==len(set(x[0] for x in fits))==275
    assert sum(x[1]=='rf' for x in fits)==165 and sum(x[1]=='ridge' for x in fits)==55 and sum(x[1]=='tanimoto1nn' for x in fits)==55
    computed={p:(m,b,v) for p,m,b,v in records}; runs=csv(ROOT/'analysis/run_metrics.csv')
    assert len(runs)==1100
    for r in runs.itertuples():
        m,b,v=computed[r.prediction_file]
        for actual,expected in [(r.mse,m),(r.baseline_mse,b),(r.test_variance,v),(r.normalized_mse,m/v),(r.training_mean_skill,1-m/b)]:
            err=abs(actual-expected); max_error=max(max_error,err); assert err<=1e-12
    arms=csv(ROOT/'analysis/arm_metrics.csv'); calc=runs.groupby(['panel','target','arm','draw_seed','model'],sort=False,as_index=False)[['train_n','test_n','mse','baseline_mse','test_variance','normalized_mse','training_mean_skill']].median()
    pd.testing.assert_frame_equal(arms,calc,check_exact=True)
    con=csv(ROOT/'analysis/per_draw_contrasts.csv'); assert len(con)==165
    for r in con.itertuples():
        a=arms[(arms.target==r.target)&(arms.model==r.model)&(arms.draw_seed==r.draw_seed)].set_index('arm').mse
        assert abs(r.source_size-(a.source_matched-a.source_full))<=1e-12
        assert abs(r.matched_pool-(a.year_matched-a.source_matched))<=1e-12
        assert abs(r.year_size-(a.year_full-a.year_matched))<=1e-12
        assert abs(r.full_gap-(a.year_full-a.source_full))<=1e-12
        assert abs(r.full_gap-r.source_size-r.year_size-r.matched_pool)<=1e-12
    summary=csv(ROOT/'analysis/target_summary.csv'); assert len(summary)==33
    for r in summary.itertuples():
        c=con[(con.target==r.target)&(con.model==r.model)]
        for n in ['source_size','matched_pool','full_gap','normalized_source_size','normalized_matched_pool','normalized_full_gap']:
            for suffix,op in [('median','median'),('min','min'),('max','max')]:
                assert abs(getattr(r,n+'_'+suffix)-getattr(c[n],op)())<=1e-12
    ds=csv(ROOT/'analysis/structure_diagnostics.csv'); assert len(ds)==110 and ds.median_max_tanimoto.between(0,1).all() and ds.fraction_ge_08.between(0,1).all()
    assert ds.train_n.eq(ds.target.map(counts.set_index('target').matched_n)).all()
    res.update(new_rf_fits=165,new_ridge_fits=55,new_nn_indices=55,reused_unique_prediction_cases=reused,independent_nearest_checks=nearest_checks,metrics_max_abs_error=max_error,per_draw_contrasts=165,target_model_summaries=33,per_draw_additive_identity='PASS',sampling_ranges_are_not_confidence_intervals=True)
    (ROOT/'VERIFICATION.json').write_text(json.dumps(res,indent=2),encoding='utf8'); print(json.dumps(res,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--stage',choices=['prepared','final'],default='final'); ap.add_argument('--root',type=Path); args=ap.parse_args()
    if args.root: ROOT=args.root.resolve()
    verify(args.stage)
