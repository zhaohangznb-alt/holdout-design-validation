from pathlib import Path
import json,re,shutil,hashlib,difflib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
B=R.parent/'holdout_shift_diagnostics_20261003_v1'
T='alk braf egfr erbb2 kdr met ache dpp4 ptgs2 hdac1 pde4d'.split()
def csv(p): return pd.read_csv(p,float_precision='round_trip')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v): Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf8')
def fmt(v): return f'{v:.3f}'
def rng(a,name): return f'{fmt(a[name+"_median"])} [{fmt(a[name+"_min"])}, {fmt(a[name+"_max"])}]'

assert json.loads((R/'VERIFICATION.json').read_text())['status']=='PASS'
shutil.copytree(B/'02_editable_source',R/'02_editable_source',dirs_exist_ok=True)
(R/'04_verification').mkdir(exist_ok=True)
s=csv(R/'analysis/target_summary.csv'); rf=s[s.model.eq('rf')].set_index('target').loc[T]
c=csv(R/'POOL_COUNTS.csv').set_index('target').loc[T]
result=json.loads((R/'RESULT_SUMMARY.json').read_text()); sc=csv(R/'analysis/structure_summary.csv').set_index('target').loc[T]
rf_count=result['matched_pool_effects']['rf']['year_higher_mse']; size_count=result['matched_pool_effects']['rf']['source_subsampling_higher_mse']
exceptions=[t.upper() for t in T if rf.loc[t].matched_pool_median<=0]
allpositive=[t.upper() for t in T if rf.loc[t].matched_pool_min>0]
lower_sim=int(sc.matched_similarity_change_median.lt(0).sum())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.linewidth':.6,'xtick.major.size':3,'ytick.major.size':0})
fig,axs=plt.subplots(1,2,figsize=(7.05,4.7),sharey=True)
y=np.array([0,1,2,3,4,5,6.6,7.6,8.6,9.6,10.6])
for ax,name,color,title in zip(axs,['source_size','matched_pool'],['#28749A','#B75A27'],['(a) Training-row reduction','(b) Matched-size pool contrast']):
    for yy,t in zip(y,T):
        a=rf.loc[t]
        ax.plot([a[name+'_min'],a[name+'_max']],[yy,yy],color=color,lw=1.3,zorder=2)
        ax.plot([a[name+'_min'],a[name+'_min']],[yy-.07,yy+.07],color=color,lw=.8)
        ax.plot([a[name+'_max'],a[name+'_max']],[yy-.07,yy+.07],color=color,lw=.8)
    ax.scatter(rf[name+'_median'],y,color=color,s=26,zorder=3)
    ax.set_ylim(11.25,-.65); ax.axhline(5.8,color='#BAC2C7',lw=.6); ax.axvline(0,color='#68767E',lw=.8)
    ax.grid(axis='x',color='#E5E8EA',lw=.5);ax.set_axisbelow(True)
    ax.set_title(title,loc='left',fontweight='bold',fontsize=9.5,pad=10,y=1.10)
    ax.set_xlabel('RF MSE difference (pChEMBL²)',labelpad=9)
    ax.set_yticks(y,labels=[f'{t.upper()} ({int(c.loc[t].common_test_n)})' for t in T])
    lo=float(rf[name+'_min'].min()); hi=float(rf[name+'_max'].max()); spread=max(hi-lo,.05)
    ax.set_xlim(min(lo,0)-spread*.10,max(hi,0)+spread*.10)
axs[0].text(0,1.035,'Source matched − source full',transform=axs[0].transAxes,fontsize=8,color='#44515B')
axs[1].text(0,1.035,'Year matched − source matched',transform=axs[1].transAxes,fontsize=8,color='#44515B')
fig.subplots_adjust(left=.19,right=.985,top=.79,bottom=.16,wspace=.27)
fig.savefig(R/'02_editable_source/figures/Figure_7.pdf',metadata={'Title':'Common-test matched-training-size controls','Creator':'Matplotlib from verified common-test experiments'})
fig.savefig(R/'analysis/Figure_7.png',dpi=180);plt.close(fig)
mapping=rf.reset_index()[['target','source_size_median','source_size_min','source_size_max','matched_pool_median','matched_pool_min','matched_pool_max']].copy()
mapping['common_test_n']=c.common_test_n.to_numpy();mapping['matched_train_n']=c.matched_n.to_numpy()
mapping.to_csv(R/'analysis/Figure_7_data.csv',index=False)

method=r'''\subsection{Common-test controls with matched training size}

For each broad-cohort target, we fixed the intersection of the archived source-exact and year-exact test records, preserving source-exact order and checking identical identities, labels and metadata. These records were disjoint from both original training pools by identity, canonical structure and source document. The common training budget was the smaller pool's number of measurement-context rows. We retained that pool in full and sampled the larger pool without replacement using five prespecified seeds (101, 211, 307, 401 and 503), preserving original row order. Sampling used neither labels nor structural similarity.

The larger-pool samples used the same fixed RF, Ridge and 1-NN specifications; RF used seeds 42, 53 and 67. Existing full-pool predictions, including the smaller matched pool, were reused on the common test rows. We compared absolute MSE for source-full, source-matched and year-matched evaluation and retained each arm's training-mean error and skill. RF MSE first averaged row losses within each seed and then took the seed median. Target summaries use the median over the five draws, with their minimum and maximum as a sampling range. The matched pools were also compared by structural proximity, distinct molecules and documents, label distribution and document years (Table S22).

'''
results=fr'''\subsection{{Common-test controls separate row-count sensitivity from pool differences}}

The common test sets contained 4,814 measurement contexts across all 11 targets, with 23--1,416 rows per target (Figure~\ref{{fig:7}}, Table S22). The year-exact training pool was smaller in every target and therefore remained unchanged; source-exact training was reduced to the same row count. The experiment created 165 RF fits, 55 Ridge fits and 55 nearest-neighbour indices, alongside 110 reused full-pool prediction files.

Source-pool subsampling increased median RF MSE in {size_count} targets. After matching training size, year-pool RF MSE was higher in {rf_count} targets{('; the exceptions were '+', '.join(exceptions)) if exceptions else ''}. The median within-target increase, divided by the fixed common-test variance, was {result['matched_pool_effects']['rf']['median_normalized_matched_pool']:.3f}, compared with {result['matched_pool_effects']['rf']['median_normalized_source_size']:.3f} for source-pool subsampling. This variance normalization provides a common descriptive error scale, while training-mean skill remains tied to each arm's training labels. Ridge and 1-NN had higher matched year-pool MSE in {result['matched_pool_effects']['ridge']['year_higher_mse']} and {result['matched_pool_effects']['tanimoto1nn']['year_higher_mse']} targets, respectively. Matched year-pool median structural proximity was lower in {lower_sim} targets. These results describe the shared test intersections.

\begin{{figure}}[!htbp]
\centering
\includegraphics[width=\linewidth]{{figures/Figure_7.pdf}}
\caption{{Common-test RF comparisons with training-size control. Parentheses give the number of common test measurement contexts. (a) MSE of the subsampled source pool minus MSE of the full source pool. (b) MSE of the full year pool minus MSE of the size-matched source pool; the year pool already has the smaller training size. Both comparisons use identical test records. Points are medians over five prespecified draws, after the three-seed RF median within each draw; horizontal lines show the minimum and maximum across draws. They are sampling ranges. Positive differences indicate higher error for the first-named arm. Scales differ between panels.}}\label{{fig:7}}
\end{{figure}}

'''
mainpath=R/'02_editable_source/main_polished.tex'; main=mainpath.read_text(encoding='utf8')
assert '\subsection{Common-test controls' not in main
main=main.replace('\section{Results}',method+'\section{Results}',1)
assert method in main
main=main.replace('\section{Discussion}',results+'\section{Discussion}',1)
assert results in main
old='Training size, chemistry, source composition and label distributions change jointly across routes; separating their contributions requires comparisons with matched test rows and controlled training-set size.'
new='The common-test control fixes evaluated rows and training-row counts; residual pool differences still include chemistry, label distributions, chronology and document composition.'
assert old in main;main=main.replace(old,new,1)
main=main.replace('These comparisons support reporting holdout operations, model specifications and eligibility sensitivities separately',f'On common test records, year-pool RF MSE remained higher after training-size matching in {rf_count} of 11 targets. These comparisons support reporting holdout operations, model specifications and eligibility sensitivities separately',1)
main=main.replace('(Tables S1--S21 and Figures S1--S8)','; common-test, matched-training-size controls (Tables S1--S22 and Figures S1--S8)',1)
availability=' A versioned Zenodo DOI remains pending.'
assert availability in main
main=main.replace(availability,' The common-test control inputs, predictions, scripts, numerical results and manifests accompany this revision in the controlled-comparison package. A versioned Zenodo DOI remains pending.',1)
mainpath.write_text(main,encoding='utf8')

rows=[];table=[]
for t in T:
    a=rf.loc[t];ridge=s[(s.target==t)&(s.model=='ridge')].iloc[0];nn=s[(s.target==t)&(s.model=='tanimoto1nn')].iloc[0]
    rows.append(f'{t.upper()} & {int(c.loc[t].common_test_n)} & {int(c.loc[t].matched_n)} & {rng(a,"source_size")} & {rng(a,"matched_pool")} & {fmt(ridge.matched_pool_median)} & {fmt(nn.matched_pool_median)} \\\\')
    table.append(dict(target=t,common_test_n=int(c.loc[t].common_test_n),matched_train_n=int(c.loc[t].matched_n),rf_source_size_median=a.source_size_median,rf_source_size_min=a.source_size_min,rf_source_size_max=a.source_size_max,rf_matched_pool_median=a.matched_pool_median,rf_matched_pool_min=a.matched_pool_min,rf_matched_pool_max=a.matched_pool_max,ridge_matched_pool_median=ridge.matched_pool_median,nn_matched_pool_median=nn.matched_pool_median))
pd.DataFrame(table).to_csv(R/'analysis/Table_S22_data.csv',index=False)
supp=fr'''\clearpage
\section*{{Table S22 Common-test controls with matched training size}}

The test records are the exact-identity intersection of source-exact and year-exact holdouts in the revised broad cohorts. They retain source-exact order, unchanged labels and metadata, and have no identity, canonical-structure or source-document overlap with either training pool. The counts are measurement contexts. Common-test coverage ranges from {c.source_test_coverage.min():.1%} to {c.source_test_coverage.max():.1%} of the original source-exact tests and {c.year_test_coverage.min():.1%} to {c.year_test_coverage.max():.1%} of the year-exact tests. All 11 targets are retained, including ERBB2 (23 rows), PTGS2 (35 rows) and PDE4D (52 rows).

Every year-exact training pool is smaller, so its full-pool prediction is reused and source-exact training is reduced to the same number of rows. For each target, five independent RandomState draws use seeds 101, 211, 307, 401 and 503 with uniform sampling without replacement, followed by sorted original positions. The draws do not use outcome labels or similarity. RF retains 500 trees, minimum leaf size two, square-root feature sampling and seeds 42, 53 and 67. Ridge retains alpha one and the original LSQR settings. The 1-NN representation is binary radius-two, 2,048-bit Morgan without chirality; ties select the first ordered training row. The run creates 165 RF fits, 55 Ridge fits and 55 1-NN indices; 110 unique full-pool prediction files are reused. The 385 unique prediction files support 1,100 logical arm--draw--model--seed references, rather than 1,100 new fits.

The table reports differences in model MSE (squared pChEMBL units). RF losses are averaged within each seed and then summarised by the three-seed median. The table entry is the median over five draws; brackets show the draw minimum and maximum. Size is source-matched minus source-full; pool is year-matched minus source-matched. Positive values mean higher error for the first-named arm. Secondary columns report the median matched-pool contrast for Ridge and 1-NN; their complete draw ranges are in the accompanying CSVs.

\begingroup
\setlength{{\tabcolsep}}{{3pt}}
\footnotesize
\renewcommand{{\thetable}}{{S22}}
\begin{{longtable}}{{lrrllll}}
\caption{{Common-test counts, training budgets and controlled error contrasts.}}\label{{tab:S22}}\\
\toprule
Target & Test $n$ & Train $m$ & RF size [range] & RF pool [range] & Ridge pool & 1-NN pool \\
\midrule
\endfirsthead
\toprule
Target & Test $n$ & Train $m$ & RF size [range] & RF pool [range] & Ridge pool & 1-NN pool \\
\midrule
\endhead
'''+ '\n'.join(rows)+r'''
\bottomrule
\end{longtable}
\endgroup

Absolute MSE is the primary comparison because each training pool supplies a different training mean. The numerical package also records matching training-mean MSE and skill, and normalizes MSE differences by the fixed common-test variance. That variance is the error of the test-mean constant and is used only as a descriptive scale. It is not a deployed training-derived comparator.

For each draw, the full-pool MSE gap equals the sum of year-full minus year-matched, year-matched minus source-matched, and source-matched minus source-full MSE. Here the first term is zero because the year pool is unchanged. The identity is checked per draw; separately reported medians of components need not add. No new bootstrap is used. The matched-size residual includes structural, label, time and source-composition differences. Structural diagnostics list median maximum test-to-train Tanimoto, the fraction at least 0.8, distinct training molecules/documents and the label/year moments for both matched pools in every draw.

The package provides all 143 prepared input files, 385 prediction files, per-job execution and reuse ledgers, the frozen plan, model settings, full-precision metrics, sample ranges, structural diagnostics and verification scripts. The original partitions, historical predictions and Figures 1--6 remain unchanged.

'''
supp=supp.replace('%',r'\%')
sipath=R/'02_editable_source/supporting_information_polished.tex'; si=sipath.read_text(encoding='utf8')
si=si.replace('Table S21 adds frozen-prediction route diagnostics.','Table S21 adds frozen-prediction route diagnostics, and Table S22 reports common-test controls with matched training size.',1)
si=si.replace('\end{document}',supp+'\end{document}',1);sipath.write_text(si,encoding='utf8')
(R/'MANUSCRIPT_DRAFT_EN.md').write_text(method+results,encoding='utf8')
checks={}
for name in ['main_polished.tex','supporting_information_polished.tex']:
    old=(B/'02_editable_source'/name).read_text(encoding='utf8'); new=(R/'02_editable_source'/name).read_text(encoding='utf8')
    pattern=r'\\begin\{(?:longtable|tabular)\}.*?\\end\{(?:longtable|tabular)\}'
    oldtabs=re.findall(pattern,old,re.S);newtabs=re.findall(pattern,new,re.S)
    assert all(x in newtabs for x in oldtabs)
    for p in [r'\\bibitem.*?(?=\\bibitem|\\end\{thebibliography\})',r'\\begin\{equation\}.*?\\end\{equation\}']:
        assert re.findall(p,old,re.S)==re.findall(p,new,re.S)
    assert old.split('\\begin{document}')[0]==new.split('\\begin{document}')[0]
    checks[name]=dict(old_tables=len(oldtabs),new_tables=len(newtabs),all_old_tables_unchanged=True,preamble_references_equations_unchanged=True)
    (R/'04_verification'/f'{name}.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='prior/'+name,tofile='new/'+name)),encoding='utf8')
figs=list((B/'02_editable_source/figures').glob('*'))
for p in figs:
    if p.is_file(): assert sha(p)==sha(R/'02_editable_source/figures'/p.name)
checks['old_figure_files_unchanged']=sum(p.is_file() for p in figs)
save(R/'04_verification/MANUSCRIPT_PRESERVATION.json',checks)
print(json.dumps(checks,indent=2))
