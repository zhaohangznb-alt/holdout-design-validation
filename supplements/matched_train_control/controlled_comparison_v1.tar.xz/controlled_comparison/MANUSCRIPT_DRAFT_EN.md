\subsection{Common-test controls with matched training size}

For each broad-cohort target, we fixed the intersection of the archived source-exact and year-exact test records, preserving source-exact order and checking identical identities, labels and metadata. These records were disjoint from both original training pools by identity, canonical structure and source document. The common training budget was the smaller pool's number of measurement-context rows. We retained that pool in full and sampled the larger pool without replacement using five prespecified seeds (101, 211, 307, 401 and 503), preserving original row order. Sampling used neither labels nor structural similarity.

The larger-pool samples used the same fixed RF, Ridge and 1-NN specifications; RF used seeds 42, 53 and 67. Existing full-pool predictions, including the smaller matched pool, were reused on the common test rows. We compared absolute MSE for source-full, source-matched and year-matched evaluation and retained each arm's training-mean error and skill. RF MSE first averaged row losses within each seed and then took the seed median. Target summaries use the median over the five draws, with their minimum and maximum as a sampling range. The matched pools were also compared by structural proximity, distinct molecules and documents, label distribution and document years (Table S22).

\subsection{Common-test controls separate row-count sensitivity from pool differences}

The common test sets contained 4,814 measurement contexts across all 11 targets, with 23--1,416 rows per target (Figure~\ref{fig:7}, Table S22). The year-exact training pool was smaller in every target and therefore remained unchanged; source-exact training was reduced to the same row count. The experiment created 165 RF fits, 55 Ridge fits and 55 nearest-neighbour indices, alongside 110 reused full-pool prediction files.

Source-pool subsampling increased median RF MSE in 8 targets. After matching training size, year-pool RF MSE was higher in 9 targets; the exceptions were EGFR, PTGS2. The median within-target increase, divided by the fixed common-test variance, was 0.160, compared with 0.008 for source-pool subsampling. This variance normalization provides a common descriptive error scale, while training-mean skill remains tied to each arm's training labels. Ridge and 1-NN had higher matched year-pool MSE in 9 and 8 targets, respectively. Matched year-pool median structural proximity was lower in 9 targets. These results describe the shared test intersections.

\begin{figure}[!htbp]
\centering
\includegraphics[width=\linewidth]{figures/Figure_7.pdf}
\caption{Common-test RF comparisons with training-size control. Parentheses give the number of common test measurement contexts. (a) MSE of the subsampled source pool minus MSE of the full source pool. (b) MSE of the full year pool minus MSE of the size-matched source pool; the year pool already has the smaller training size. Both comparisons use identical test records. Points are medians over five prespecified draws, after the three-seed RF median within each draw; horizontal lines show the minimum and maximum across draws. They are sampling ranges. Positive differences indicate higher error for the first-named arm. Scales differ between panels.}\label{fig:7}
\end{figure}

